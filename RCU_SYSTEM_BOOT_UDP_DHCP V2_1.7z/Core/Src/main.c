/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "rtc.h"
#include "spi.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
//****************************************************************************************************************************
//  I N C L U D E    F I L E S
//****************************************************************************************************************************
#include <stdio.h>
#include <string.h>    // strcat �Լ��� ����� ��� ����
#include <stdarg.h>
#include <math.h>
#include "stm32f1xx_hal.h"
#include "define.h"
#include "extern.h"
#include "w5500.h"
#include "wizchip_conf.h"
#include "cJSON.h"
#include "msg_command.h"
#include "dhcp.h"
#include "httpClient.h"
#include "auto_update.h"
#include "sntp.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
#define __MAIN_W5500_DEBUG__
#define MY_MAX_DHCP_RETRY			2
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

//==============================================================================
int ret = 0;

unsigned char buf[BUFFER_SIZE];
uint8_t gDATABUF[DATA_BUF_SIZE];

//==============================================================================
char MACidbuf[6];  
char Board_out_Format[BUFFER_SIZE];

//==============================================================================
///////////////////////////////////
// Default Network Configuration //
///////////////////////////////////
wiz_NetInfo gWIZNETINFO = { .mac = {0x00, 0x08, 0xdc, 0xab, 0xcd, 0xef},
                            .ip = {172,30,0,100},
                            .sn = {255, 255, 252, 0},
                            .gw = {172,30,0,1},
                            .dns = {0, 0, 0, 0},
                            .dhcp = NETINFO_DHCP };

char gstech_topic[30]  = "/gstech/";	//"/gstech/1888/#";
char topic_Output[30]  = "/gstech/";	//{"/gstech/566/out/status"};
char targetusername[6] = "gstech";
char targetpassword[6] = "gs7011";

//for http client
uint8_t SERVER_IP[4]   = {172,30,0,2};	//{121,150,67,34};               	// Translated IP address by DNS Server
uint16_t SERVER_PORT   = 80;                  			// Translated Port address by DNS Server
uint16_t MQTT_PORT     = 1883;                  			// Translated Port address by DNS Server
uint8_t VERSION_URI[]  = "/firmware/version.json";
char UPDATE_IP[20];
char POST_UPDATE_MSG[200];

uint32_t flashVersion;
uint8_t flag_sent_http_request = DISABLE;

uint8_t g_send_buf[DATA_BUF_SIZE];
uint8_t g_recv_buf[DATA_BUF_SIZE];
uint8_t data_buf [DATA_BUF_SIZE]; // TX Buffer for applications
uint8_t my_dhcp_retry = 0;

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void GSTECH_DELAY_1mS(WORD Delay);
void GSTECH_DEVICE_SETUP_MESSAGE_OUTPUT_PROCESS(void);
void GSTECH_TIMER_10MS_PROCESS(void);
void GSTECH_TIMER_25MS_PROCESS(void);
void GSTECH_TIMER_50MS_PROCESS(void);
void GSTECH_TIMER_100MS_PROCESS(void);
void GSTECH_TIMER_250MS_PROCESS(void);
void GSTECH_TIMER_500MS_PROCESS(void);
void GSTECH_TIMER_1000MS_PROCESS(void);
void GSTECH_TIMER_XXXXMS_PROCESS(void);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

//****************************************************************************************************************************
//  G L O B A L   F U N C T I O N    P R O T O T Y P E S
//****************************************************************************************************************************
int _write(int file, BYTE* p, int len)
{
	HAL_UART_Transmit(&huart1, p, len, 50);
	return len;
}

//****************************************************************************************************************************
//  U S E R 	C O D E
//****************************************************************************************************************************

//****************************************************************************************************************************
//
// FUNCTION       : void GSTECH_PHY_LINK_STATUS_CHECK(void)
//
// USAGE          : PHY Link Status Check Process
//
// INPUT        :   None
//
// USED			:   None
//				
// OUTPUT       :   None
//
//****************************************************************************************************************************
void GSTECH_PHY_LINK_STATUS_CHECK(void)
{
	uint8_t tmp;

	do
	{
		ctlwizchip(CW_GET_PHYLINK, (void*) &tmp);
	}while((tmp == PHY_LINK_OFF));	// && !BitTimeOverW5500Check);

	#ifdef __MAIN_DEBUG__
	printf(">> GSTECH_PHY_LINK_STATUS_CHECK - %d\r\n", PHY_LINK_OFF);
	#endif
}

typedef  void (*pFunction)(void);
typedef __IO uint32_t  vu32;

void GSTECH_GSTECH_APPLICATION_CODE_JUMP(void)
{
	uint16 i;
	pFunction Jump_To_Application;
	uint32 JumpAddress;
	for (i = 0; i < 1000; i++);//wait for a while
	JumpAddress = *(vu32*)(ApplicationAddress + 4);

	Jump_To_Application = (pFunction)JumpAddress;
	__disable_irq();
	__set_MSP(*(__IO uint32_t*)ApplicationAddress);
	Jump_To_Application();
}

BYTE GSTECH_GET_VERSION(char *Version)
{
	uint8_t Temp, ReadVersion;

	for(Temp = 0; Temp < 4; Temp++)
	{
		if(Version[Temp] == 'v')
		{
			Temp++;
			ReadVersion = (Version[Temp] - 0x30) * 10;
		}
		else if(Version[Temp] == '.')
		{
			Temp++;
			ReadVersion += Version[Temp] - 0x30;
		}
	}

	return ReadVersion;
}


//****************************************************************************************************************************
//
// FUNCTION       : void GSTECH_DEVICE_SETUP_MESSAGE_OUTPUT_PROCESS(void)
//
// USAGE          : MQTT Message Receive & Send Common Process
//
// INPUT        :   None
//
// USED			:   None
//				
// OUTPUT       :   None
//
//****************************************************************************************************************************
void GSTECH_DEVICE_SETUP_MESSAGE_OUTPUT_PROCESS(void)
{
	char Tempchar[12];

	#ifdef __MAIN_DEBUG__
   	printf("\r\nGSTECH_DEVICE_SETUP_MESSAGE_OUTPUT_PROCESS\r\n");
	#endif

	memset(Board_out_Format,0,strlen(Board_out_Format));  
    //========================================================================
	sprintf(Board_out_Format,"%s","{ \"type\": \"RESPONSE_INFO\",");  
    
  	//---------------------------------------------------
	strcat(Board_out_Format,"\"deviceId\": \"");  
	strncat(Board_out_Format,MACidbuf,6);	// 5C5F9F
	strcat(Board_out_Format,"\",");
    
  	//---------------------------------------------------
	strcat(Board_out_Format,"\"dhcp\": \"");
	if(gstech_Device_DHCP == NETINFO_DHCP)
		strcat(Board_out_Format,"True\", ");
	else
		strcat(Board_out_Format,"False\", ");

  	//---------------------------------------------------
	strcat(Board_out_Format,"\"ip\": \"");
	sprintf(Tempchar, "%d.%d.%d.%d\", ", gstech_Device_IP[0],gstech_Device_IP[1],gstech_Device_IP[2],gstech_Device_IP[3]);
	strcat(Board_out_Format,Tempchar);
    
  	//---------------------------------------------------
	strcat(Board_out_Format,"\"subnet\": \"");
	sprintf(Tempchar, "%d.%d.%d.%d\",", gstech_Device_SN[0],gstech_Device_SN[1],gstech_Device_SN[2],gstech_Device_SN[3]);
	strcat(Board_out_Format,Tempchar);
    
  	//---------------------------------------------------
	strcat(Board_out_Format,"\"gateway\": \"");
	sprintf(Tempchar, "%d.%d.%d.%d\", ", gstech_Device_GW[0],gstech_Device_GW[1],gstech_Device_GW[2],gstech_Device_GW[3]);
	strcat(Board_out_Format,Tempchar);
    
  	//---------------------------------------------------
	strcat(Board_out_Format,"\"macAddr\": \"");
	sprintf(Tempchar, "%02X-%02X-%02X-%02X-%02X-%02X\",", gstech_Device_MAC[0],gstech_Device_MAC[1],gstech_Device_MAC[2],gstech_Device_MAC[3],gstech_Device_MAC[4],gstech_Device_MAC[5]);
	strcat(Board_out_Format,Tempchar);

  	//---------------------------------------------------
	strcat(Board_out_Format,"\"mqttIp\": \"");
	sprintf(Tempchar, "%d.%d.%d.%d\",", gstech_Mqtt_IP[0],gstech_Mqtt_IP[1],gstech_Mqtt_IP[2],gstech_Mqtt_IP[3]);
	strcat(Board_out_Format,Tempchar);

  	//---------------------------------------------------
	strcat(Board_out_Format,"\"mqttPort\": \"");
	sprintf(Tempchar, "%d\",", gstech_Mqtt_PORT);
	strcat(Board_out_Format,Tempchar);
    
  	//---------------------------------------------------
	strcat(Board_out_Format,"\"mqttId\": \"");
	sprintf(Tempchar, "%s\",", gstech_Mqtt_UserName);
	strcat(Board_out_Format,Tempchar);
    
  	//---------------------------------------------------
	strcat(Board_out_Format,"\"mqttPw\": \"");
	sprintf(Tempchar, "%s\" ", gstech_Mqtt_PW);
	strcat(Board_out_Format,Tempchar);
    
  	//---------------------------------------------------
	strcat(Board_out_Format,"\"updateIp\": \"");
	sprintf(Tempchar, "%d.%d.%d.%d\",", gstech_Update_IP[0],gstech_Update_IP[1],gstech_Update_IP[2],gstech_Update_IP[3]);
	strcat(Board_out_Format,Tempchar);
    
  	//---------------------------------------------------
	strcat(Board_out_Format,"\"updatePort\": \"");
	sprintf(Tempchar, "%d\",", gstech_Update_PORT);
	strcat(Board_out_Format,Tempchar);
    
  	//---------------------------------------------------
	strcat(Board_out_Format,"\"statusCycle\": \"");
	if(gstech_StatusCycle)
		strcat(Board_out_Format,"True\",");
	else
		strcat(Board_out_Format,"False\",");
    
  	//---------------------------------------------------
	strcat(Board_out_Format,"\"period\": \"");
	sprintf(Tempchar, "%d\" ", gstech_Period);
	strcat(Board_out_Format,Tempchar);
	strcat(Board_out_Format,"}");
	strcat(Board_out_Format,"\0");

    //========================================================================
 	printf("Board_out_Format =\r\n%s\r\n",Board_out_Format);

	for(gstech_OutputCount = 0; gstech_OutputCount < DATA_BUF_SIZE; gstech_OutputCount++)
	{
   		//printf("%c", Board_out_Format[gstech_OutputCount]);
		if(Board_out_Format[gstech_OutputCount] == '}')
			break;
	}
	++gstech_OutputCount;
   	printf("\r\nBoard_out_Format gstech_OutputCount = %d\r\n", gstech_OutputCount);
}

//****************************************************************************************************************************
//
// FUNCTION       : void GSTECH_W5500_NETWORK_INIT(WORD Delay)
//
// USAGE          : Initialize W5500 Network Chipset
//
// INPUT          : None
//
// OUTPUT         : None
//
//****************************************************************************************************************************
void GSTECH_W5500_NETWORK_INIT(void)
{
	uint8_t tmpstr[6] = {0,};
	uint8_t memsize[2][8] = { { 2, 2, 2, 2, 2, 2, 2, 2 }, { 2, 2, 2, 2, 2, 2, 2, 2 } };
    
	/* wizchip initialize*/
	if (ctlwizchip(CW_INIT_WIZCHIP, (void*) memsize) == -1) 
	{
		printf("WIZCHIP Initialized fail.\r\n");
		while (1);
	}
   
	#ifdef __MAIN_W5500_DEBUG__
	printf("WIZCHIP Initialized Done ........\r\n");
	#endif
    
    ctlnetwork(CN_SET_NETINFO, (void*)&gWIZNETINFO);
    
	// Display Network Information
	ctlwizchip(CW_GET_ID,(void*)tmpstr);
    
	#ifdef __MAIN_W5500_DEBUG__
	if(gWIZNETINFO.dhcp == NETINFO_DHCP) 
		printf("\r\n===== %s NET CONF : DHCP =====\r\n",(char*)tmpstr);
	else 
		printf("\r\n===== %s NET CONF : Static =====\r\n",(char*)tmpstr);

	printf("Network - MAC: %02X:%02X:%02X:%02X:%02X:%02X\r\n",gstech_Device_MAC[0],gstech_Device_MAC[1],gstech_Device_MAC[2],gstech_Device_MAC[3],gstech_Device_MAC[4],gstech_Device_MAC[5]);
	printf("================================\r\n");
	#endif
}

////****************************************************************************************************************************
////
//// FUNCTION       : void GSTECH_DELAY_1mS(WORD Delay)
////
//// USAGE          : System Timer 1ms * xx Count Delay
////
//// INPUT          : WORD Value
////
//// OUTPUT         : None
////
////****************************************************************************************************************************
//void GSTECH_DELAY_1mS(WORD Delay)
//{
//	for( ; Delay !=	_CLR; Delay-- )
//	{
//		Bit1mS = _CLR;
//		do
//		{
//			BitTimeToggle = ~BitTimeToggle;
//	  		//HAL_IWDG_Refresh(&hiwdg);
//		}
//		while(Bit1mS == _CLR);
//	}
//}

//****************************************************************************************************************************
//
// FUNCTION       : void GSTECH_INITIALIZE_GLOBAL_RAM(void)
//
// USAGE          : Initialize Global RAM
//
// INPUT          : None
//
// OUTPUT         : None
//
//****************************************************************************************************************************
void GSTECH_INITIALIZE_GLOBAL_RAM(void)
{
	TIMERFLAGSbits.BitWord 		= _CLR;
	USARTFLAGSbits.BitWord 		= _CLR;
	GLOBAL1FLAGSbits.BitWord 	= _CLR;
	GLOBAL2FLAGSbits.BitWord 	= _CLR;
	GLOBAL3FLAGSbits.BitWord 	= _CLR;
	PORTDET1FLAGSbits.BitWord 	= _CLR;
	PORTDET2FLAGSbits.BitWord 	= _CLR;
	PORTCTRL1FLAGSbits.BitWord 	= _CLR;
	PORTCTRL2FLAGSbits.BitWord 	= _CLR;
	EEPromFLAGSbits.BitWord 	= _CLR;

  	//===========================================================================
	gstech_Device_IP[0] = 0;//192;
	gstech_Device_IP[1] = 0;//168;
	gstech_Device_IP[2] = 0;//  0;
	gstech_Device_IP[3] = 0;//255;

	//---------------------------------------------------------------------------
 	gstech_Device_SN[0] = 0;//255;
	gstech_Device_SN[1] = 0;//255;
	gstech_Device_SN[2] = 0;//255;
	gstech_Device_SN[3] = 0;//  0;

	//---------------------------------------------------------------------------
 	gstech_Device_GW[0] = 0;//192;
	gstech_Device_GW[1] = 0;//168;
	gstech_Device_GW[2] = 0;//  0;
	gstech_Device_GW[3] = 0;//  1;

	//---------------------------------------------------------------------------
 	gstech_Device_DNS[0] =  0;
	gstech_Device_DNS[1] =  0;
	gstech_Device_DNS[2] =  0;
	gstech_Device_DNS[3] =  0;

	//---------------------------------------------------------------------------
 	gstech_Device_MAC[0] = 0xFF;
	gstech_Device_MAC[1] = 0xFF;
	gstech_Device_MAC[2] = 0xFF;
	gstech_Device_MAC[3] = 0xFF;
	gstech_Device_MAC[4] = 0xFF;
	gstech_Device_MAC[5] = 0xFF;

	//---------------------------------------------------------------------------
	gstech_Device_DHCP = NETINFO_DHCP;
	gstech_Device_PORT = PORT_TCPS;

	//===========================================================================
	BitPHYStatuscheckflag = _SET;
	BitEnableGetVersionFile = _SET;
	BitEnableGetFirmwareFile = _SET;

	gstech_Mqtt_IP[0] = gstech_Update_IP[0] = SERVER_IP[0];
	gstech_Mqtt_IP[1] = gstech_Update_IP[1] = SERVER_IP[1];
	gstech_Mqtt_IP[2] = gstech_Update_IP[2] = SERVER_IP[2];
	gstech_Mqtt_IP[3] = gstech_Update_IP[3] = SERVER_IP[3];
	gstech_Mqtt_PORT = MQTT_PORT;
	gstech_Update_PORT = SERVER_PORT;
	local_port = PORT_TCPS;

  	//===========================================================================
	USART2_TX_ENABLE_ON();

	SD_CARD_CS_OFF();
	FLASH_CS_OFF();
	FLASH_WP_ON();
	
	W5500_RESET_HIGH();
	W5500_CS_HIGH();

	RELAY_PORT_1_OFF();
	RELAY_PORT_2_OFF();
	RELAY_PORT_3_OFF();
	RELAY_PORT_4_OFF();
	RELAY_PORT_5_OFF();
	RELAY_PORT_6_OFF();
	RELAY_PORT_7_OFF();
	RELAY_PORT_8_OFF();

	CTRL_PORT_1_OFF();
	CTRL_PORT_2_OFF();

	STATUS_LED_1_OFF();
	STATUS_LED_2_OFF();

	DEBUG_OFF();
}

//****************************************************************************************************************************
//
// FUNCTION       : int main(void)
//
// USAGE          : The application entry point.
//
// INPUT          : None
//
// OUTPUT         : None
//
//****************************************************************************************************************************
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	char TempBF[30];
   	uint16_t len = 0, i;
   /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_RTC_Init();
  MX_SPI1_Init();
  MX_SPI2_Init();
  MX_I2C2_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */

	__enable_irq();
	HAL_UART_Receive_IT(&huart1, &gstech_Com1ReceiveBuffer, 1);

	printf("\r\n\r\n===============================================\r\n");
	printf("RCU Board Boot System Start .........");
	printf("\r\n===============================================\r\n\r\n");

	GSTECH_INITIALIZE_GLOBAL_RAM();

	GSTECH_FLASH_CHECK_BLANK();
 
  	W5500_RESET_LOW();
  	HAL_Delay(1);
  	W5500_RESET_HIGH();

   	//========================================================================
	//print_network_information();
	GSTECH_W5500_NETWORK_INIT();

    //========================================================================
	sprintf(MACidbuf,"%02X%02X%02X",gstech_Device_MAC[3],gstech_Device_MAC[4],gstech_Device_MAC[5]);  
	strcat(gstech_topic,MACidbuf);
	strcat(gstech_topic,"/in/#");
    
    //========================================================================
	strcat(topic_Output,MACidbuf);
	strcat(topic_Output,"/out/status");
    
    //========================================================================
 	printf("gstech_topic: %s\r\n",gstech_topic);
 	printf("topic_Output: %s\r\n",topic_Output);

    //========================================================================
	GSTECH_DEVICE_SETUP_MESSAGE_OUTPUT_PROCESS();

    //========================================================================
	sprintf(UPDATE_IP,"%d.%d.%d.%d",gstech_Update_IP[0],gstech_Update_IP[1],gstech_Update_IP[2],gstech_Update_IP[3]);  
    
    //========================================================================
	memset(POST_UPDATE_MSG,0,strlen(POST_UPDATE_MSG));  
	memset(TempBF,0,strlen(TempBF));  
	sprintf(TempBF,"%d.%d.%d.%d:%d\r\n",(uint8_t)gstech_Update_IP[0],(uint8_t)gstech_Update_IP[1],(uint8_t)gstech_Update_IP[2],(uint8_t)gstech_Update_IP[3],(uint8_t)gstech_Update_PORT);  
 	
	sprintf(POST_UPDATE_MSG,"%s","GET /firmware/RCU_SYSTEM_MQTT.binary HTTP/1.1\r\n");  
	strcat(POST_UPDATE_MSG,"Host:");
	strcat(POST_UPDATE_MSG,TempBF);
	strcat(POST_UPDATE_MSG,"Accept-Range: bytes\r\n");
	strcat(POST_UPDATE_MSG,"Pragma:no-cache\r\n");
	strcat(POST_UPDATE_MSG,"Connection:keep-alive\r\n");
	strcat(POST_UPDATE_MSG,"\r\n");
 	
	printf("POST_UPDATE_MSG = \r\n{%s}\r\n",POST_UPDATE_MSG);

    //========================================================================
    //========================================================================
	/* DHCP client Initialization */
	printf(">> DHCP DHCP_init Start ....... \r\n\r\n");  	
	if(gstech_Device_DHCP == NETINFO_DHCP)
	{
		DHCP_init(SOCK_DHCP, gDATABUF);
    
		BitEnableDHCPFunction = _SET; 	// flag for running DHCP user's code
    
		while(BitEnableDHCPFunction)
		{
	   		/* PHY Status checker: Check every 'SEC_PHYSTATUS_CHECK' seconds */
			if(BitPHYStatuscheckflag)
			{
				BitPHYStatuscheckflag = _CLR;
				GSTECH_PHY_LINK_STATUS_CHECK();
			}
    
			/* DHCP */
			/* DHCP IP allocation and check the DHCP lease time (for IP renewal) */
			switch(DHCP_run())
			{
				case DHCP_IP_LEASED:
					BitEnableDHCPFunction = _CLR;
					printf(">> DHCP DHCP_init Done ......\r\n");
					break;
				case DHCP_FAILED:
					my_dhcp_retry++;
					if(my_dhcp_retry > MY_MAX_DHCP_RETRY)
					{
						gWIZNETINFO.dhcp = gstech_Device_DHCP = NETINFO_STATIC;
						DHCP_stop();      // if restart, recall DHCP_init()
						printf(">> DHCP %d Failed\r\n", my_dhcp_retry);
						ctlnetwork(CN_SET_NETINFO, (void*) &gWIZNETINFO);
						my_dhcp_retry = 0;
					}
					break;
				case DHCP_IP_ASSIGN:
				case DHCP_IP_CHANGED:
				default:
					break;
			}
    
			if(Bit1000mS)
			{
				printf("DHCP Get Waitting....... \r\n\r\n");
				Bit1000mS = _CLR;  	
			}
		}
 	}
	printf("DHCP Get Done ....... \r\n\r\n");  	
    
    //========================================================================
	{
		//================================================================================
		/* HTTP client Version File Get Initialization */
		gstech_HTTPTimeOutCount = _TIME_5000MS_VALUE;
		BitTimeOverHTTPCheck = _CLR;
  		gstech_Server_FW_Version = _CLR;
 		printf("HTTP Check Start Time MilliTimer[%ld] \r\n\r\n", MilliTimer);
    	
   		httpc_init(SOCK_VERSION, gstech_Update_IP, gstech_Update_PORT, g_send_buf, g_recv_buf);
    	
		BitEnableGetVersionFile = _SET;
    
		while(BitEnableGetVersionFile)
		{
			httpc_connection_handler();
    
			if(httpc_isSockOpen)
				httpc_connect();
    	    
  			//----------------------------------------------------------------------------
			if(httpc_isConnected && !BitTimeOverHTTPCheck)
			{
			  	if(!flag_sent_http_request)
			  	{
					// Send: HTTP request
					request.method = (uint8_t *)HTTP_GET;
					request.uri = (uint8_t *)VERSION_URI;
					request.host = (uint8_t *)UPDATE_IP;
    
				  	httpc_send(&request, g_recv_buf, g_send_buf, 0);
    
					flag_sent_http_request = ENABLE;
			  	}
    	    
  				//----------------------------------------------------------------------------
				// Recv: HTTP response
				if(httpc_isReceived > 0)
				{
					len = httpc_recv(g_recv_buf, httpc_isReceived);
						
					printf(" >> HTTP Response - Received len: %d\r\n", len);
					printf("======================================================\r\n");
					for(i = 0; i < len; i++) 
					{
		  				//HAL_IWDG_Refresh(&hiwdg);
						printf("%c", g_recv_buf[i]);
					}
					printf("\r\n");
					printf("======================================================\r\n");
    	    
					{
						char Gstech_version[4];
						char ptr[100];
						int Start, End;//, Compare;
						uint16_t content_len=0;
    	    
						Start = strcspn((char *)g_recv_buf, "{");
						End = strcspn((char *)g_recv_buf, "}");
					 	++End;
					 	printf("Start=%d, End=%d , End - Start =%d\r\n",Start,End, End-Start);
						content_len = End - Start;
						memset(ptr,0x00,100);
						strncpy(&ptr[0], (char *)(g_recv_buf+Start), content_len);
					 	printf("%s\r\n", (char *)ptr);
		   				parse_command((char *)ptr,"version", (char*) Gstech_version);
						printf("Gstech_version=%s , size=%d\r\n", Gstech_version, sizeof(Gstech_version));
    	    
						gstech_Server_FW_Version = (WORD)GSTECH_GET_VERSION(Gstech_version);
						//printf("\r\ngstech_Server_FW_Version[v%d.%d] \r\n", gstech_Server_FW_Version/10, gstech_Server_FW_Version%10);
					}
					BitEnableGetVersionFile = _CLR;
				}
			}
    
			if(BitTimeOverHTTPCheck)
			{
				printf("HTTPC Check TimeOut Exit ....... \r\n\r\n");
				BitEnableGetVersionFile = _CLR;
			}				
		}
      	
 		printf("HTTP Check End Time MilliTimer[%ld] \r\n\r\n", MilliTimer);
		//flashVersion = VersionAddr;
		if(!BitTimeOverHTTPCheck)		//httpc_isConnected == HTTPC_TRUE)
		{
			gstech_Flash_FW_Version = (uint16_t)(*(__IO uint32_t*)VersionAddr);
			gstech_Application_Data = (uint16_t)(*(__IO uint32_t*)ApplicationAddress);
 			printf("gstech_Application_start_Data[0x%4x] \r\n\r\n", gstech_Application_Data);
    
			printf("gstech_Flash_FW_Version[v%d.%d] \r\n", gstech_Flash_FW_Version/10, gstech_Flash_FW_Version%10);
			printf("gstech_Server_FW_Version[v%d.%d] \r\n\r\n", gstech_Server_FW_Version/10, gstech_Server_FW_Version%10);
   		
			//================================================================================
			//if((gstech_Flash_FW_Version != gstech_Server_FW_Version) || (gstech_Flash_FW_Version >= 0x7FFF))
			if((((gstech_Server_FW_Version < 10) || (gstech_Server_FW_Version > 99)) && (gstech_Application_Data == 0xFFFF)) ||
			   (((gstech_Server_FW_Version >= 10) && (gstech_Server_FW_Version <= 99)) && (gstech_Flash_FW_Version != gstech_Server_FW_Version)))
			{
 				printf("Application Code Download Start BitEnableGetFirmwareFile[%d] ....\r\n\r\n", (BYTE)BitEnableGetFirmwareFile);
				/* HTTP client Firmware File Get Initialization */
			    
				//if(httpc_isConnected == HTTPC_TRUE)
			    	httpc_init(SOCK_VERSION, gstech_Update_IP, gstech_Update_PORT, g_send_buf, g_recv_buf);
				//else
			    //	httpc_init(SOCK_VERSION, SERVER_IP, SERVER_PORT, g_send_buf, g_recv_buf);
				BitFirmwareFileNotFined = _CLR;				    
 				HAL_GPIO_WritePin(GPIOC,GPIO_PIN_7, GPIO_PIN_RESET);
 				HAL_GPIO_WritePin(GPIOC,GPIO_PIN_8, GPIO_PIN_RESET);

  				gstech_Application_Count = _CLR;
  				while(BitEnableGetFirmwareFile && !BitFirmwareFileNotFined)
				{
			 		//HAL_IWDG_Refresh(&hiwdg);
					GSTECH_MQTT_APPLICATION_UPDATE_PROCESS(W5500_UPDATE);
				}
			}
			else if(gstech_Application_Data != 0xFFFF)
			{		
				BitEnableGetFirmwareFile = _CLR;
				printf("Jump to Application Program [Application Download Skip]......\r\n\r\n");
 			}
		}
	}

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  	while(_SET)
 	{ 
 		//if(BitEEPSaveDone)
		//	GSTECH_EEPROM_SAVE_ALL();
  
   		if(!BitEnableGetFirmwareFile)	// Firmware DownLoad Done....
   			GSTECH_GSTECH_APPLICATION_CODE_JUMP();
 
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  	}
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSI|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_RTC;
  PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSI;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
