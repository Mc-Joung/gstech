/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "i2c.h"
#include "iwdg.h"
#include "rtc.h"
#include "spi.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
//****************************************************************************************************************************
//  I N C L U D E    F I L E S
//****************************************************************************************************************************
#include <stdio.h>
#include <string.h>    // strcat �Լ��� ����� ��� ����
#include <stdarg.h>
#include <math.h>
#include "stm32f1xx_hal.h"
#include "define.h"
#include "extern.h"
#include "w5500.h"
#include "wizchip_conf.h"
#include "loopback.h"
#include "mqtt_interface.h"
#include "MQTTClient.h"
#include "cJSON.h"
#include "msg_command.h"
#include "dhcp.h"
#include "httpClient.h"
#include "sntp.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/*
{
"type": "ON/OFF", 
"idx": "1",
"status": "ON", 
"time": "0",
 "passwd": "0"
} 

{
"type": "DELAY", 
"idx": "1",
"status": "ON", 
"time": "5",
 "passwd": "0"
} 

{
"type": "ALL_ON/OFF", 
"idx": "0",
"status": "ON", 
"time": "5",
 "passwd": "0"
} 

{
"type": "UPDATE", 
"idx": "0",
"status": "0", 
"time": "0",
 "passwd": "0"
} 

*/

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

//==============================================================================
unsigned char buf[BUFFER_SIZE];
Network n;
Client c;
uint8_t gDATABUF[DATA_BUF_SIZE];
//u_short gstech_MacAddID;

unsigned char ReadBuffer[BUFFER_SIZE] = {};
BYTE targetIP[4];
WORD targetPort;
BYTE UpdateIP[4];
WORD UpdatePort;

//==============================================================================
uint16 len=0;
uint8_t msgbuf[BUFFER_SIZE];
uint8_t SUB_FLAG = 1;
char ser_cmd[BUFFER_SIZE];

char MACidbuf[6];  
char Board_out_Format[DATA_BUF_SIZE];
BYTE RelayStableCount[_MAX_RELAY_COUNT+1];
uint32 SocketTimeoutCount;

//==============================================================================
unsigned char dup;
unsigned char retained;
unsigned short mssageid;
int payloadlen_in;
unsigned char* payload_in;
MQTTString receivedTopic;
char new_topic[30];

int rc=0;
uint16 anyport = PORT_TCPS;
MQTTPacket_connectData data = MQTTPacket_connectData_initializer; //MQTT declear package
uint8_t ntp_server[4] = {128, 138, 141, 172};	// time.nist.gov
//uint8_t ntp_server[4] = {211, 233, 84, 186};	// kr.pool.ntp.org

//==============================================================================
///////////////////////////////////
// Default Network Configuration //
///////////////////////////////////
wiz_NetInfo gWIZNETINFO = { .mac = {0x00, 0x08, 0xdc, 0xab, 0xcd, 0xef},
                            .ip = {192, 168, 1, 100},
                            .sn = {255, 255, 255, 0},
                            .gw = {192, 168, 1, 1},
                            .dns = {0, 0, 0, 0},
                            .dhcp = NETINFO_DHCP };

char gstech_topic[30] = "/gstech/";	//"/gstech/1888/#";
char topic_Output[30] = "/gstech/";	//{"/gstech/566/out/status"};
char targetusername[6] = "gstech";
char targetpassword[6] = "gs7011";

uint8_t flag_sent_http_request = DISABLE;
uint8_t data_buf [DATA_BUF_SIZE]; // TX Buffer for applications
/////////////////////
// PHYStatus check //
/////////////////////
//#define SEC_PHYSTATUS_CHECK 		1		// sec

////////////////
// DHCP client//
////////////////
#define MY_MAX_DHCP_RETRY			2
uint8_t my_dhcp_retry = 0;

uint16 gstech_ServerCheckTimeCount = _CLR;

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
extern int MQTTSerialize_zero(unsigned char* buf, int buflen, unsigned char packettype);

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void GSTECH_WRITE_VER_TO_FLASH(WORD Version);//flash
void GSTECH_NETWORK_SET_COMMON_PROCESS(void);
void GSTECH_DELAY_1mS(WORD Delay);
void GSTECH_MQTT_MESSAGE_OUTPUT_PROCESS(void);
void GSTECH_TIMER_10MS_PROCESS(void);
void GSTECH_TIMER_25MS_PROCESS(void);
void GSTECH_TIMER_50MS_PROCESS(void);
void GSTECH_TIMER_100MS_PROCESS(void);
void GSTECH_TIMER_250MS_PROCESS(void);
void GSTECH_TIMER_500MS_PROCESS(void);
void GSTECH_TIMER_1000MS_PROCESS(void);
void GSTECH_TIMER_XXXXMS_PROCESS(void);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

//****************************************************************************************************************************
//  G L O B A L   F U N C T I O N    P R O T O T Y P E S
//****************************************************************************************************************************
int _write(int file, BYTE* p, int len)
{
	HAL_UART_Transmit(&huart1, p, len, 50);
	return len;
}

//****************************************************************************************************************************
//  U S E R 	C O D E
//****************************************************************************************************************************

//****************************************************************************************************************************
//
// FUNCTION       : void GSTECH_BOOT_CODE_JUMP(void)
//
// USAGE          : Code Jump Boot Routine Process
//
// INPUT        :   None
//
// USED			:   None
//				
// OUTPUT       :   None
//
//****************************************************************************************************************************
//typedef  void (*pFunction)(void);
//typedef __IO uint32_t  vu32;

void GSTECH_BOOT_CODE_JUMP(void)
{
   	printf("\r\n Main Routine Jump_To_Application........\r\n");
 	BitJumpBootCodeStart = _CLR;

	MX_IWDG_Init();

   	//if(__HAL_RCC_GET_FLAG(RCC_FLAG_WWDGRST) == SET)
  	{
	  	__HAL_RCC_CLEAR_RESET_FLAGS();
  	}
	while(_SET);
}

//****************************************************************************************************************************
//
// FUNCTION       : void Net_Conf(void), void messageArrived(MessageData* md)
//
// USAGE          : Dummy
//
// INPUT        :   None
//
// USED			:   None
//				
// OUTPUT       :   None
//
//****************************************************************************************************************************
//void Net_Conf(void)
//{
//	/* wizchip netconf */
//	ctlnetwork(CN_SET_NETINFO, (void*) &gWIZNETINFO);
//}

void messageArrived(MessageData* md)
{
}

void GSTECH_NETWORK_SET_COMMON_PROCESS(void)
{
	/*Set network informations*/
	wizchip_setnetinfo(&gWIZNETINFO);
    
	n.my_socket = SOCK_MQTT;
	NewNetwork(&n);

	data.willFlag = 0; //data setting 
	data.MQTTVersion = 4;
	data.clientID.cstring = topic_Output;
	data.username.cstring = gstech_Mqtt_UserName;
	data.password.cstring = gstech_Mqtt_PW;
    
	data.keepAliveInterval = 5;
	data.cleansession = 1;
}

//****************************************************************************************************************************
//
// FUNCTION       : void GSTECH_MAKE_PUB_MSG(char *Topic,unsigned char*msgbuf,int buflen,char*msg)
//
// USAGE          : Make Message Routine Process
//
// INPUT        :   None
//
// USED			:   None
//				
// OUTPUT       :   None
//
//****************************************************************************************************************************
void GSTECH_MAKE_PUB_MSG(char *Topic,unsigned char*msgbuf,int buflen,char*msg)
{
	unsigned char pub_topic[DATA_BUF_SIZE];
	int msglen = strlen(msg);
	MQTTString topicString = MQTTString_initializer;

	memset(pub_topic,0,sizeof(pub_topic));
	memcpy(pub_topic,Topic,strlen(Topic));
	topicString.cstring = (char*)pub_topic;

 	#ifdef __MAIN_DEBUG__
	//printf("GSTECH_MAKE_PUB_MSG pub_topic = %s\r\n",pub_topic);
 	//printf("GSTECH_MAKE_PUB_MSG msg = %s\r\n",msg);
	#endif

	MQTTSerialize_publish(msgbuf, buflen, 0, 0, 2, 0, topicString, (unsigned char*)msg, msglen); 

 	#ifdef __MAIN_DEBUG__
  	// printf("GSTECH_MAKE_PUB_MSG len = %d\r\n", len);	
	#endif
}

//****************************************************************************************************************************
//
// FUNCTION       : void GSTECH_PHY_LINK_STATUS_CHECK(void)
//
// USAGE          : PHY Link Status Check Process
//
// INPUT        :   None
//
// USED			:   None
//				
// OUTPUT       :   None
//
//****************************************************************************************************************************
void GSTECH_PHY_LINK_STATUS_CHECK(void)
{
	uint8_t tmp;

	do
	{
		ctlwizchip(CW_GET_PHYLINK, (void*) &tmp);
	}while((tmp == PHY_LINK_OFF) && !BitTimeOverW5500Check);

	#ifdef __MAIN_DEBUG__
	printf(">> GSTECH_PHY_LINK_STATUS_CHECK - %d\r\n", PHY_LINK_OFF);
	#endif
}

////****************************************************************************************************************************
////
//// FUNCTION       : void GSTECH_WRITE_VER_TO_FLASH(WORD Version)
////
//// USAGE          :Firmware Version Write to Flash Memory Process
////
//// INPUT        :   None
////
//// USED			:   None
////				
//// OUTPUT       :   None
////
////****************************************************************************************************************************
//void GSTECH_WRITE_VER_TO_FLASH(WORD Version)//flash
//{
// 	FLASH_EraseInitTypeDef EraseInitStruct;
//	//volatile HAL_StatusTypeDef status_erase;
//	uint32_t PageError;
//	uint32_t flashVersion = VersionAddr;
//
//	/* Unock the Flash to enable the flash control register access *************/
//	while(HAL_FLASH_Unlock()!=HAL_OK)
//	{
//		while(HAL_FLASH_Lock()!=HAL_OK);//Weird fix attempt
//	}
//
//	/* Allow Access to option bytes sector */
//	while(HAL_FLASH_OB_Unlock()!=HAL_OK)
//	{
//		while(HAL_FLASH_OB_Lock()!=HAL_OK);//Weird fix attempt
//	}
//
//	/* Fill EraseInit structure*/
//	EraseInitStruct.TypeErase = FLASH_TYPEERASE_PAGES;
//	EraseInitStruct.PageAddress = flashVersion;
//	EraseInitStruct.NbPages = 1;
// 
//	HAL_FLASHEx_Erase(&EraseInitStruct, &PageError);
//   
//	HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, flashVersion, Version);
//  	HAL_FLASH_Lock();
//
//    #ifdef __MAIN_DEBUG__
//	printf("Write flashVersion[0x%lx] = [v%d.%d] \r\n", flashVersion, (uint8_t)(((uint16_t)(*(__IO uint32_t*)flashVersion))/10), (uint8_t)(((uint16_t)(*(__IO uint32_t*)flashVersion))%10));
//	//("Write MQTT gstech_Read_FW_Version [0x%x] \r\n", gstech_Read_FW_Version);
// 	#endif
//}


//****************************************************************************************************************************
//
// FUNCTION       : void ETEM_DELAY_1mS(WORD Delay)
//
// USAGE          : System Timer 1ms * xx Count Delay
//
// INPUT          : WORD Value
//
// OUTPUT         : None
//
//****************************************************************************************************************************
BYTE GSTECH_MQTT_RELAY_AC_CHECK_PROCESS(BYTE RelayIndex)
{
	BYTE TempCount;

	for(TempCount = _CLR; TempCount < 20; TempCount++ )
	{
		Bit1mS = _CLR;
		while(Bit1mS == _CLR);

		switch(RelayIndex)
		{
			case 1: 
				if(PORT_1_DETECT()) 
					++RelayStableCount[RelayIndex];
				break;
			case 2: 
				if(PORT_2_DETECT()) 
					++RelayStableCount[RelayIndex];
				break;
			case 3: 
				if(PORT_3_DETECT()) 
					++RelayStableCount[RelayIndex];
				break;
			case 4: 
				if(PORT_4_DETECT()) 
					++RelayStableCount[RelayIndex];
				break;
			case 5: 
				if(PORT_5_DETECT()) 
					++RelayStableCount[RelayIndex];
				break;
			case 6: 
				if(PORT_6_DETECT()) 
					++RelayStableCount[RelayIndex];
				break;
			case 7: 
				if(PORT_7_DETECT()) 
					++RelayStableCount[RelayIndex];
				break;
			case 8: 
				if(PORT_8_DETECT()) 
					++RelayStableCount[RelayIndex];
				break;
			default: 
				break;
		}
	}

	if(RelayStableCount[RelayIndex] >= 3)
		return _SET;
	else
		return _CLR;
}
 
////****************************************************************************************************************************
////
//// FUNCTION       : BYTE GSTECH_MQTT_MICOM_PORT_GET_PROCESS(BYTE RelayIndex)
////
//// USAGE          : MQTT Message Realy Result Data Get Process
////
//// INPUT        :   None
////
//// USED			:   None
////				
//// OUTPUT       :   None
////
////****************************************************************************************************************************
//BYTE GSTECH_MQTT_MICOM_PORT_GET_PROCESS(BYTE RelayIndex)
//{
//	switch(RelayIndex)
//	{
//		case  1: return (BYTE)BitPort1DetStatus;
//		case  2: return (BYTE)BitPort2DetStatus;
//		case  3: return (BYTE)BitPort3DetStatus;
//		case  4: return (BYTE)BitPort4DetStatus;
//		case  5: return (BYTE)BitPort5DetStatus;
//		case  6: return (BYTE)BitPort6DetStatus;
//		case  7: return (BYTE)BitPort7DetStatus;
//		case  8: return (BYTE)BitPort8DetStatus;
//
//		//case  9: return (BYTE)BitPort9DetStatus;
//		//case 10: return (BYTE)BitPort10DetStatus;
//		//case 11: return (BYTE)BitPort11DetStatus;
//		//case 12: return (BYTE)BitPort12DetStatus;
//		//case 13: return (BYTE)BitPort13DetStatus;
//		//case 14: return (BYTE)BitPort14DetStatus;
//		//case 15: return (BYTE)BitPort15DetStatus;
//		//case 16: return (BYTE)BitPort16DetStatus;
//        //
//		//case 17: return (BYTE)BitPort17DetStatus;
//		//case 18: return (BYTE)BitPort18DetStatus;
//		//case 19: return (BYTE)BitPort19DetStatus;
//		//case 20: return (BYTE)BitPort20DetStatus;
//		//case 21: return (BYTE)BitPort21DetStatus;
//		//case 22: return (BYTE)BitPort22DetStatus;
//		//case 23: return (BYTE)BitPort23DetStatus;
//		//case 24: return (BYTE)BitPort24DetStatus;
//        //
//		//case 25: return (BYTE)BitPort25DetStatus;
//		//case 26: return (BYTE)BitPort26DetStatus;
//		//case 27: return (BYTE)BitPort27DetStatus;
//		//case 28: return (BYTE)BitPort28DetStatus;
//		//case 29: return (BYTE)BitPort29DetStatus;
//		//case 30: return (BYTE)BitPort30DetStatus;
//		//case 31: return (BYTE)BitPort31DetStatus;
//		//case 32: return (BYTE)BitPort32DetStatus;
//
//		default: return _CLR;
//	}
//}

//****************************************************************************************************************************
//
// FUNCTION       : BYTE GSTECH_MQTT_RELAY_RESULT_GET_PROCESS(BYTE RelayIndex)
//
// USAGE          : MQTT Message Realy Result Data Get Process
//
// INPUT        :   None
//
// USED			:   None
//				
// OUTPUT       :   None
//
//****************************************************************************************************************************
BYTE GSTECH_MQTT_RELAY_RESULT_GET_PROCESS(BYTE RelayIndex)
{
	BYTE TempBF;

	switch(RelayIndex)
	{
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:
		case 6:
		case 7:
		case 8: 
			TempBF = GSTECH_MQTT_RELAY_AC_CHECK_PROCESS(RelayIndex);
			#ifdef __MAIN_DEBUG__
   			printf("Input[%d] = %d\r\n", RelayIndex, TempBF);
			#endif
			return TempBF;

		//case  9: return (BYTE)BitPort9DetStatus;
		//case 10: return (BYTE)BitPort10DetStatus;
		//case 11: return (BYTE)BitPort11DetStatus;
		//case 12: return (BYTE)BitPort12DetStatus;
		//case 13: return (BYTE)BitPort13DetStatus;
		//case 14: return (BYTE)BitPort14DetStatus;
		//case 15: return (BYTE)BitPort15DetStatus;
		//case 16: return (BYTE)BitPort16DetStatus;
        //
		//case 17: return (BYTE)BitPort17DetStatus;
		//case 18: return (BYTE)BitPort18DetStatus;
		//case 19: return (BYTE)BitPort19DetStatus;
		//case 20: return (BYTE)BitPort20DetStatus;
		//case 21: return (BYTE)BitPort21DetStatus;
		//case 22: return (BYTE)BitPort22DetStatus;
		//case 23: return (BYTE)BitPort23DetStatus;
		//case 24: return (BYTE)BitPort24DetStatus;
        //
		//case 25: return (BYTE)BitPort25DetStatus;
		//case 26: return (BYTE)BitPort26DetStatus;
		//case 27: return (BYTE)BitPort27DetStatus;
		//case 28: return (BYTE)BitPort28DetStatus;
		//case 29: return (BYTE)BitPort29DetStatus;
		//case 30: return (BYTE)BitPort30DetStatus;
		//case 31: return (BYTE)BitPort31DetStatus;
		//case 32: return (BYTE)BitPort32DetStatus;

		default: return _CLR;
	}
}

//****************************************************************************************************************************
//
// FUNCTION       : void GSTECH_MQTT_RELAY_MESSAGE_DATA_ADD_PROCESS(void)
//
// USAGE          : MQTT Message Realy Data Common Process
//
// INPUT        :   None
//
// USED			:   None
//				
// OUTPUT       :   None
//
//****************************************************************************************************************************
void GSTECH_MQTT_RELAY_MESSAGE_DATA_ADD_PROCESS(BYTE EndIndex)
{
	WORD TempCtrl1BitMask = _WBIT00;
	//WORD TempCtrl2BitMask = _WBIT00;
	BYTE TempCount;
	char TempBF[2];

	//#ifdef __MAIN_DEBUG__
   	//printf("Read Relay Data[%d]\r\n", (BYTE)PORT_1_DETECT());
   	//printf("Read Relay Data[%d]\r\n", (BYTE)PORT_2_DETECT());
   	//printf("Read Relay Data[%d]\r\n", (BYTE)PORT_3_DETECT());
   	//printf("Read Relay Data[%d]\r\n", (BYTE)PORT_4_DETECT());
	//#endif

	memset(RelayStableCount,0,_MAX_RELAY_COUNT+1);  

	for(TempCount = 1; TempCount <= EndIndex; TempCount++)
	{ 	
  		//---------------------------------------------------
		strcat(Board_out_Format,"\{ \"idx\": \"");
		sprintf(TempBF,"%d",(TempCount));  
		strcat(Board_out_Format,TempBF);	// 1
		strcat(Board_out_Format,"\", \"status\": \"");

  		//---------------------------------------------------
		//if(TempCount <= 16)
		{
			if(PORTCTRL1FLAGSbits.BitWord & TempCtrl1BitMask)
				strcat(Board_out_Format,"ON");
			else
				strcat(Board_out_Format,"OFF");
			TempCtrl1BitMask <<= 1;
		}
		//else if(TempCount > 16)
		//{
		//	if(PORTCTRL2FLAGSbits.BitWord & TempCtrl2BitMask)
		//		strcat(Board_out_Format,"ON");
		//	else
		//		strcat(Board_out_Format,"OFF");
		//	TempCtrl2BitMask <<= 1;
		//}

  		//---------------------------------------------------
		strcat(Board_out_Format,"\", \"input\": \"");
		if(GSTECH_MQTT_RELAY_RESULT_GET_PROCESS(TempCount))
			strcat(Board_out_Format,"ON");
		else
			strcat(Board_out_Format,"OFF");

		//if(TempCount <= 16)
		//{
		//	if(PORTDET1FLAGSbits.BitWord & TempStatus1BitMask)
		//		strcat(Board_out_Format,"ON");
		//	else
		//		strcat(Board_out_Format,"OFF");
		//	TempStatus1BitMask <<= 1;
		//}
		//else if(TempCount > 16)
		//{
		//	if(PORTDET2FLAGSbits.BitWord & TempStatus2BitMask)
		//		strcat(Board_out_Format,"ON");
		//	else
		//		strcat(Board_out_Format,"OFF");
		//	TempStatus2BitMask <<= 1;
		//}

  		//---------------------------------------------------
		if(TempCount == EndIndex)
			strcat(Board_out_Format,"\"}");
		else
			strcat(Board_out_Format,"\"},");
	}
}

//****************************************************************************************************************************
//
// FUNCTION       : void GSTECH_MQTT_MESSAGE_OUTPUT_PROCESS(void)
//
// USAGE          : MQTT Message Receive & Send Common Process
//
// INPUT        :   None
//
// USED			:   None
//				
// OUTPUT       :   None
//
//****************************************************************************************************************************
void GSTECH_MQTT_MESSAGE_OUTPUT_PROCESS(void)
{
	char Temp;

	#ifdef __MAIN_DEBUG__
   	printf("\r\nGSTECH_MQTT_MESSAGE_OUTPUT_PROCESS\r\n");
	#endif
    //========================================================================
	memset(Board_out_Format,0,DATA_BUF_SIZE);  

    //========================================================================
	sprintf(Board_out_Format,"%s","{ \"ID\": \"");  
	sprintf(MACidbuf,"%02X%02X%02X",gstech_Device_MAC[3],gstech_Device_MAC[4],gstech_Device_MAC[5]);  
	strncat(Board_out_Format,MACidbuf,6);	// 5C5F9F
	strcat(Board_out_Format,"\",");
	strcat(Board_out_Format,"\"relays\"");
	strcat(Board_out_Format,":[");

    //========================================================================
  	GSTECH_MQTT_RELAY_MESSAGE_DATA_ADD_PROCESS(_MAX_RELAY_COUNT);

    //========================================================================
	strcat(Board_out_Format,"], ");
	strcat(Board_out_Format,"\"ver\": \"");
	sprintf(&Temp,"%d",((BYTE)(DEFAULT_VERSION)/10));  
	strcat(Board_out_Format,&Temp);	// 1.x
	strcat(Board_out_Format,".");
	sprintf(&Temp,"%d",((BYTE)(DEFAULT_VERSION)%10));  
	strcat(Board_out_Format,&Temp);	// x.0
	strcat(Board_out_Format,"\", ");

  	//---------------------------------------------------
	strcat(Board_out_Format,"\"temp\": \"");
	sprintf(&Temp,"%d",(gstech_CurrentTemperature/10));  
	strcat(Board_out_Format,&Temp);	// �µ�
	strcat(Board_out_Format,".");
	sprintf(&Temp,"%d",(gstech_CurrentTemperature%10));  
	strcat(Board_out_Format,&Temp);	// �µ�
	strcat(Board_out_Format,"\", ");

  	//---------------------------------------------------
	strcat(Board_out_Format,"\"datetime\": \"20");
	sprintf(&Temp,"%02d",RtcDate.Year);  
	strcat(Board_out_Format,&Temp);	// ��
	strcat(Board_out_Format,"-");

	sprintf(&Temp,"%02d",RtcDate.Month);  
	strcat(Board_out_Format,&Temp);	// ��
	strcat(Board_out_Format,"-");

	sprintf(&Temp,"%02d",RtcDate.Date);  
	strcat(Board_out_Format,&Temp);	// ��
	strcat(Board_out_Format," ");

  	//---------------------------------------------------
	sprintf(&Temp,"%02d",RtcTime.Hours);  
	strcat(Board_out_Format,&Temp);	// ��
	strcat(Board_out_Format,":");

	sprintf(&Temp,"%02d",RtcTime.Minutes);  
	strcat(Board_out_Format,&Temp);	// ��
	strcat(Board_out_Format,":");

	sprintf(&Temp,"%02d",RtcTime.Seconds);  
	strcat(Board_out_Format,&Temp);	// ��
	strcat(Board_out_Format,"\"}");

    //========================================================================
	#ifdef __MAIN_DEBUG__
 	printf("Board_out_Format =\r\n%s\r\n",Board_out_Format);
	#endif
 
	for(gstech_OutputCount = 0; gstech_OutputCount < DATA_BUF_SIZE; gstech_OutputCount++)
	{
		if(Board_out_Format[gstech_OutputCount] == '\0')
			break;
	}
	++gstech_OutputCount;

	#ifdef __MAIN_DEBUG__
   	printf("\r\nBoard_out_Format gstech_OutputCount = %d\r\n", gstech_OutputCount);
	#endif
    //========================================================================
	//memset(msgbuf,0,DATA_BUF_SIZE);

	GSTECH_MAKE_PUB_MSG(topic_Output, msgbuf, sizeof(msgbuf), Board_out_Format);

	send(SOCK_MQTT, msgbuf, sizeof(msgbuf));

   	BitMqttSendDataStart = _CLR;
	close(SOCK_MQTT);
	socket(SOCK_MQTT,Sn_MR_TCP,PORT_TCPS,Sn_MR_ND);

   	//========================================================================
}

//****************************************************************************************************************************
//
// FUNCTION       : void GSTECH_DEVICE_SETUP_MESSAGE_OUTPUT_PROCESS(void)
//
// USAGE          : MQTT Device Setup Message Receive & Send Common Process
//
// INPUT        :   None
//
// USED			:   None
//				
// OUTPUT       :   None
//
//****************************************************************************************************************************
void GSTECH_DEVICE_SETUP_MESSAGE_OUTPUT_PROCESS(void)
{
	char Tempchar[12];

	#ifdef __MAIN_DEBUG__
   	printf("\r\nGSTECH_DEVICE_SETUP_MESSAGE_OUTPUT_PROCESS\r\n");
	#endif
    //========================================================================
	memset(Board_out_Format,0,strlen(Board_out_Format));  
    //========================================================================
	sprintf(Board_out_Format,"%s","{ \"type\": \"RESPONSE_INFO\",");  

  	//---------------------------------------------------
	strcat(Board_out_Format,"\"deviceId\": \"");  
	strncat(Board_out_Format,MACidbuf,6);	// 5C5F9F
	strcat(Board_out_Format,"\",");

  	//---------------------------------------------------
	strcat(Board_out_Format,"\"dhcp\": \"");
	if(gstech_Device_DHCP == NETINFO_DHCP)
		strcat(Board_out_Format,"True\",");
	else
		strcat(Board_out_Format,"False\",");

  	//---------------------------------------------------
	strcat(Board_out_Format,"\"ip\": \"");
	sprintf(Tempchar, "%d.%d.%d.%d\",", gstech_Device_IP[0],gstech_Device_IP[1],gstech_Device_IP[2],gstech_Device_IP[3]);
	strcat(Board_out_Format,Tempchar);

  	//---------------------------------------------------
	strcat(Board_out_Format,"\"subnet\": \"");
	sprintf(Tempchar, "%d.%d.%d.%d\",", gstech_Device_SN[0],gstech_Device_SN[1],gstech_Device_SN[2],gstech_Device_SN[3]);
	strcat(Board_out_Format,Tempchar);

  	//---------------------------------------------------
	strcat(Board_out_Format,"\"gateway\": \"");
	sprintf(Tempchar, "%d.%d.%d.%d\",", gstech_Device_GW[0],gstech_Device_GW[1],gstech_Device_GW[2],gstech_Device_GW[3]);
	strcat(Board_out_Format,Tempchar);

  	//---------------------------------------------------
	strcat(Board_out_Format,"\"macAddr\": \"");
	sprintf(Tempchar, "%02X-%02X-%02X-%02X-%02X-%02X\",", gWIZNETINFO.mac[0],gWIZNETINFO.mac[1],gWIZNETINFO.mac[2],gWIZNETINFO.mac[3],gWIZNETINFO.mac[4],gWIZNETINFO.mac[5]);
	strcat(Board_out_Format,Tempchar);

  	//---------------------------------------------------
	strcat(Board_out_Format,"\"mqttIp\": \"");
	sprintf(Tempchar, "%d.%d.%d.%d\",", gstech_Mqtt_IP[0],gstech_Mqtt_IP[1],gstech_Mqtt_IP[2],gstech_Mqtt_IP[3]);
	strcat(Board_out_Format,Tempchar);

  	//---------------------------------------------------
	strcat(Board_out_Format,"\"mqttPort\": \"");
	sprintf(Tempchar, "%d\",", gstech_Mqtt_PORT);
	strcat(Board_out_Format,Tempchar);

  	//---------------------------------------------------
	strcat(Board_out_Format,"\"mqttId\": \"");
	sprintf(Tempchar, "%s\",", gstech_Mqtt_UserName);
	strcat(Board_out_Format,Tempchar);

  	//---------------------------------------------------
	strcat(Board_out_Format,"\"mqttPw\": \"");
	sprintf(Tempchar, "%s\",", gstech_Mqtt_PW);
	strcat(Board_out_Format,Tempchar);

  	//---------------------------------------------------
	strcat(Board_out_Format,"\"updateIp\": \"");
	sprintf(Tempchar, "%d.%d.%d.%d\",", gstech_Update_IP[0],gstech_Update_IP[1],gstech_Update_IP[2],gstech_Update_IP[3]);
	strcat(Board_out_Format,Tempchar);

  	//---------------------------------------------------
	strcat(Board_out_Format,"\"updatePort\": \"");
	sprintf(Tempchar, "%d\",", gstech_Update_PORT);
	strcat(Board_out_Format,Tempchar);

  	//---------------------------------------------------
	strcat(Board_out_Format,"\"statusCycle\": \"");
	if(gstech_StatusCycle)
		strcat(Board_out_Format,"True\",");
	else
		strcat(Board_out_Format,"False\",");

  	//---------------------------------------------------
	strcat(Board_out_Format,"\"period\": \"");
	sprintf(Tempchar, "%d\" ", gstech_Period);
	strcat(Board_out_Format,Tempchar);
	strcat(Board_out_Format,"}");
	strcat(Board_out_Format,"\0");

    //========================================================================
	#ifdef __MAIN_DEBUG__
 	printf("Board_out_Format =\r\n%s\r\n",Board_out_Format);
	#endif

	for(gstech_OutputCount = 0; gstech_OutputCount < DATA_BUF_SIZE; gstech_OutputCount++)
	{
		if(Board_out_Format[gstech_OutputCount] == '}')
			break;
	}
	++gstech_OutputCount;
	#ifdef __MAIN_DEBUG__
   	printf("\r\nBoard_out_Format gstech_OutputCount = %d\r\n", gstech_OutputCount);
	#endif
}

//****************************************************************************************************************************
//
// FUNCTION       : void GSTECH_GET_ADC_TEMPERATURE_VALUE(void)
//
// USAGE          : Get Temp. Value.
//
// INPUT        :   Read ADC Temp. Value
//
// USED			:   None
//				
// OUTPUT       :   temp value
//
//****************************************************************************************************************************
void GSTECH_GET_ADC_TEMPERATURE_VALUE(void)
{
	BYTE ii, jj;
	WORD TempBF;
	

	gstech_CurrentTemperatureAverage[gstech_CurrentTemperatureStableCount++] = ADC_Read();

	if(gstech_CurrentTemperatureStableCount >= _INITIAL_ADC_AVERAGE_COUNT)
	{
		gstech_CurrentTemperatureStableCount = _CLR;

		for(ii = _CLR; ii < _INITIAL_ADC_AVERAGE_COUNT; ii++)
		{
			for(jj = ii; jj < _INITIAL_ADC_AVERAGE_COUNT; jj++)
			{
				if(gstech_CurrentTemperatureAverage[ii] < gstech_CurrentTemperatureAverage[jj])
				{
					TempBF = gstech_CurrentTemperatureAverage[ii];
					gstech_CurrentTemperatureAverage[ii] = gstech_CurrentTemperatureAverage[jj];
					gstech_CurrentTemperatureAverage[jj] = TempBF;
				}
			}
		}
	
		TempBF = 4096 - gstech_CurrentTemperatureAverage[_CENTRE_ADC_AVERAGE_COUNT];	// AN0
 		//printf("TempBF ADC Value = [%4d]\r\n", TempBF);

		gstech_CurrentTemperature = (TempBF * 10) / _TEMP_SENSOR_STEP;
        //Voltage = (TempBF * 3.3) / 4095;
        //tempC = (Voltage - 0.5) * 1000;
        //printf("tempC value : %4d \r\n", gstech_CurrentTemperature);
       
        //tempC = 10000/(4095/TempBF-1);
        //printf("tempC value 1 : %3.2f C \r\n", tempC);
        //V = tempC/100000;
        //printf("tempC value 2 : %3.2f C \r\n", V);
        //V = log(tempC);
        //printf("tempC value 3 : %5.2f C \r\n", V);
        //V = V / 3950; 
        //printf("tempC value 4 : %5.2f C \r\n", V);
        //V += 1.0/(25*273.15);
        //printf("tempC value 5 : %5.2f C \r\n", V);
        //V = 1.0/V;
        //printf("tempC value 6 : %5.2f C \r\n", V);
        //V -= 273.15;
       
        //V = ((float)TempBF * 3.3)/4096 * 100; // connect Vs(Temp36) to 3.3V(WIZwiki-W7500) 
        //float V = ain.read(/) * 5; // connect Vs(Temp36) to 5V(WIZwiki-W7500)
        
        //tempC = (V-0.5) * 100; // calculate temperature C
        //tempF = (tempC * 9 / 5) + 32.0; // calculate temperature F
        
        //printf("tempC value : %5.2f C \r\n", V);
        //Printf("tempF value : %5.2f F \r\n", tempF);

 
 
		//tempC = 3300 * TempBF / 4096;
   		//gstech_CurrentTemperature = (SWORD)((float)TempBF / 10.0);

 		//printf("gstech_CurrentTemperature = [%3.1f]\r\n", (float)gstech_CurrentTemperature);

		//gstech_CurrentTemperature = 4096 - GSTECH_GET_REAL_TEMPERATURE_VALUE(gstech_CurrentTemperatureAverage[_CENTRE_ADC_AVERAGE_COUNT]);	// AN0
		//if(gstech_CurrentTemperature >= _MAX_TEMP)
		//	gstech_CurrentTemperature = _MAX_TEMP - 1;
	}
}

//****************************************************************************************************************************
//
// FUNCTION       : void GSTECH_W5500_NETWORK_INIT(WORD Delay)
//
// USAGE          : Initialize W5500 Network Chipset
//
// INPUT          : None
//
// OUTPUT         : None
//
//****************************************************************************************************************************
void GSTECH_W5500_NETWORK_INIT(void)
{
	uint8_t tmpstr[6] = {0,};
	uint8_t memsize[2][8] = { { 2, 2, 2, 2, 2, 2, 2, 2 }, { 2, 2, 2, 2, 2, 2, 2, 2 } };
    
	/* wizchip initialize*/
	if (ctlwizchip(CW_INIT_WIZCHIP, (void*) memsize) == -1) 
	{
		#ifdef __MAIN_DEBUG__
		printf("WIZCHIP Initialized fail.\r\n");
		#endif
		while (1);
	}
   
	#ifdef __MAIN_DEBUG__
	printf("WIZCHIP Initialized Done ........\r\n");
	#endif
    
    ctlnetwork(CN_SET_NETINFO, (void*)&gWIZNETINFO);

	// Display Network Information
	ctlwizchip(CW_GET_ID,(void*)tmpstr);
    
	if(gWIZNETINFO.dhcp == NETINFO_DHCP) 
		printf("\r\n===== %s NET CONF : DHCP =====\r\n",(char*)tmpstr);
	else 
		printf("\r\n===== %s NET CONF : Static =====\r\n",(char*)tmpstr);

	#ifdef __MAIN_DEBUG__
	printf("Internal PORT-1 Network - SIP: %3d.%3d.%3d.%3d\r\n", gWIZNETINFO.ip[0],gWIZNETINFO.ip[1],gWIZNETINFO.ip[2],gWIZNETINFO.ip[3]);
	printf("Internal PORT-1 Network - GAR: %3d.%3d.%3d.%3d\r\n", gWIZNETINFO.gw[0],gWIZNETINFO.gw[1],gWIZNETINFO.gw[2],gWIZNETINFO.gw[3]);
	printf("Internal PORT-1 Network - SUB: %3d.%3d.%3d.%3d\r\n", gWIZNETINFO.sn[0],gWIZNETINFO.sn[1],gWIZNETINFO.sn[2],gWIZNETINFO.sn[3]);
	printf("Internal PORT-1 Network - DNS: %3d.%3d.%3d.%3d\r\n", gWIZNETINFO.dns[0],gWIZNETINFO.dns[1],gWIZNETINFO.dns[2],gWIZNETINFO.dns[3]);
	printf("Internal PORT-1 Network - PORT_TCPS: [%5d]\r\n",PORT_TCPS);
	printf("Internal PORT-1 Network - MAC: %02X:%02X:%02X:%02X:%02X:%02X\r\n",gWIZNETINFO.mac[0],gWIZNETINFO.mac[1],gWIZNETINFO.mac[2],gWIZNETINFO.mac[3],gWIZNETINFO.mac[4],gWIZNETINFO.mac[5]);
	printf("======================\r\n");
	#endif

	//gstech_MacAddID = gWIZNETINFO.mac[0]+gWIZNETINFO.mac[1]+gWIZNETINFO.mac[2]+gWIZNETINFO.mac[3]+gWIZNETINFO.mac[4]+gWIZNETINFO.mac[5];

	#ifdef __MAIN_DEBUG__
	printf("MAC Address ID = [%02X%02X%02X]\r\n\r\n",gstech_Device_MAC[3],gstech_Device_MAC[4],gstech_Device_MAC[5]);
	//printf("MAC Address ID = [%04d]\r\n", gstech_MacAddID);
	printf("Server IP : %3d.%3d.%3d.%3d\r\n", gstech_Mqtt_IP[0],gstech_Mqtt_IP[1],gstech_Mqtt_IP[2],gstech_Mqtt_IP[3]);
 	printf("Server Port : [%04d]\r\n",gstech_Mqtt_PORT);

	printf("rgstech_Update_IP : %3d.%3d.%3d.%3d\r\n", gstech_Update_IP[0],gstech_Update_IP[1],gstech_Update_IP[2],gstech_Update_IP[3]);
	printf("rgstech_Update_PORT: %d\r\n",gstech_Update_PORT);
	printf("rgstech_StatusCycle: %d\r\n",gstech_StatusCycle);
	printf("rgstech_Period: %d\r\n",gstech_Period);

 	printf("gstech_Mqtt_UserName: %s\r\n",gstech_Mqtt_UserName);
	printf("gstech_Mqtt_PW: %s\r\n",gstech_Mqtt_PW);
	#endif
}

//****************************************************************************************************************************
//
// FUNCTION       : void GSTECH_DELAY_1mS(WORD Delay)
//
// USAGE          : System Timer 1ms * xx Count Delay
//
// INPUT          : WORD Value
//
// OUTPUT         : None
//
//****************************************************************************************************************************
void GSTECH_DELAY_1mS(WORD Delay)
{
	for( ; Delay !=	_CLR; Delay-- )
	{
		Bit1mS = _CLR;
		do
		{
			BitTimeToggle = ~BitTimeToggle;
	  		//HAL_IWDG_Refresh(&hiwdg);
		}
		while(Bit1mS == _CLR);
	}
}

//****************************************************************************************************************************
//
// FUNCTION       : void GSTECH_INITIALIZE_GLOBAL_RAM(void)
//
// USAGE          : Initialize Global RAM
//
// INPUT          : None
//
// OUTPUT         : None
//
//****************************************************************************************************************************
void GSTECH_INITIALIZE_GLOBAL_RAM(void)
{
	TIMERFLAGSbits.BitWord 		= _CLR;
	USARTFLAGSbits.BitWord 		= _CLR;
	GLOBAL1FLAGSbits.BitWord 	= _CLR;
	GLOBAL2FLAGSbits.BitWord 	= _CLR;
	GLOBAL3FLAGSbits.BitWord 	= _CLR;
	PORTDET1FLAGSbits.BitWord 	= _CLR;
	PORTDET2FLAGSbits.BitWord 	= _CLR;
	PORTCTRL1FLAGSbits.BitWord 	= _CLR;
	PORTCTRL2FLAGSbits.BitWord 	= _CLR;
	PORTCTRLEn1FLAGSbits.BitWord 	= _CLR;
	PORTCTRLEn2FLAGSbits.BitWord 	= _CLR;
	EEPromFLAGSbits.BitWord 	= _CLR;

  	//===========================================================================
	gstech_Device_IP[0] = 0;//192;
	gstech_Device_IP[1] = 0;//168;
	gstech_Device_IP[2] = 0;//  0;
	gstech_Device_IP[3] = 0;//255;

	//---------------------------------------------------------------------------
 	gstech_Device_SN[0] = 0;//255;
	gstech_Device_SN[1] = 0;//255;
	gstech_Device_SN[2] = 0;//255;
	gstech_Device_SN[3] = 0;//  0;

	//---------------------------------------------------------------------------
 	gstech_Device_GW[0] = 0;//192;
	gstech_Device_GW[1] = 0;//168;
	gstech_Device_GW[2] = 0;//  0;
	gstech_Device_GW[3] = 0;//  1;

	//---------------------------------------------------------------------------
 	gstech_Device_DNS[0] =  0;
	gstech_Device_DNS[1] =  0;
	gstech_Device_DNS[2] =  0;
	gstech_Device_DNS[3] =  0;

	//---------------------------------------------------------------------------
 	gstech_Device_MAC[0] = 0xFF;
	gstech_Device_MAC[1] = 0xFF;
	gstech_Device_MAC[2] = 0xFF;
	gstech_Device_MAC[3] = 0xFF;
	gstech_Device_MAC[4] = 0xFF;
	gstech_Device_MAC[5] = 0xFF;

	//---------------------------------------------------------------------------
	gstech_Device_DHCP = NETINFO_DHCP;
	gstech_Device_PORT = PORT_TCPS;

	//===========================================================================
	BitPHYStatuscheckflag = _SET;
	BitEnableGetVersionFile = _SET;
	BitEnableGetFirmwareFile = _SET;

	gstech_Mqtt_IP[0] = gstech_Update_IP[0] = 121;
	gstech_Mqtt_IP[1] = gstech_Update_IP[1] = 150;
	gstech_Mqtt_IP[2] = gstech_Update_IP[2] = 67;
	gstech_Mqtt_IP[3] = gstech_Update_IP[3] = 34;
	gstech_Mqtt_PORT = 1883;
	gstech_Update_PORT = 80;
	local_port = PORT_TCPS;

  	//===========================================================================
	USART2_TX_ENABLE_ON();

  	//===========================================================================
	//PC-13 Output ����
	BKP->RTCCR &= ~BKP_RTCCR_ASOE;

  	//===========================================================================
	SD_CARD_CS_OFF();
	FLASH_CS_OFF();
	FLASH_WP_ON();
	
	W5500_RESET_LOW();
	W5500_CS_HIGH();

	CTRL_PORT_1_OFF();
	CTRL_PORT_2_OFF();

	STATUS_LED_1_OFF();
	STATUS_LED_2_OFF();

	DEBUG_OFF();
}

////****************************************************************************************************************************
////
//// FUNCTION       : void GSTECH_TIMER_10MS_PROCESS(void)
////
//// USAGE          : Each 10ms function process
////
//// INPUT          : None
////
//// OUTPUT         : None
////
////****************************************************************************************************************************
//void GSTECH_TIMER_10MS_PROCESS(void)
//{
//	//========================================================================================================================
//	Bit10mS = _CLR; 
//}

//****************************************************************************************************************************
//
// FUNCTION       : void GSTECH_TIMER100MSPROCESS(void)
//
// USAGE          : Each 100ms function process
//
// INPUT          : None
//
// OUTPUT         : None
//
//****************************************************************************************************************************
void GSTECH_TIMER_100MS_PROCESS(void)
{
	GSTECH_GET_ADC_TEMPERATURE_VALUE();

	//========================================================================================================================
	Bit100mS = _CLR; 
}
	
//****************************************************************************************************************************
//
// FUNCTION       : void GSTECH_TIMER_250MS_PROCESS(void)
//
// USAGE          : Each 250ms function process
//
// INPUT          : None
//
// OUTPUT         : None
//
//****************************************************************************************************************************
void GSTECH_TIMER_250MS_PROCESS(void)
{
 	BitTimeToggle = ~BitTimeToggle;
 	if(BitTimeToggle)
 		HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_7);
 	else
 		HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_8);

	//========================================================================================================================
	Bit250mS = _CLR; 
}

//****************************************************************************************************************************
//
// FUNCTION       : void GSTECH_TIMER_500MS_PROCESS(void)
//
// USAGE          : Each 500ms function process
//
// INPUT          : None
//
// OUTPUT         : None
//
//****************************************************************************************************************************
void GSTECH_TIMER_500MS_PROCESS(void)
{
	//BYTE TempCount;

	HAL_RTC_GetTime(&hrtc, &RtcTime, RTC_FORMAT_BIN);
	HAL_RTC_GetDate(&hrtc, &RtcDate, RTC_FORMAT_BIN);

	if(BitMqttResetCommandSetDone)
	{
		//for(TempCount = _SET; TempCount <= _MAX_RELAY_COUNT; TempCount++)
		GSTECH_MQTT_RELAY_CONTROL_PROCESS(Gstech_ResetRelayIdx);
		BitMqttResetCommandSetDone = _CLR;
		BitMqttSendDataStart = _SET;		// MQTT Message Reply Send Start
	}
	//========================================================================================================================
	Bit500mS = _CLR; 
}

//****************************************************************************************************************************
//
// FUNCTION       : void GSTECH_TIMER_1000MS_PROCESS(void)
//
// USAGE          : Each 1000ms function process
//
// INPUT          : None
//
// OUTPUT         : None
//
//****************************************************************************************************************************
void GSTECH_TIMER_1000MS_PROCESS(void)
{
	//uint8_t tmp;
    //
	//ctlwizchip(CW_GET_PHYLINK, (void*) &tmp);
	//rc = getSn_SR(SOCK_MQTT);
    //
	//if((tmp == 0) || (rc != SOCK_ESTABLISHED))
	//{
	//	if((++gstech_ServerCheckTimeCount) >= _MQTT_REBOOT_TIME_OUT_COUNT)
	//		BitJumpBootCodeStart = _SET;	
    //
	//	#ifdef __MAIN_DEBUG__
	//	if(rc != SOCK_ESTABLISHED)
	//		printf("Reboot Time getSn_IR(SOCK_MQTT) - 0x%x\r\n", rc);
	//	else if(tmp == 0)
	//		printf("Reboot Time PHY_LINK_STATUS_CHECK - %d\r\n", tmp);
	//	#endif
	//}
	//else
	//{
	//	gstech_ServerCheckTimeCount = _CLR;
	//}
	
	//========================================================================================================================
	if(BitMqttReConnectionStart)
	{
		if((++SocketTimeoutCount) == 5)
		{
			close(SOCK_MQTT);
			SocketTimeoutCount = _CLR;
			BitMqttReConnectionStart = _CLR;
		}
	}
	
	//========================================================================================================================
	if(gstech_PeriodCount)
	{
		if(BitMqttConnectionDone && BitMqttContinueSendEnable)
		{
			if((--gstech_PeriodCount) == _CLR)
			{
				GSTECH_MQTT_MESSAGE_OUTPUT_PROCESS();
				gstech_PeriodCount = gstech_Period;
			}
		}
	}

	#ifdef __MAIN_DEBUG__
    //printf("%d-%d-%d, %d:%d:%d\r\n", RtcDate.Year+2000, RtcDate.Month, RtcDate.Date, RtcTime.Hours, RtcTime.Minutes, RtcTime.Seconds);
	#endif

	//========================================================================================================================
	Bit1000mS = _CLR;
}
 
//****************************************************************************************************************************
//
// FUNCTION       : int main(void)
//
// USAGE          : The application entry point.
//
// INPUT          : None
//
// OUTPUT         : None
//
//****************************************************************************************************************************
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	uint32_t flashVersion = VersionAddr;
	datetime tmpTimestr;
   	//uint8_t TestStatus; // return value for SOCK_ERRORs
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_ADC1_Init();
  MX_RTC_Init();
  MX_SPI1_Init();
  MX_SPI2_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  MX_I2C2_Init();
  /* USER CODE BEGIN 2 */
	printf("\r\n\r\n===============================================\r\n");
	printf("RCU Board MQTT System Start .........");
	printf("\r\n===============================================\r\n\r\n");

	__enable_irq();
	HAL_UART_Receive_IT(&huart1, &gstech_Com1ReceiveBuffer, 1);
	HAL_UART_Receive_IT(&huart2, &gstech_Com2ReceiveBuffer, 1);
 
	GSTECH_INITIALIZE_GLOBAL_RAM();

	EEP_CHECK_BLANK();

	//========================================================================================================================
	//if(!BitOneTimeInitialDone)
	#if __RELAY_DEFAULT_HIGH == _SET
	{
		RELAY_PORT_1_ON();
		GSTECH_DELAY_1mS(500);
		RELAY_PORT_2_ON();
		GSTECH_DELAY_1mS(500);
		RELAY_PORT_3_ON();
		GSTECH_DELAY_1mS(500);
		RELAY_PORT_4_ON();
		//GSTECH_DELAY_1mS(500);
		//RELAY_PORT_5_ON();
		//GSTECH_DELAY_1mS(500);
		//RELAY_PORT_6_ON();
		//GSTECH_DELAY_1mS(500);
		//RELAY_PORT_7_ON();
		//GSTECH_DELAY_1mS(500);
		//RELAY_PORT_8_ON();

		BitPort1Control = _SET;
		BitPort2Control = _SET;
		BitPort3Control = _SET;
		BitPort4Control = _SET;
		//BitPort5Control = _SET;
		//BitPort6Control = _SET;
		//BitPort7Control = _SET;
		//BitPort8Control = _SET;
		BitOneTimeInitialDone = _SET;
	}
	#else
	{
		RELAY_PORT_1_OFF();
		GSTECH_DELAY_1mS(500);
		RELAY_PORT_2_OFF();
		GSTECH_DELAY_1mS(500);
		RELAY_PORT_3_OFF();
		GSTECH_DELAY_1mS(500);
		RELAY_PORT_4_OFF();
		//GSTECH_DELAY_1mS(500);
		//RELAY_PORT_5_OFF();
		//GSTECH_DELAY_1mS(500);
		//RELAY_PORT_6_OFF();
		//GSTECH_DELAY_1mS(500);
		//RELAY_PORT_7_OFF();
		//GSTECH_DELAY_1mS(500);
		//RELAY_PORT_8_OFF();

		BitPort1Control = _CLR;
		BitPort2Control = _CLR;
		BitPort3Control = _CLR;
		BitPort4Control = _CLR;
		//BitPort5Control = _CLR;
		//BitPort6Control = _CLR;
		//BitPort7Control = _CLR;
		//BitPort8Control = _CLR;
		BitOneTimeInitialDone = _SET;
	}
	#endif
	//gstech_Mqtt_IP[0] = gstech_Update_IP[0] = 121;
	//gstech_Mqtt_IP[1] = gstech_Update_IP[1] = 150;
	//gstech_Mqtt_IP[2] = gstech_Update_IP[2] = 67;
	//gstech_Mqtt_IP[3] = gstech_Update_IP[3] = 34;
	//gstech_Mqtt_PORT = 1883;
	//gstech_Update_PORT = 80;
	//local_port = PORT_TCPS;
	//memcpy(&gstech_Mqtt_UserName , &targetusername , 6);	// gstech
	//memcpy(&gstech_Mqtt_PW , &targetpassword , 6);		// gs7011

  	W5500_RESET_LOW();
  	HAL_Delay(1);
  	W5500_RESET_HIGH();

	memcpy(&gWIZNETINFO.ip[0],  gstech_Device_IP, 4);
	memcpy(&gWIZNETINFO.gw[0],  gstech_Device_GW, 4);
	memcpy(&gWIZNETINFO.sn[0],  gstech_Device_SN, 4);
	memcpy(&gWIZNETINFO.mac[0], gstech_Device_MAC, 6);

    //========================================================================
   	//if(__HAL_RCC_GET_FLAG(RCC_FLAG_WWDGRST) == SET)
  	//{
	//  	__HAL_RCC_CLEAR_RESET_FLAGS();
  	//}

	gstech_Read_FW_Version = (uint16_t)(*(__IO uint32_t*)flashVersion);
	printf("Read Boot flashVersion[0x%lx] = [v%d.%d] \r\n", flashVersion, (uint8_t)gstech_Read_FW_Version/10, (uint8_t)gstech_Read_FW_Version%10);

   	//========================================================================
	//print_network_information();
	GSTECH_W5500_NETWORK_INIT();

    //========================================================================
	//char gstech_topic[30] = "/gstech/";
	sprintf(MACidbuf,"%02X%02X%02X",gstech_Device_MAC[3],gstech_Device_MAC[4],gstech_Device_MAC[5]);  
	strcat(gstech_topic,MACidbuf);
	strcat(gstech_topic,"/in/#");
    
    //========================================================================
	//char topic_Output[30]={"/gstech/"};
	strncat(topic_Output,MACidbuf, 6);
	strcat(topic_Output,"/out/status");
    
    //========================================================================
	#ifdef __MAIN_DEBUG__
 	printf("gstech_topic: %s\r\n",gstech_topic);
 	printf("topic_Output: %s\r\n",topic_Output);
	#endif

    //========================================================================
    GSTECH_DEVICE_SETUP_MESSAGE_OUTPUT_PROCESS();

    //========================================================================
    //========================================================================
	/* DHCP client Initialization */
	//BitEnableDHCPFunction = _SET;
	printf(">> DHCP DHCP_init Start ....... \r\n\r\n");  	
	if(gstech_Device_DHCP == NETINFO_DHCP)
	{
		//gstech_W5500TimeOutCount = _TIME_5000MS_VALUE;
		//BitTimeOverW5500Check = _CLR;

	  	//HAL_IWDG_Refresh(&hiwdg);
		DHCP_init(SOCK_DHCP, gDATABUF);
		// if you want different action instead default ip assign, update, conflict.
		// if cbfunc == 0, act as default.
		//reg_dhcp_cbfunc(my_ip_assign, my_ip_assign, my_ip_conflict);
    
		//gstech_W5500TimeOutCount = _TIME_5000MS_VALUE;
		//BitTimeOverW5500Check = _CLR;

		BitEnableDHCPFunction = _SET; 	// flag for running DHCP user's code
    
		while(BitEnableDHCPFunction)
		{
	  		//HAL_IWDG_Refresh(&hiwdg);
    
	   		/* PHY Status checker: Check every 'SEC_PHYSTATUS_CHECK' seconds */
			if(BitPHYStatuscheckflag)
			{
				BitPHYStatuscheckflag = _CLR;
				GSTECH_PHY_LINK_STATUS_CHECK();
			}
    
			/* DHCP */
			/* DHCP IP allocation and check the DHCP lease time (for IP renewal) */
			switch(DHCP_run())
			{
				case DHCP_IP_LEASED:
					BitEnableDHCPFunction = _CLR;
					#ifdef __MAIN_DEBUG__
 					printf(">> DHCP DHCP_init Done ......\r\n");
					#endif
					break;
				case DHCP_FAILED:
					/* ===== Example pseudo code =====  */
					// The below code can be replaced your code or omitted.
					// if omitted, retry to process DHCP
					my_dhcp_retry++;
					if(my_dhcp_retry > MY_MAX_DHCP_RETRY)
					{
						gWIZNETINFO.dhcp = gstech_Device_DHCP = NETINFO_STATIC;
						DHCP_stop();      // if restart, recall DHCP_init()
						#ifdef __MAIN_DEBUG__
						printf(">> DHCP %d Failed\r\n", my_dhcp_retry);
						#endif

						ctlnetwork(CN_SET_NETINFO, (void*) &gWIZNETINFO);
						my_dhcp_retry = 0;
						//BitEnableDHCPFunction = _CLR;
					}
					break;
				case DHCP_IP_ASSIGN:
				case DHCP_IP_CHANGED:
				default:
					break;
			}

			if(Bit1000mS)
			{
				printf("DHCP Get Waitting....... \r\n\r\n");
				Bit1000mS = _CLR;  	
			}
			//if(BitTimeOverW5500Check)
			//{
			//	printf("DHCP Check TimeOut Exit ....... \r\n\r\n");
			//	BitEnableDHCPFunction = _CLR;
			//}				
		}
 	}
   
    //========================================================================
	//================================================================================
	#if SUPPORT_NTP_TIME == _SET
	gstech_sntpTimeOutCount = _TIME_3000MS_VALUE;
	BitTimeOversntpCheck = _CLR;

 	SNTP_init(SOCK_SNTP, ntp_server, 40, gDATABUF);	// timezone: Korea, Republic of
	do {/*HAL_IWDG_Refresh(&hiwdg);*/}                                
	while((SNTP_run(&tmpTimestr) != 1) && !BitTimeOversntpCheck);
	#ifdef __MAIN_DEBUG__
    printf("\r\n Current Time : %d-%d-%d, %d:%d:%d\r\n\r\n", tmpTimestr.yy, tmpTimestr.mo, tmpTimestr.dd, tmpTimestr.hh, tmpTimestr.mm, tmpTimestr.ss);
	#endif
    
  	if(!BitTimeOversntpCheck)
  	{
	  	RtcDate.Year = tmpTimestr.yy - 2000;
	  	RtcDate.Month = tmpTimestr.mo;
	  	RtcDate.Date = tmpTimestr.dd;
	  	RtcTime.Hours = tmpTimestr.hh;
	  	RtcTime.Minutes = tmpTimestr.mm;
	  	RtcTime.Seconds = tmpTimestr.ss;
	  	HAL_RTC_SetDate(&hrtc, &RtcDate, RTC_FORMAT_BIN);
	  	HAL_RTC_SetTime(&hrtc, &RtcTime, RTC_FORMAT_BIN);

		HAL_RTC_GetTime(&hrtc, &RtcTime, RTC_FORMAT_BIN);
		HAL_RTC_GetDate(&hrtc, &RtcDate, RTC_FORMAT_BIN);
		#ifdef __MAIN_DEBUG__
	    printf("\r\n RTC Time : %d-%d-%d, %d:%d:%d\r\n\r\n", RtcDate.Year, RtcDate.Month, RtcDate.Date, RtcTime.Hours, RtcTime.Minutes, RtcTime.Seconds);
		#endif
	}
	#endif
    //========================================================================
    //========================================================================
	/*Set network informations*/
	GSTECH_NETWORK_SET_COMMON_PROCESS();
	//wizchip_setnetinfo(&gWIZNETINFO);
    //
	//n.my_socket = SOCK_MQTT;
	//NewNetwork(&n);
    //
	//data.willFlag = 0; //data setting 
	//data.MQTTVersion = 4;
	//data.clientID.cstring = topic_Output;
	//data.username.cstring = gstech_Mqtt_UserName;
	//data.password.cstring = gstech_Mqtt_PW;
    //
	//data.keepAliveInterval = 180;
	//data.cleansession = 1;

    //========================================================================
  	/* Infinite loop */
  	while(_SET)
	{
		//HAL_IWDG_Refresh(&hiwdg); 

    	//====================================================================
		switch(getSn_SR(SOCK_MQTT))
		{
			case SOCK_INIT:
			    //connect(n.my_socket,gstech_Mqtt_IP,gstech_Mqtt_PORT);
 				ConnectNetwork(&n, gstech_Mqtt_IP, gstech_Mqtt_PORT);
				MQTTClient(&c,&n,1000,buf,BUFFER_SIZE,ReadBuffer,BUFFER_SIZE);
	 			#ifdef __MAIN_DEBUG__
         		printf("SOCK_INIT.......\r\n");	
				#endif

				BitMqttConnectionDone = _CLR;
				BitMqttReConnectionStart = _CLR;
 				break;
			case SOCK_ESTABLISHED:
				if(getSn_IR(SOCK_MQTT) & Sn_IR_CON)
					setSn_IR(SOCK_MQTT, Sn_IR_CON);
            
				if((len = getSn_RX_RSR(SOCK_MQTT)) == 0)
        		{					
					rc = MQTTConnect(&c, &data);
	        		rc = MQTTSubscribe(&c, gstech_topic, 0, messageArrived);
					BitMqttConnectionDone = _SET;
				} 
				else
				{
    				rc = MQTTYield(&c, data.keepAliveInterval);
					if (rc == -1) 
					{	
 						#ifdef __MAIN_DEBUG__
 					 	printf("\r\nDisconnected\r\n");	
						#endif
						close(SOCK_MQTT);
					}
				}
				break;
			case SOCK_CLOSE_WAIT: 
	 			#ifdef __MAIN_DEBUG__
         		printf("SOCK_CLOSE_WAIT.......\r\n");	
				#endif
				
				//BitMqttReConnectionStart = _SET;
				//break;
			case SOCK_CLOSED:  
          		//if(BitMqttConnectiornDone)
          		{
          			socket(SOCK_MQTT,Sn_MR_TCP,anyport,0);			
 	 				#ifdef __MAIN_DEBUG__
           			if(BitMqttConnectionDone)
       					printf("SOCK_CLOSED.......\r\n");	
					#endif
				}
				BitMqttConnectionDone = _CLR;
				break;
			default:
				break;
		}   

		//================================================================================
		//================================================================================
		if(BitJumpBootCodeStart && ((GetCommandType == _MQTT_COMMAND_UPDATE) || (GetCommandType == _MQTT_COMMAND_REBOOT)))
		 	GSTECH_BOOT_CODE_JUMP();

		//================================================================================
		//================================================================================
		// UDP server loopback status 
		if((rc = loopback_udps(SOCK_UDPS, gDATABUF, PORT_UDPS_BROADCAST)) < 0) 
		{
			#ifdef __MAIN_DEBUG__
			printf("SOCK_UDPS ERROR : %d\r\n", rc);
			#endif
		}
	    
		//--------------------------------------------------------------------------------
		// UDP server loopback IP setup
		if((rc = loopback_udpc(SOCK_UDPS_SETUP, gDATABUF, PORT_UDPS_SETUP)) < 0) 
		{
			#ifdef __MAIN_DEBUG__
			printf("SOCK_UDPS_SETUP ERROR : %d\r\n", rc);
			#endif
		}
        
		//================================================================================
		//================================================================================
		if(BitTimeOverCom1Rx)
			GSTECH_USART_COM1_RX_COMMAND_PROCESS();
		
		//--------------------------------------------------------------------------------
		if(BitTimeOverCom2Rx)
			GSTECH_USART_COM2_RX_COMMAND_PROCESS();
		
		//================================================================================
		if(BitMqttConnectionDone && BitMqttSendDataStart)
			GSTECH_MQTT_MESSAGE_OUTPUT_PROCESS();

		//================================================================================
		//if(Bit10mS)
		//	GSTECH_TIMER_10MS_PROCESS();
		
		//--------------------------------------------------------------------------------
		if(Bit100mS)
			GSTECH_TIMER_100MS_PROCESS();
		
		//--------------------------------------------------------------------------------
		if(Bit250mS)
			GSTECH_TIMER_250MS_PROCESS();
		
		//--------------------------------------------------------------------------------
		if(Bit500mS)
			GSTECH_TIMER_500MS_PROCESS();

		//--------------------------------------------------------------------------------
		if(Bit1000mS)
			GSTECH_TIMER_1000MS_PROCESS();

		//--------------------------------------------------------------------------------
		if(BitEEPSaveDone)
			GSTECH_FLASH_SAVE_ALL();

		//================================================================================
	}


  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSI|RCC_OSCILLATORTYPE_HSE
                              |RCC_OSCILLATORTYPE_LSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.LSEState = RCC_LSE_ON;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_RTC|RCC_PERIPHCLK_ADC;
  PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSE;
  PeriphClkInit.AdcClockSelection = RCC_ADCPCLK2_DIV6;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
