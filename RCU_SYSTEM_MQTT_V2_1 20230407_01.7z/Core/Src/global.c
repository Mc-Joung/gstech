/********************** (C) COPYRIGHT 2011 NEXON chip co.,**********************
* File Name          : global.c
* Author             : www.nexonchip.com Benjamin Lee
* Version            : V2.0.0
* Date               : 04/16/2011
* Description        : Header for global.c module
********************************************************************************
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

//****************************************************************************************************************************
//  I N C L U D E    F I L E S
//****************************************************************************************************************************
#include "rtc.h"
#include "define.h"
#include "extern.h"

//=================================================================================================================================
BYTE gstech_Timer10mSec;
BYTE gstech_Timer25mSec;
BYTE gstech_Timer50mSec;
BYTE gstech_Timer100mSec;
WORD gstech_Timer250mSec;
WORD gstech_Timer500mSec;
WORD gstech_Timer1000mSec;
WORD gstech_TimerxxxxmSec;
WORD gstech_TimeOverI2C;

//=================================================================================================================================
TimerFlagsType TIMERFLAGSbits;
GlobalFlagsType USARTFLAGSbits;
GlobalFlagsType GLOBAL1FLAGSbits;
GlobalFlagsType GLOBAL2FLAGSbits;
GlobalFlagsType GLOBAL3FLAGSbits;
GlobalFlagsType PORTDET1FLAGSbits;
GlobalFlagsType PORTDET2FLAGSbits;
GlobalFlagsType PORTCTRL1FLAGSbits;
GlobalFlagsType PORTCTRL2FLAGSbits;
GlobalFlagsType PORTCTRLEn1FLAGSbits;
GlobalFlagsType PORTCTRLEn2FLAGSbits;
GlobalFlagsType EEPromFLAGSbits;

//=================================================================================================================================
RTC_TimeTypeDef RtcTime;
RTC_DateTypeDef RtcDate;

//=================================================================================================================================
BYTE gstech_ModBusCoil[_MAX_COIL_BUFFER] = {0};
WORD gstech_ModBusRegister[_MAX_REGISTER_BUFFER] = {0};

//=================================================================================================================================
// USART 1
BYTE gstech_COM1_Rx_BF[_MAX_COMx_RX_BUFFER_SIZE] = {0};
BYTE gstech_COM1_Tx_BF[_MAX_COMx_TX_BUFFER_SIZE] = {0};
BYTE ProcessCOM1RxBuffer[_MAX_COMx_RX_BUFFER_SIZE] = {0};
BYTE gstech_Com1ReceiveBuffer = _CLR;
BYTE gstech_Com1TimeOutCount = _CLR;
BYTE gstech_Com1ReceiveCount = _CLR;
BYTE gstech_Com1ProcesseCount = _CLR;
WORD gstech_Com1ACKSendTimeCount = _CLR;

//=================================================================================================================================
// USART 2
BYTE gstech_COM2_Rx_BF[_MAX_COMx_RX_BUFFER_SIZE] = {0};
BYTE gstech_COM2_Tx_BF[_MAX_COMx_TX_BUFFER_SIZE] = {0};
BYTE ProcessCOM2RxBuffer[_MAX_COMx_RX_BUFFER_SIZE] = {0};
BYTE gstech_Com2ReceiveBuffer = _CLR;
BYTE gstech_Com2TimeOutCount = _CLR;
BYTE gstech_Com2ReceiveCount = _CLR;
BYTE gstech_Com2ProcesseCount = _CLR;
WORD gstech_Com2ACKSendTimeCount = _CLR;

//=================================================================================================================================
BYTE gstech_W5500TXBuffer[DATA_BUF_SIZE + 3];
BYTE gstech_W5500RXBuffer[DATA_BUF_SIZE + 3];
WORD gstech_W5500TimeOutCount = _CLR;
WORD gstech_sntpTimeOutCount = _CLR;

//=================================================================================================================================
BYTE gstech_Device_IP[4];
BYTE gstech_Device_SN[4];
BYTE gstech_Device_GW[4];
BYTE gstech_Device_DNS[4];
BYTE gstech_Device_DHCP;
WORD gstech_Device_PORT;
BYTE gstech_Device_MAC[6];
//WORD gstech_MacAddID;
WORD gstech_OutputCount;

//-------------------------------------------------------------------------------------------------------------------------
BYTE gstech_Mqtt_IP[4];
WORD gstech_Mqtt_PORT;
char gstech_Mqtt_UserName[_MQTT_MAX_ID_COUNT+3];
BYTE gstech_UserNameLength;
char gstech_Mqtt_PW[_MQTT_MAX_PW_COUNT+3];
BYTE gstech_PasswordLength;
//char gstech_FW_Version[4];
//WORD gstech_FW_Version;
WORD gstech_Read_FW_Version;

//-------------------------------------------------------------------------------------------------------------------------
WORD local_port;
BYTE gstech_Update_IP[4];
WORD gstech_Update_PORT;
BYTE gstech_StatusCycle;
WORD gstech_Period;
WORD gstech_PeriodCount;

//=================================================================================================================================
WORD gstech_CurrentTemperatureAverage[_INITIAL_ADC_AVERAGE_COUNT];
WORD gstech_CurrentTemperature;
BYTE gstech_CurrentTemperatureStableCount;

//=================================================================================================================================
BYTE etem_W5500TXBuffer[DATA_BUF_SIZE + 3];
BYTE etem_W5500RXBuffer[DATA_BUF_SIZE + 3];
WORD etem_W5500TimeOutCount = _CLR;

//=================================================================================================================================
BYTE gstech_Port1StableCount = 0;
BYTE gstech_Port2StableCount = 0;
BYTE gstech_Port3StableCount = 0;
BYTE gstech_Port4StableCount = 0;
BYTE gstech_Port5StableCount = 0;
BYTE gstech_Port6StableCount = 0;
BYTE gstech_Port7StableCount = 0;
BYTE gstech_Port8StableCount = 0;

//-------------------------------------------------------------------------------------------------------------------------
BYTE gstech_Port1UnStableCount = 0;
BYTE gstech_Port2UnStableCount = 0;
BYTE gstech_Port3UnStableCount = 0;
BYTE gstech_Port4UnStableCount = 0;
BYTE gstech_Port5UnStableCount = 0;
BYTE gstech_Port6UnStableCount = 0;
BYTE gstech_Port7UnStableCount = 0;
BYTE gstech_Port8UnStableCount = 0;

//-------------------------------------------------------------------------------------------------------------------------
DWORD gstech_RelayTimeCount[33] = {_CLR};
//WORD gstech_RelayTimeCount = 0;
//WORD gstech_RelayTimeCount = 0;
//WORD gstech_RelayTimeCount = 0;
//WORD gstech_RelayTimeCount = 0;
//WORD gstech_RelayTimeCount = 0;
//WORD gstech_RelayTimeCount = 0;
//WORD gstech_RelayTimeCount = 0;

DWORD gstech_MqttSendStartTimeCount = 0;
WORD gstech_pingMessageTimeCount = 0;
BYTE Gstech_ResetRelayIdx = 0;

//=================================================================================================================================
//=================================================================================================================================

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
