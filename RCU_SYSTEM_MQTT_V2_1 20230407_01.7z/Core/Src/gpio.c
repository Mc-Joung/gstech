/**
  ******************************************************************************
  * @file    gpio.c
  * @brief   This file provides code for the configuration
  *          of all used GPIO pins.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "gpio.h"

/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/*----------------------------------------------------------------------------*/
/* Configure GPIO                                                             */
/*----------------------------------------------------------------------------*/
/* USER CODE BEGIN 1 */
void GSTECHGPIO_PORT1_STATUS_PORT_CHECK_PROCESS(void);
void GSTECHGPIO_PORT2_STATUS_PORT_CHECK_PROCESS(void);
void GSTECHGPIO_PORT3_STATUS_PORT_CHECK_PROCESS(void);
void GSTECHGPIO_PORT4_STATUS_PORT_CHECK_PROCESS(void);
void GSTECHGPIO_PORT5_STATUS_PORT_CHECK_PROCESS(void);
void GSTECHGPIO_PORT6_STATUS_PORT_CHECK_PROCESS(void);
void GSTECHGPIO_PORT7_STATUS_PORT_CHECK_PROCESS(void);
void GSTECHGPIO_PORT8_STATUS_PORT_CHECK_PROCESS(void);

/* USER CODE END 1 */

/** Configure pins as
        * Analog
        * Input
        * Output
        * EVENT_OUT
        * EXTI
*/
void MX_GPIO_Init(void)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13|GPIO_PIN_10, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3
                          |GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_7|GPIO_PIN_8
                          |GPIO_PIN_9, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_8|GPIO_PIN_15, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2|GPIO_PIN_12|GPIO_PIN_3|GPIO_PIN_4, GPIO_PIN_RESET);

  /*Configure GPIO pin : PC13 */
  GPIO_InitStruct.Pin = GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PC0 PC1 PC2 PC3
                           PC4 PC5 PC7 PC8
                           PC9 PC10 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_3
                          |GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_7|GPIO_PIN_8
                          |GPIO_PIN_9|GPIO_PIN_10;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PA0 PA1 PA4 PA8
                           PA15 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1|GPIO_PIN_4|GPIO_PIN_8
                          |GPIO_PIN_15;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB1 PB2 PB12 PB3
                           PB4 */
  GPIO_InitStruct.Pin = GPIO_PIN_1|GPIO_PIN_2|GPIO_PIN_12|GPIO_PIN_3
                          |GPIO_PIN_4;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : PC6 PC11 PC12 */
  GPIO_InitStruct.Pin = GPIO_PIN_6|GPIO_PIN_11|GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PA11 PA12 */
  GPIO_InitStruct.Pin = GPIO_PIN_11|GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : PD2 */
  GPIO_InitStruct.Pin = GPIO_PIN_2;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pins : PB5 PB6 PB7 PB8
                           PB9 */
  GPIO_InitStruct.Pin = GPIO_PIN_5|GPIO_PIN_6|GPIO_PIN_7|GPIO_PIN_8
                          |GPIO_PIN_9;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

}

/* USER CODE BEGIN 2 */
////****************************************************************************************************************************
////
//// FUNCTION       : void GSTECHGPIO_PORT1_STATUS_PORT_CHECK_PROCESS(void)
////
//// USAGE          : Port1 Status Check
////
//// INPUT          : None
////
//// OUTPUT         : None
////
////****************************************************************************************************************************
//void GSTECHGPIO_PORT1_STATUS_PORT_CHECK_PROCESS(void)
//{
//	if(!PORT_1_DETECT())
//	{
//		if(!BitPort1DetStatus)
//		{
//			if((++gstech_Port1StableCount) > _GPIO_PORT_STABLE_COUNT)
//			{
//				BitPort1DetStatus = _SET;
//				gstech_Port1StableCount = _CLR;
//			}
//		}
//		
//		gstech_Port1UnStableCount = _CLR;
//	}
//	else
//	{
//		if(BitPort1DetStatus)
//		{
//			if((++gstech_Port1UnStableCount) > _GPIO_PORT_UNSTABLE_COUNT)
//			{
//				BitPort1DetStatus = _CLR;
//				gstech_Port1UnStableCount = _CLR;
//			}
//		}
//		
//		gstech_Port1StableCount = _CLR;
//	}
//}
//
////****************************************************************************************************************************
////
//// FUNCTION       : void GSTECHGPIO_PORT2_STATUS_PORT_CHECK_PROCESS(void)
////
//// USAGE          : Port2 Status Check
////
//// INPUT          : None
////
//// OUTPUT         : None
////
////****************************************************************************************************************************
//void GSTECHGPIO_PORT2_STATUS_PORT_CHECK_PROCESS(void)
//{
//	if(!PORT_2_DETECT())
//	{
//		if(!BitPort2DetStatus)
//		{
//			if((++gstech_Port2StableCount) > _GPIO_PORT_STABLE_COUNT)
//			{
//				BitPort2DetStatus = _SET;
//				gstech_Port2StableCount = _CLR;
//			}
//		}
//		
//		gstech_Port2UnStableCount = _CLR;
//	}
//	else
//	{
//		if(BitPort2DetStatus)
//		{
//			if((++gstech_Port2UnStableCount) > _GPIO_PORT_UNSTABLE_COUNT)
//			{
//				BitPort2DetStatus = _CLR;
//				gstech_Port2UnStableCount = _CLR;
//			}
//		}
//		
//		gstech_Port2StableCount = _CLR;
//	}
//}
//
////****************************************************************************************************************************
////
//// FUNCTION       : void GSTECHGPIO_PORT3_STATUS_PORT_CHECK_PROCESS(void)
////
//// USAGE          : Port3 Status Check
////
//// INPUT          : None
////
//// OUTPUT         : None
////
////****************************************************************************************************************************
//void GSTECHGPIO_PORT3_STATUS_PORT_CHECK_PROCESS(void)
//{
//	if(!PORT_3_DETECT())
//	{
//		if(!BitPort3DetStatus)
//		{
//			if((++gstech_Port3StableCount) > _GPIO_PORT_STABLE_COUNT)
//			{
//				BitPort3DetStatus = _SET;
//				gstech_Port3StableCount = _CLR;
//			}
//		}
//		
//		gstech_Port3UnStableCount = _CLR;
//	}
//	else
//	{
//		if(BitPort3DetStatus)
//		{
//			if((++gstech_Port3UnStableCount) > _GPIO_PORT_UNSTABLE_COUNT)
//			{
//				BitPort3DetStatus = _CLR;
//				gstech_Port3UnStableCount = _CLR;
//			}
//		}
//		
//		gstech_Port3StableCount = _CLR;
//	}
//}
//
////****************************************************************************************************************************
////
//// FUNCTION       : void GSTECHGPIO_PORT4_STATUS_PORT_CHECK_PROCESS(void)
////
//// USAGE          : Port4 Status Check
////
//// INPUT          : None
////
//// OUTPUT         : None
////
////****************************************************************************************************************************
//void GSTECHGPIO_PORT4_STATUS_PORT_CHECK_PROCESS(void)
//{
//	if(!PORT_4_DETECT())
//	{
//		if(!BitPort4DetStatus)
//		{
//			if((++gstech_Port4StableCount) > _GPIO_PORT_STABLE_COUNT)
//			{
//				BitPort4DetStatus = _SET;
//				gstech_Port4StableCount = _CLR;
//			}
//		}
//		
//		gstech_Port4UnStableCount = _CLR;
//	}
//	else
//	{
//		if(BitPort4DetStatus)
//		{
//			if((++gstech_Port4UnStableCount) > _GPIO_PORT_UNSTABLE_COUNT)
//			{
//				BitPort4DetStatus = _CLR;
//				gstech_Port4UnStableCount = _CLR;
//			}
//		}
//		
//		gstech_Port4StableCount = _CLR;
//	}
//}
//
////****************************************************************************************************************************
////
//// FUNCTION       : void GSTECHGPIO_PORT5_STATUS_PORT_CHECK_PROCESS(void)
////
//// USAGE          : Port5 Status Check
////
//// INPUT          : None
////
//// OUTPUT         : None
////
////****************************************************************************************************************************
//void GSTECHGPIO_PORT5_STATUS_PORT_CHECK_PROCESS(void)
//{
//	if(!PORT_5_DETECT())
//	{
//		if(!BitPort5DetStatus)
//		{
//			if((++gstech_Port5StableCount) > _GPIO_PORT_STABLE_COUNT)
//			{
//				BitPort5DetStatus = _SET;
//				gstech_Port5StableCount = _CLR;
//			}
//		}
//		
//		gstech_Port5UnStableCount = _CLR;
//	}
//	else
//	{
//		if(BitPort5DetStatus)
//		{
//			if((++gstech_Port5UnStableCount) > _GPIO_PORT_UNSTABLE_COUNT)
//			{
//				BitPort5DetStatus = _CLR;
//				gstech_Port5UnStableCount = _CLR;
//			}
//		}
//		
//		gstech_Port5StableCount = _CLR;
//	}
//}
//
////****************************************************************************************************************************
////
//// FUNCTION       : void GSTECHGPIO_PORT6_STATUS_PORT_CHECK_PROCESS(void)
////
//// USAGE          : Port6 Status Check
////
//// INPUT          : None
////
//// OUTPUT         : None
////
////****************************************************************************************************************************
//void GSTECHGPIO_PORT6_STATUS_PORT_CHECK_PROCESS(void)
//{
//	if(!PORT_6_DETECT())
//	{
//		if(!BitPort6DetStatus)
//		{
//			if((++gstech_Port6StableCount) > _GPIO_PORT_STABLE_COUNT)
//			{
//				BitPort6DetStatus = _SET;
//				gstech_Port6StableCount = _CLR;
//			}
//		}
//		
//		gstech_Port6UnStableCount = _CLR;
//	}
//	else
//	{
//		if(BitPort6DetStatus)
//		{
//			if((++gstech_Port6UnStableCount) > _GPIO_PORT_UNSTABLE_COUNT)
//			{
//				BitPort6DetStatus = _CLR;
//				gstech_Port6UnStableCount = _CLR;
//			}
//		}
//		
//		gstech_Port6StableCount = _CLR;
//	}
//}
//
////****************************************************************************************************************************
////
//// FUNCTION       : void GSTECHGPIO_PORT7_STATUS_PORT_CHECK_PROCESS(void)
////
//// USAGE          : Port7 Status Check
////
//// INPUT          : None
////
//// OUTPUT         : None
////
////****************************************************************************************************************************
//void GSTECHGPIO_PORT7_STATUS_PORT_CHECK_PROCESS(void)
//{
//	if(!PORT_7_DETECT())
//	{
//		if(!BitPort7DetStatus)
//		{
//			if((++gstech_Port7StableCount) > _GPIO_PORT_STABLE_COUNT)
//			{
//				BitPort7DetStatus = _SET;
//				gstech_Port7StableCount = _CLR;
//			}
//		}
//		
//		gstech_Port7UnStableCount = _CLR;
//	}
//	else
//	{
//		if(BitPort7DetStatus)
//		{
//			if((++gstech_Port7UnStableCount) > _GPIO_PORT_UNSTABLE_COUNT)
//			{
//				BitPort7DetStatus = _CLR;
//				gstech_Port7UnStableCount = _CLR;
//			}
//		}
//		
//		gstech_Port7StableCount = _CLR;
//	}
//}
//
////****************************************************************************************************************************
////
//// FUNCTION       : void GSTECHGPIO_PORT8_STATUS_PORT_CHECK_PROCESS(void)
////
//// USAGE          : Port8 Status Check
////
//// INPUT          : None
////
//// OUTPUT         : None
////
////****************************************************************************************************************************
//void GSTECHGPIO_PORT8_STATUS_PORT_CHECK_PROCESS(void)
//{
//	if(!PORT_8_DETECT())
//	{
//		if(!BitPort8DetStatus)
//		{
//			if((++gstech_Port8StableCount) > _GPIO_PORT_STABLE_COUNT)
//			{
//				BitPort8DetStatus = _SET;
//				gstech_Port8StableCount = _CLR;
//			}
//		}
//		
//		gstech_Port8UnStableCount = _CLR;
//	}
//	else
//	{
//		if(BitPort8DetStatus)
//		{
//			if((++gstech_Port8UnStableCount) > _GPIO_PORT_UNSTABLE_COUNT)
//			{
//				BitPort8DetStatus = _CLR;
//				gstech_Port8UnStableCount = _CLR;
//			}
//		}
//		
//		gstech_Port8StableCount = _CLR;
//	}
//}

/* USER CODE END 2 */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
