#include <stdio.h>
#include <string.h>    // strcat �Լ��� ����� ��� ����
#include "define.h"
#include "mqtt_interface.h"
#include "wizchip_conf.h"
#include "socket.h"
#include "stm32f1xx_it.h"

//void SysTick_Handler(void) {
//	MilliTimer++;
//}

char expired(Timer* timer) 
{
	long left = timer->end_time - MilliTimer;
	return (left < 0);
}

void countdown_ms(Timer* timer, unsigned int timeout) 
{
	timer->end_time = MilliTimer + timeout;
}

void countdown(Timer* timer, unsigned int timeout) 
{
	timer->end_time = MilliTimer + (timeout * 1000);
}

int left_ms(Timer* timer) 
{
	long left = timer->end_time - MilliTimer;
	return (left < 0) ? 0 : left;
}

void InitTimer(Timer* timer) 
{
	timer->end_time = 0;
}

void NewNetwork(Network* n) 
{
	//n->my_socket = 0;
	n->mqttread = w5500_read;
	n->mqttwrite = w5500_write;
	n->disconnect = w5500_disconnect;
}

int w5500_read(Network* n, unsigned char* buffer, int len, int timeout_ms)
{
	if((getSn_SR(n->my_socket) == SOCK_ESTABLISHED) && (getSn_RX_RSR(n->my_socket)>0))
	{
		return (int)(recv(n->my_socket, buffer, len));
	}

	return 0;
}

int w5500_write(Network* n, unsigned char* buffer, int len, int timeout_ms)
{
	if(getSn_SR(n->my_socket) == SOCK_ESTABLISHED)
	{
		return (int)(send(n->my_socket, buffer, len));
	}

	return 0;
}

void w5500_disconnect(Network* n)
{
	disconnect(n->my_socket);
}


int ConnectNetwork(Network* n, uint8_t* ip, int port)
{
	socket(n->my_socket,Sn_MR_TCP,PORT_TCPS,0);	// PORT_TCPS = 6000
	connect(n->my_socket,ip,port);
	return 0;
}
	//socket(n->my_socket,Sn_MR_TCP,12345,0);
	//connect(n->my_socket,ip,port);	// port = 1883
