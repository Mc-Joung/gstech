/**
  ******************************************************************************
  * File Name          : EEProm.c
  * Description        : This file provides code for the configuration
  *                      of the IO Card instances.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2019 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
/* USER CODE BEGIN 0 */
//****************************************************************************************************************************
//  I N C L U D E    F I L E S
//****************************************************************************************************************************
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "stm32f1xx_hal.h"
//#include "iwdg.h"
#include "define.h"
#include "extern.h"
#include "gpio.h"
#include "usart.h"
#include "w5500.h"
#include "wizchip_conf.h"
#include "loopback.h"
#include "main.h"

/* USER CODE END 0 */

/* USER CODE BEGIN 1 */
//****************************************************************************************************************************
//  G L O B  A L    V A R I A B L E S
//****************************************************************************************************************************
I2C_HandleTypeDef hi2c2;
//****************************************************************************************************************************
//  L O C A L    V A R I A B L E S
//****************************************************************************************************************************
uint32_t flashAddress;
uint16_t ReadBF;
uint16_t WriteBF;
uint16_t TempCount;

//****************************************************************************************************************************
//  L O C A L     D E F I N I T I O N S 
//****************************************************************************************************************************

//****************************************************************************************************************************
//  L O C A L    F U N C T I O N
//****************************************************************************************************************************
//void EEP_WRITE_FIRMWARE_VERSION(WORD Version);
//void GSTECH_Dly10us(WORD nCount);
//void GSTECH_EEPROM_I2C_STOP(void);
//void GSTECH_EEPROM_I2C_START(void);
//void GSTECH_EEPROM_I2C_TX_BYTE(BYTE Value);
//BYTE GSTECH_EEPROM_I2C_RX_BYTE(BYTE Ack);
////void GSTECH_WRITE_xxx_EEP_DATA(BYTE Addr, BYTE *Point, BYTE Count);
//BYTE GSTECH_WRITE_xxx_EEP_DATA(BYTE Address, BYTE *Point, BYTE Length);
////void GSTECH_READ_xxx_EEP_DATA(BYTE Addr, BYTE *Point, BYTE Count);
//BYTE GSTECH_READ_xxx_EEP_DATA(BYTE Address, BYTE *Point, BYTE Length);
void GSTECH_FLASH_CHECK_BLANK(void);
void GSTECH_FLASH_READ_ALL(void);
void GSTECH_INITIAL_FLASH_SAVE_ALL(WORD Version);

//****************************************************************************************************************************
//  E X T E R N A L    F U N C T I O N
//****************************************************************************************************************************

//****************************************************************************************************************************
//  U S E R 	C O D E
//****************************************************************************************************************************

//****************************************************************************************************************************
//
// FUNCTION       : void EEP_READ_DEVICE_MAC(void)
//
// USAGE          : EEPROM Read Device Mac Address
//
// INPUT          : None
//
// OUTPUT         : None
//
//****************************************************************************************************************************
void EEP_READ_DEVICE_MAC(void)
{
	//flashAddress = MemoryDeviceMACAddr;
    //
	//for(TempCount = _CLR; TempCount < 6; TempCount += 2)
	//{
	//	ReadBF = (uint16_t)(*(__IO uint32_t*)flashAddress);
	//	gstech_Device_MAC[TempCount+0] = (BYTE)(ReadBF>>8);
	//	gstech_Device_MAC[TempCount+1] = (BYTE)(ReadBF);
	//	//printf("FLash Read[0x%lx] = [0x%x]\r\n",flash_ID, ReadBF);
	//	flashAddress += 2;
	//}

	HAL_I2C_Mem_Read(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_ADDR_DEVICE_MAC, I2C_MEMADD_SIZE_8BIT, (BYTE *)gstech_Device_MAC, 6, 50);

	//gstech_MacAddID = gstech_Device_MAC[0]+gstech_Device_MAC[1]+gstech_Device_MAC[2]+gstech_Device_MAC[3]+gstech_Device_MAC[4]+gstech_Device_MAC[5];
	#ifdef __EEPROM_DEBUG__
	printf("FLash Read gstech_Device_MAC : %02X:%02X:%02X:%02X:%02X:%02X\r\n",gstech_Device_MAC[0],gstech_Device_MAC[1],gstech_Device_MAC[2],gstech_Device_MAC[3],gstech_Device_MAC[4],gstech_Device_MAC[5]);
	printf("FLash Read gstech_MacAddID: %02X%02X%02X\r\n\r\n",gstech_Device_MAC[3],gstech_Device_MAC[4],gstech_Device_MAC[5]);
	#endif
}

//****************************************************************************************************************************
//
// FUNCTION       : void FLASH_READ_DEVICE_IP(void)
//
// USAGE          : FLASH Read Device IP Address
//
// INPUT          : None
//
// OUTPUT         : None
//
//****************************************************************************************************************************
void FLASH_READ_DEVICE_IP(void)
{
	for(TempCount = _CLR; TempCount < 4; TempCount++)
		gstech_Device_IP[TempCount] = (BYTE)(*(__IO uint32_t*)(MemoryDeviceIPAddr+(TempCount*2)));

	//HAL_I2C_Mem_Read(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_ADDR_DEVICE_IP, I2C_MEMADD_SIZE_8BIT, &gstech_Device_IP[0], 4, 10);

	#ifdef __EEPROM_DEBUG__
	printf("FLash Read MemoryDeviceIPAddr    [0x%x] - ", MemoryDeviceIPAddr);
	printf("Device_IP : %3d.%3d.%3d.%3d\r\n", gstech_Device_IP[0],gstech_Device_IP[1],gstech_Device_IP[2],gstech_Device_IP[3]);
	#endif
}

//****************************************************************************************************************************
//
// FUNCTION       : void FLASH_READ_DEVICE_SN(void)
//
// USAGE          : FLASH Read Device Subnet Mask Address
//
// INPUT          : None
//
// OUTPUT         : None
//
//****************************************************************************************************************************
void FLASH_READ_DEVICE_SN(void)
{
	for(TempCount = _CLR; TempCount < 4; TempCount++)
		gstech_Device_SN[TempCount] = (BYTE)(*(__IO uint32_t*)(MemoryDeviceSNAddr+(TempCount*2)));

	//HAL_I2C_Mem_Read(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_ADDR_DEVICE_SN, I2C_MEMADD_SIZE_8BIT, &gstech_Device_SN[0], 4, 10);

	#ifdef __EEPROM_DEBUG__
	printf("FLash Read MemoryDeviceSNAddr    [0x%x] - ", MemoryDeviceSNAddr);
	printf("Device_SN : %3d.%3d.%3d.%3d\r\n", gstech_Device_SN[0],gstech_Device_SN[1],gstech_Device_SN[2],gstech_Device_SN[3]);
	#endif
}

//****************************************************************************************************************************
//
// FUNCTION       : void FLASH_READ_DEVICE_GW(void)
//
// USAGE          : FLASH Read Device Gateway Address
//
// INPUT          : None
//
// OUTPUT         : None
//
//****************************************************************************************************************************
void FLASH_READ_DEVICE_GW(void)
{
	for(TempCount = _CLR; TempCount < 4; TempCount++)
		gstech_Device_GW[TempCount] = (BYTE)(*(__IO uint32_t*)(MemoryDeviceGWAddr+(TempCount*2)));

	//HAL_I2C_Mem_Read(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_ADDR_DEVICE_GW, I2C_MEMADD_SIZE_8BIT, (uint8_t *)gstech_Device_GW, 4, 100);

	#ifdef __EEPROM_DEBUG__
	printf("FLash Read MemoryDeviceSNAddr    [0x%x] - ", MemoryDeviceGWAddr);
	printf("Device_GW : %3d.%3d.%3d.%3d\r\n", gstech_Device_GW[0],gstech_Device_GW[1],gstech_Device_GW[2],gstech_Device_GW[3]);
	#endif
}

//****************************************************************************************************************************
//
// FUNCTION       : void FLASH_READ_DEVICE_DNS(void)
//
// USAGE          : FLASH Read Device domain Name Server Address
//
// INPUT          : None
//
// OUTPUT         : None
//
//****************************************************************************************************************************
void FLASH_READ_DEVICE_DNS(void)
{
	for(TempCount = _CLR; TempCount < 4; TempCount++)
		gstech_Device_DNS[TempCount] = (BYTE)(*(__IO uint32_t*)(MemoryDeviceDNSAddr+(TempCount*2)));

	//HAL_I2C_Mem_Read(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_ADDR_DEVICE_DNS, I2C_MEMADD_SIZE_8BIT, (uint8_t *)gstech_Device_DNS, 4, 100);

	#ifdef __EEPROM_DEBUG__
	printf("FLash Read MemoryDeviceDNSAddr   [0x%x] - ", MemoryDeviceDNSAddr);
	printf("Device_DNS : %3d.%3d.%3d.%3d\r\n", gstech_Device_DNS[0],gstech_Device_DNS[1],gstech_Device_DNS[2],gstech_Device_DNS[3]);
	#endif
}

//****************************************************************************************************************************
//
// FUNCTION       : void FLASH_READ_DEVICE_PORT(void)
//
// USAGE          : FLASH Read Device port Address
//
// INPUT          : None
//
// OUTPUT         : None
//
//****************************************************************************************************************************
void FLASH_READ_DEVICE_PORT(void)
{
	gstech_Device_PORT = (uint16_t)(*(__IO uint32_t*)MemoryDevicePORTAddr);

	//BYTE TempBF;
    //
	//HAL_I2C_Mem_Read(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_ADDR_DEVICE_PORT+0, I2C_MEMADD_SIZE_8BIT, &TempBF, 1, 50);
	//gstech_Device_PORT = TempBF;
	//gstech_Device_PORT <<= 8;
	//HAL_I2C_Mem_Read(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_ADDR_DEVICE_PORT+1, I2C_MEMADD_SIZE_8BIT, &TempBF, 1, 50);
	//gstech_Device_PORT |= TempBF;

	if((gstech_Device_PORT == _CLR) || (gstech_Device_PORT == 0xFFFF))
		gstech_Device_PORT = PORT_TCPS;
	#ifdef __EEPROM_DEBUG__
	printf("FLash Read MemoryDevicePORTAddr  [0x%x] - ", MemoryDevicePORTAddr);
	printf("Device_PORT: %d\r\n",gstech_Device_PORT);
	#endif
}

//****************************************************************************************************************************
//
// FUNCTION       : void FLASH_READ_DEVICE_DHCP(void)
//
// USAGE          : FLASH Read Device DHCP Address
//
// INPUT          : None
//
// OUTPUT         : None
//
//****************************************************************************************************************************
void FLASH_READ_DEVICE_DHCP(void)
{
	gstech_Device_DHCP = (uint16_t)(*(__IO uint32_t*)MemoryDeviceDHCPAddr);

	//HAL_I2C_Mem_Read(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_ADDR_DEVICE_DHCP, I2C_MEMADD_SIZE_8BIT, &gstech_Device_DHCP, 1, 50);

	#ifdef __EEPROM_DEBUG__
	printf("FLash Read MemoryDeviceDHCPAddr  [0x%x] - ", MemoryDeviceDHCPAddr);
	if(gstech_Device_DHCP == NETINFO_STATIC)
		printf("Device Type: STATIC\r\n\r\n");
	else if(gstech_Device_DHCP == NETINFO_DHCP)
		printf("Device Type: DHCP\r\n\r\n");
	#endif
}

//****************************************************************************************************************************
//
// FUNCTION       : void FLASH_READ_MQTT_ID(void)
//
// USAGE          : FLASH Read Mqtt ID Char
//
// INPUT          : None
//
// OUTPUT         : None
//
//****************************************************************************************************************************
void FLASH_READ_MQTT_ID(void)
{
	for(TempCount = _CLR; TempCount < _MQTT_MAX_ID_COUNT; TempCount++)
		gstech_Mqtt_UserName[TempCount]  = (char)(*(__IO uint32_t*)(MemoryMqttIDAddr+(TempCount*2)));

	gstech_UserNameLength = (uint16_t)(*(__IO uint32_t*)MemoryMqttIDLengthAddr);

 	//=================================================================================================================================
	#ifdef __EEPROM_DEBUG__
	printf("FLash Read MemoryMqttIDAddr    [0x%x] - ", MemoryMqttIDAddr);
	printf("Mqtt_ID: %s\r\n",(char *)gstech_Mqtt_UserName);
	printf("FLash gstech_UserNameLength: %d\r\n",gstech_UserNameLength);
	#endif

	//HAL_I2C_Mem_Read(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_ADDR_MQTT_ID_LENGTH, I2C_MEMADD_SIZE_8BIT,&gstech_UserNameLength, 1, 50);
    //
	//if((gstech_UserNameLength == _CLR) || (gstech_UserNameLength > _MQTT_MAX_ID_COUNT))
	//{
	//	gstech_UserNameLength = 6;
	//	memcpy(&gstech_Mqtt_UserName[0] , &targetusername[0] , gstech_UserNameLength);    
	//}
	//else
	//{
	//	HAL_I2C_Mem_Read(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_ADDR_MQTT_ID, I2C_MEMADD_SIZE_8BIT, (BYTE *)gstech_Mqtt_UserName, (uint16_t)gstech_UserNameLength, 50);
	//}
    //
	//#ifdef __EEPROM_DEBUG__
	//printf("FLash read gstech_UserNameLength: %d\r\n",gstech_UserNameLength);
	//printf("FLash read gstech_Mqtt_UserName: %s\r\n",(char *)gstech_Mqtt_UserName);
	//#endif
	//gstech_UserNameLength = 6;
	//memset(gstech_Mqtt_UserName,0,_MQTT_MAX_ID_COUNT);
	//memcpy(&gstech_Mqtt_UserName[0] , &targetusername[0] , 6);    
	//printf("gstech_Mqtt_UserName: %s\r\n",(char *)gstech_Mqtt_UserName);
}

//****************************************************************************************************************************
//
// FUNCTION       : void FLASH_READ_MQTT_PW(void)
//
// USAGE          : FLASH Read Mqtt PW Char
//
// INPUT          : None
//
// OUTPUT         : None
//
//****************************************************************************************************************************
void FLASH_READ_MQTT_PW(void)
{
	for(TempCount = _CLR; TempCount < _MQTT_MAX_PW_COUNT; TempCount++)
		gstech_Mqtt_PW[TempCount]  = (char)(*(__IO uint32_t*)(MemoryMqttPWAddr+(TempCount*2)));

	gstech_PasswordLength = (uint16_t)(*(__IO uint32_t*)MemoryMqttPWLengthAddr);;

 	//=================================================================================================================================
	#ifdef __EEPROM_DEBUG__
	printf("FLash Read MemoryMqttPWAddr          [0x%x] - ", MemoryMqttPWAddr);
	printf("Mqtt_PW: %s\r\n",(char *)gstech_Mqtt_PW);
	printf("FLash gstech_PasswordLength: %d\r\n",gstech_PasswordLength);
	#endif


	//memset(gstech_Mqtt_PW,0,_MQTT_MAX_ID_COUNT);
    //
	//HAL_I2C_Mem_Read(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_ADDR_MQTT_PW_LENGTH, I2C_MEMADD_SIZE_8BIT, &gstech_PasswordLength, 1, 50);
    //
	//if((gstech_PasswordLength == _CLR) || (gstech_PasswordLength > _MQTT_MAX_ID_COUNT))
	//{
	//	gstech_PasswordLength = 6;
	//	memcpy(&gstech_Mqtt_PW[0] , &targetpassword[0] , gstech_PasswordLength);    
	//}
	//else
	//{
	//	HAL_I2C_Mem_Read(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_ADDR_MQTT_PW, I2C_MEMADD_SIZE_8BIT, (BYTE *)gstech_Mqtt_PW, (uint16_t)gstech_UserNameLength, 50);
    //
	//}
    //
	//#ifdef __EEPROM_DEBUG__
	//printf("eeprom read gstech_PasswordLength: %d\r\n",gstech_PasswordLength);
	//printf("eeprom read gstech_Mqtt_PW: %s\r\n",(char *)gstech_Mqtt_PW);
	////printf("eeprom read Temppassword: %s\r\n",(char *)Temppassword);
	////printf("read Temppassword: %c\r\n",Temppassword[0]);
	////printf("read Temppassword: %c\r\n",Temppassword[1]);
	////printf("read Temppassword: %c\r\n",Temppassword[2]);
	////printf("read Temppassword: %c\r\n",Temppassword[3]);
	////printf("read Temppassword: %c\r\n",Temppassword[4]);
	////printf("read Temppassword: %c\r\n",Temppassword[5]);
	//#endif
	//gstech_PasswordLength = 6;
	//memset(gstech_Mqtt_PW,0,_MQTT_MAX_PW_COUNT);
	//memcpy(&gstech_Mqtt_PW[0] , &targetpassword[0] , 6);    
	//printf("gstech_Mqtt_PW: %s\r\n",(char *)gstech_Mqtt_PW);
}

//****************************************************************************************************************************
//
// FUNCTION       : void FLASH_READ_MQTT_IP(void)
//
// USAGE          : FLASH Read Mqtt IP Address
//
// INPUT          : None
//
// OUTPUT         : None
//
//****************************************************************************************************************************
void FLASH_READ_MQTT_IP(void)
{
	for(TempCount = _CLR; TempCount < 4; TempCount++)
		gstech_Mqtt_IP[TempCount] = (BYTE)(*(__IO uint32_t*)(MemoryMqttIPAddr+(TempCount*2)));

	//HAL_I2C_Mem_Read(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_ADDR_MQTT_IP, I2C_MEMADD_SIZE_8BIT, &gstech_Mqtt_IP[0], 4, 50);

	#ifdef __EEPROM_DEBUG__
	printf("FLash Read MemoryMqttIPAddr      [0x%x] - ", MemoryMqttIPAddr);
	printf("Mqtt_IP : %3d.%3d.%3d.%3d\r\n", gstech_Mqtt_IP[0],gstech_Mqtt_IP[1],gstech_Mqtt_IP[2],gstech_Mqtt_IP[3]);
	#endif
}

//****************************************************************************************************************************
//
// FUNCTION       : void FLASH_READ_MQTT_PORT(void)
//
// USAGE          : FLASH Read Mqtt port Address
//
// INPUT          : None
//
// OUTPUT         : None
//
//****************************************************************************************************************************
void FLASH_READ_MQTT_PORT(void)
{
	gstech_Mqtt_PORT = (uint16_t)(*(__IO uint32_t*)MemoryMqttPORTAddr);

	//BYTE TempBF;
    //
	//HAL_I2C_Mem_Read(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_ADDR_MQTT_PORT+0, I2C_MEMADD_SIZE_8BIT, &TempBF, 1, 50);
	//gstech_Mqtt_PORT = TempBF;
	//gstech_Mqtt_PORT <<= 8;
	//HAL_I2C_Mem_Read(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_ADDR_MQTT_PORT+1, I2C_MEMADD_SIZE_8BIT, &TempBF, 1, 50);
	//gstech_Mqtt_PORT |= TempBF;

	#ifdef __EEPROM_DEBUG__
	printf("FLash Read MemoryMqttPORTAddr    [0x%x] - ", MemoryMqttPORTAddr);
	printf("Mqtt_PORT: %d\r\n\r\n",gstech_Mqtt_PORT);
	#endif
}

//****************************************************************************************************************************
//
// FUNCTION       : void FLASH_READ_UPDATE_IP(void)
//
// USAGE          : FLASH Read Update IP Address
//
// INPUT          : None
//
// OUTPUT         : None
//
//****************************************************************************************************************************
void FLASH_READ_UPDATE_IP(void)
{
	for(TempCount = _CLR; TempCount < 4; TempCount++)
		gstech_Update_IP[TempCount] = (BYTE)(*(__IO uint32_t*)(MemoryUpdateIPAddr+(TempCount*2)));

	//HAL_I2C_Mem_Read(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_ADDR_UPDATE_IP, I2C_MEMADD_SIZE_8BIT, &gstech_Update_IP[0], 4, 10);

	#ifdef __EEPROM_DEBUG__
	printf("FLash Read MemoryUpdateIPAddr    [0x%x] - ", MemoryUpdateIPAddr);
	printf("Update_IP : %3d.%3d.%3d.%3d\r\n", gstech_Update_IP[0],gstech_Update_IP[1],gstech_Update_IP[2],gstech_Update_IP[3]);
	#endif
}

//****************************************************************************************************************************
//
// FUNCTION       : void FLASH_READ_UPDATE_PORT(void)
//
// USAGE          : FLASH Read Mqtt port Address
//
// INPUT          : None
//
// OUTPUT         : None
//
//****************************************************************************************************************************
void FLASH_READ_UPDATE_PORT(void)
{
	gstech_Update_PORT = (uint16_t)(*(__IO uint32_t*)MemoryUpdatePORTAddr);

	//BYTE TempBF;
    //
	//HAL_I2C_Mem_Read(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_ADDR_UPDATE_PORT+0, I2C_MEMADD_SIZE_8BIT, &TempBF, 1, 10);
	//gstech_Update_PORT = TempBF;
	//gstech_Update_PORT <<= 8;
	//HAL_I2C_Mem_Read(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_ADDR_UPDATE_PORT+1, I2C_MEMADD_SIZE_8BIT, &TempBF, 1, 10);
	//gstech_Update_PORT |= TempBF;

	if((gstech_Mqtt_PORT == _CLR) || (gstech_Mqtt_PORT == 0xFFFF))
		gstech_Update_PORT = 80;
	#ifdef __EEPROM_DEBUG__
	printf("FLash Read MemoryUpdatePORTAddr  [0x%x] - ", MemoryUpdatePORTAddr);
	printf("Update_PORT: %d\r\n",gstech_Update_PORT);
	#endif
}

//****************************************************************************************************************************
//
// FUNCTION       : void FLASH_EEP_READ_STATUS_CYCLEREAD_DEVICE_DHCP(void)
//
// USAGE          : FLASH Read Status Cycle Address
//
// INPUT          : None
//
// OUTPUT         : None
//
//****************************************************************************************************************************
void FLASH_READ_STATUS_CYCLE(void)
{
	gstech_StatusCycle = (uint8_t)(*(__IO uint32_t*)MemoryUpdateStatusAddr);

	//HAL_I2C_Mem_Read(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_ADDR_STATUS_CYCLE, I2C_MEMADD_SIZE_8BIT, &gstech_StatusCycle, 1, 10);

	//BitMqttContinueSendEnable = _CLR;
	//if(gstech_StatusCycle)
	//	BitMqttContinueSendEnable = _SET;

	#ifdef __EEPROM_DEBUG__
	printf("FLash Read MemoryUpdateStatusAddr[0x%x] - ", MemoryUpdateStatusAddr);
	printf("StatusCycle: %d\r\n",gstech_StatusCycle);
	#endif
}

//****************************************************************************************************************************
//
// FUNCTION       : void FLASH_READ_PERIOD(void)
//
// USAGE          : FLASH Read Period Address
//
// INPUT          : None
//
// OUTPUT         : None
//
//****************************************************************************************************************************
void FLASH_READ_PERIOD(void)
{
	gstech_Period = (uint16_t)(*(__IO uint32_t*)MemoryUpdatePeriodAddr);

	//BYTE TempBF;
    //
	//HAL_I2C_Mem_Read(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_ADDR_PERIOD+0, I2C_MEMADD_SIZE_8BIT, &TempBF, 1, 10);
	//gstech_Period = TempBF;
	//gstech_Period <<= 8;
	//HAL_I2C_Mem_Read(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_ADDR_PERIOD+1, I2C_MEMADD_SIZE_8BIT, &TempBF, 1, 10);
	//gstech_Period |= TempBF;

	//gstech_PeriodCount = gstech_Period;

	#ifdef __EEPROM_DEBUG__
	printf("FLash Read MemoryUpdatePeriodAddr[0x%x] - ", MemoryUpdatePeriodAddr);
	printf("Period: %d\r\n\r\n",gstech_Period);
	#endif
}

//****************************************************************************************************************************
//
// FUNCTION       : void FLASH_READ_FIRMWARE_VERSION(void)
//
// USAGE          : FLASH Read Firmware Version Address
//
// INPUT          : None
//
// OUTPUT         : None
//
//****************************************************************************************************************************
void FLASH_READ_FIRMWARE_VERSION(void)
{
	gstech_Read_FW_Version = (uint16_t)(*(__IO uint32_t*)VersionAddr);

	//BYTE TempBF;
    //
	////flashAddress = MemoryVersionWriteEnableAddr;
    //
	////TempBF = (uint16_t)(*(__IO uint32_t*)flashAddress);
    //
	//HAL_I2C_Mem_Read(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_ADDR_FIRMWARE_VERSION+0, I2C_MEMADD_SIZE_8BIT, &TempBF, 1, 10);
	//gstech_Read_FW_Version = TempBF;
	//gstech_Read_FW_Version <<= 8;
	//HAL_I2C_Mem_Read(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_ADDR_FIRMWARE_VERSION+1, I2C_MEMADD_SIZE_8BIT, &TempBF, 1, 10);
	//gstech_Read_FW_Version |= TempBF;
    //
    //
	//HAL_I2C_Mem_Read(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_ADDR_FIRMWARE_VERSION_ENABLE, I2C_MEMADD_SIZE_8BIT, &TempBF, 1, 10);
	//printf("Flash Read Version Enable = %d\r\n", TempBF);
    //
	//if(TempBF == 1)
	//{
	//	GSTECH_WRITE_VER_TO_FLASH(gstech_Read_FW_Version);
	//	#ifdef __EEPROM_DEBUG__
	//	printf("Flash Write gstech_FW_Version..........\r\n");
	//	#endif
	//}

	#ifdef __EEPROM_DEBUG__
	printf("Flash read gstech_Read_FW_Version = [v%d.%d] \r\n", (uint8_t)gstech_Read_FW_Version/10, (uint8_t)gstech_Read_FW_Version%10);
	#endif
}

//****************************************************************************************************************************
//
// FUNCTION       : void GSTECH_FLASH_READ_ALL(void)
//
// USAGE          : FLASH Read All data
//
// INPUT          : None
//
// OUTPUT         : None
//
//****************************************************************************************************************************
void GSTECH_FLASH_READ_ALL(void)
{
	EEP_READ_DEVICE_MAC();

	FLASH_READ_DEVICE_IP();
	FLASH_READ_DEVICE_SN();
	FLASH_READ_DEVICE_GW();
	FLASH_READ_DEVICE_DNS();
	FLASH_READ_DEVICE_PORT();
	FLASH_READ_DEVICE_DHCP();

	FLASH_READ_MQTT_ID();
	FLASH_READ_MQTT_PW();
	FLASH_READ_MQTT_IP();
	FLASH_READ_MQTT_PORT();

	FLASH_READ_UPDATE_IP();
	FLASH_READ_UPDATE_PORT();
	FLASH_READ_STATUS_CYCLE();
	FLASH_READ_PERIOD();

	FLASH_READ_FIRMWARE_VERSION();
}

////****************************************************************************************************************************
////
//// FUNCTION       : void EEP_WRITE_FIRMWARE_VERSION(WORD Version)
////
//// USAGE          : EEPROM Write Firmware Version Address
////
//// INPUT          : None
////
//// OUTPUT         : None
////
////****************************************************************************************************************************
//void EEP_WRITE_FIRMWARE_VERSION(WORD Version)
//{
//	BYTE TempBF;
//    
//	TempBF = (BYTE)(Version>>8);
//	HAL_I2C_Mem_Write(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_ADDR_FIRMWARE_VERSION+0, I2C_MEMADD_SIZE_8BIT, &TempBF, 1, 50);  
// 	HAL_Delay(10);   
//	TempBF = (BYTE)(Version);
//	HAL_I2C_Mem_Write(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_ADDR_FIRMWARE_VERSION+1, I2C_MEMADD_SIZE_8BIT, &TempBF, 1, 50);  
// 	HAL_Delay(10);   
//
//	TempBF = _CLR;
//	HAL_I2C_Mem_Write(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_ADDR_FIRMWARE_VERSION_ENABLE, I2C_MEMADD_SIZE_8BIT, &TempBF, 1, 50);  
// 	HAL_Delay(10);   
//
//	#ifdef __EEPROM_DEBUG__
//	printf("eeprom gstech_FW_Version[v%d.%d] Start .....\r\n", gstech_FW_Version/10, gstech_FW_Version%10);
//	#endif
//}

//****************************************************************************************************************************
//
// FUNCTION       : void GSTECH_FLASH_SAVE_ALL(void)
//
// USAGE          : Saving Set All Data to Flash
//
// INPUT          : None
//
// OUTPUT         : None
//
//****************************************************************************************************************************
void GSTECH_FLASH_SAVE_ALL(void)
{
	//volatile HAL_StatusTypeDef status_erase;
	FLASH_EraseInitTypeDef EraseInitStruct;
	uint32_t PageError;
	
	/* Unock the Flash to enable the flash control register access *************/
	while(HAL_FLASH_Unlock()!=HAL_OK)
	{
		while(HAL_FLASH_Lock()!=HAL_OK);//Weird fix attempt
	}
	
	/* Allow Access to option bytes sector */
	while(HAL_FLASH_OB_Unlock()!=HAL_OK)
	{
		while(HAL_FLASH_OB_Lock()!=HAL_OK);//Weird fix attempt
	}
	
	/* Fill EraseInit structure*/
	EraseInitStruct.TypeErase = FLASH_TYPEERASE_PAGES;
	EraseInitStruct.PageAddress = VersionAddr;
	EraseInitStruct.NbPages = 1;
	
	//HAL_FLASHEx_Erase(&EraseInitStruct, &PageError);
    if(HAL_FLASHEx_Erase(&EraseInitStruct, &PageError) != HAL_OK)
    {
      	/* Error occurred while page erase */
		printf("Allpication FLASH Erase Fault ..............\r\n");
      	return;
    }

	printf("Application FLASH Erase Done & Write Start Flash Data ..............\r\n");

 	//=================================================================================================================================
	HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, VersionAddr, gstech_Read_FW_Version);
 
 	#ifdef __EEPROM_DEBUG__
	printf("FLash Write gstech_Read_FW_Version[v%d.%d] \r\n", gstech_Read_FW_Version/10, gstech_Read_FW_Version%10);
	#endif

 	//=================================================================================================================================
	for(TempCount = _CLR; TempCount < 4; TempCount++)
		HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, MemoryDeviceIPAddr+(TempCount*2), (WORD)gstech_Device_IP[TempCount]);

	#ifdef __EEPROM_DEBUG__
	printf("FLash Write MemoryDeviceIPAddr    [0x%x] - ", MemoryDeviceIPAddr);
	printf("Device_IP : %3d.%3d.%3d.%3d\r\n", gstech_Device_IP[0],gstech_Device_IP[1],gstech_Device_IP[2],gstech_Device_IP[3]);
	#endif

	//=================================================================================================================================
	for(TempCount = _CLR; TempCount < 4; TempCount++)
		HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, MemoryDeviceSNAddr+(TempCount*2), (WORD)gstech_Device_SN[TempCount]);
 
	#ifdef __EEPROM_DEBUG__
	printf("FLash Write MemoryDeviceSNAddr    [0x%x] - ", MemoryDeviceSNAddr);
	printf("Device_SN : %3d.%3d.%3d.%3d\r\n", gstech_Device_SN[0],gstech_Device_SN[1],gstech_Device_SN[2],gstech_Device_SN[3]);
	#endif

	//=================================================================================================================================
	for(TempCount = _CLR; TempCount < 4; TempCount++)
		HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, MemoryDeviceGWAddr+(TempCount*2), (WORD)gstech_Device_GW[TempCount]);
 
	#ifdef __EEPROM_DEBUG__
	printf("FLash Write MemoryDeviceSNAddr    [0x%x] - ", MemoryDeviceGWAddr);
	printf("Device_GW : %3d.%3d.%3d.%3d\r\n", gstech_Device_GW[0],gstech_Device_GW[1],gstech_Device_GW[2],gstech_Device_GW[3]);
	#endif

	//=================================================================================================================================
	for(TempCount = _CLR; TempCount < 4; TempCount++)
		HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, MemoryDeviceDNSAddr+(TempCount*2), (WORD)gstech_Device_DNS[TempCount]);

	#ifdef __EEPROM_DEBUG__
	printf("FLash Write MemoryDeviceDNSAddr   [0x%x] - ", MemoryDeviceDNSAddr);
	printf("Device_DNS : %3d.%3d.%3d.%3d\r\n", gstech_Device_DNS[0],gstech_Device_DNS[1],gstech_Device_DNS[2],gstech_Device_DNS[3]);
	#endif

 	//=================================================================================================================================
	WriteBF = gstech_Device_PORT;
	HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, MemoryDevicePORTAddr, WriteBF);

  	#ifdef __EEPROM_DEBUG__
	printf("FLash Write gstech_Device_PORT: [%d]\r\n",gstech_Device_PORT);
	#endif

	//=================================================================================================================================
	WriteBF = (WORD)gstech_Device_DHCP;
	HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, MemoryDeviceDHCPAddr, WriteBF);
 
 	#ifdef __EEPROM_DEBUG__
	printf("FLash Write gstech_Device_DHCP: [%d]\r\n",gstech_Device_DHCP);
	#endif

	//=================================================================================================================================
	for(TempCount = _CLR; TempCount < _MQTT_MAX_ID_COUNT; TempCount++)
		HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, MemoryMqttIDAddr+(TempCount*2), gstech_Mqtt_UserName[TempCount]);
    
	#ifdef __EEPROM_DEBUG__
	printf("FLash Write Mqtt_ID: %s\r\n",(char *)gstech_Mqtt_UserName);
	#endif
    
	//=================================================================================================================================
	for(TempCount = _CLR; TempCount < _MQTT_MAX_PW_COUNT; TempCount++)
		HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, MemoryMqttPWAddr+(TempCount*2), gstech_Mqtt_PW[TempCount]);
    
 	#ifdef __EEPROM_DEBUG__
	printf("FLash Write Mqtt_PW: %s\r\n",(char *)gstech_Mqtt_PW);
	#endif

	//=================================================================================================================================
	HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, MemoryMqttIDLengthAddr, gstech_UserNameLength);

 	#ifdef __EEPROM_DEBUG__
	printf("FLash Write gstech_UserNameLength: [%d]\r\n",gstech_UserNameLength);
	#endif

 	//=================================================================================================================================
	HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, MemoryMqttPWLengthAddr, gstech_PasswordLength);

 	#ifdef __EEPROM_DEBUG__
	printf("FLash Write gstech_PasswordLength: [%d]\r\n",gstech_PasswordLength);
	#endif

 	//=================================================================================================================================
	for(TempCount = _CLR; TempCount < 4; TempCount++)
		HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, MemoryMqttIPAddr+(TempCount*2), (WORD)gstech_Mqtt_IP[TempCount]);

	#ifdef __EEPROM_DEBUG__
	printf("FLash Write MemoryMqttIPAddr   [0x%x] - ", MemoryMqttIPAddr);
	printf("Mqtt_IP : %3d.%3d.%3d.%3d\r\n", gstech_Mqtt_IP[0],gstech_Mqtt_IP[1],gstech_Mqtt_IP[2],gstech_Mqtt_IP[3]);
	#endif

 	//=================================================================================================================================
	WriteBF = gstech_Mqtt_PORT;
	HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, MemoryMqttPORTAddr, WriteBF);
 
 	#ifdef __EEPROM_DEBUG__
	printf("FLash Write gstech_Mqtt_PORT: [%d]\r\n",gstech_Mqtt_PORT);
	#endif

	//=================================================================================================================================
	for(TempCount = _CLR; TempCount < 4; TempCount++)
		HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, MemoryUpdateIPAddr+(TempCount*2), (WORD)gstech_Update_IP[TempCount]);

	#ifdef __EEPROM_DEBUG__
	printf("FLash Write MemoryUpdateIPAddr   [0x%x] - ", MemoryUpdateIPAddr);
	printf("Update_IP : %3d.%3d.%3d.%3d\r\n", gstech_Update_IP[0],gstech_Update_IP[1],gstech_Update_IP[2],gstech_Update_IP[3]);
	#endif

 	//=================================================================================================================================
	WriteBF = gstech_Update_PORT;
	HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, MemoryUpdatePORTAddr, WriteBF);
 
  	#ifdef __EEPROM_DEBUG__
	printf("FLash Write gstech_Update_PORT: [%d]\r\n",gstech_Update_PORT);
	#endif

	//=================================================================================================================================
	WriteBF = (WORD)gstech_StatusCycle;
	HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, MemoryUpdateStatusAddr, WriteBF);
 	#ifdef __EEPROM_DEBUG__
	printf("FLash Write gstech_StatusCycle: [%d]\r\n",gstech_StatusCycle);
	#endif
 
 	//=================================================================================================================================
	WriteBF = gstech_Period;
	HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, MemoryUpdatePeriodAddr, WriteBF);

 	#ifdef __EEPROM_DEBUG__
	printf("FLash Write gstech_Period: [%d]\r\n",gstech_Period);
	#endif
 
 	//=================================================================================================================================
	HAL_FLASH_Lock();

	//=========================================================================================================================
    if(EEPromFLAGSbits.BitWord == 0xFFFF)
    {
		memcpy(&gWIZNETINFO.ip[0],  gstech_Device_IP, 4);
		memcpy(&gWIZNETINFO.gw[0],  gstech_Device_GW, 4);
		memcpy(&gWIZNETINFO.sn[0],  gstech_Device_SN, 4);
		memcpy(&gWIZNETINFO.mac[0], gstech_Device_MAC, 6);

    	ctlnetwork(CN_SET_NETINFO, (void*)&gWIZNETINFO);
	}

	printf("Flash Write Done..............\r\n");
	EEPromFLAGSbits.BitWord 	= _CLR;
}

////****************************************************************************************************************************
////
//// FUNCTION       : void GSTECH_INITIAL_DEFAULT_EEPROM(void)
////
//// USAGE          : Write to the specified register of the AT24LC08.
////					RegValue: this member specifies the register to read:
//// INPUT          : None
////
//// OUTPUT         : None
////
////****************************************************************************************************************************
//void GSTECH_INITIAL_DEFAULT_EEPROM(void)
//{
//	//BYTE TempBF;
//
//	//memcpy(&gstech_Device_IP , &gWIZNETINFO.ip[0] , 4);
//	//memcpy(&gstech_Device_SN , &gWIZNETINFO.sn[0] , 4);
//	//memcpy(&gstech_Device_GW , &gWIZNETINFO.gw[0] , 4);
//	//memcpy(&gstech_Device_DNS , &gWIZNETINFO.dns[0] , 4);
//	//gstech_Device_PORT = PORT_TCPS;
//	//gstech_Device_DHCP = NETINFO_DHCP;
//	//printf("origin gstech_Device_IP : %3d.%3d.%3d.%3d\r\n", gstech_Device_IP[0],gstech_Device_IP[1],gstech_Device_IP[2],gstech_Device_IP[3]);
//	//printf("origin gstech_Device_SN : %3d.%3d.%3d.%3d\r\n", gstech_Device_SN[0],gstech_Device_SN[1],gstech_Device_SN[2],gstech_Device_SN[3]);
//	//printf("origin gstech_Device_GW : %3d.%3d.%3d.%3d\r\n", gstech_Device_GW[0],gstech_Device_GW[1],gstech_Device_GW[2],gstech_Device_GW[3]);
//	//printf("origin gstech_Device_PORT: [0x%x] = %d\r\n",gstech_Device_PORT,gstech_Device_PORT);
//	//printf("origin gstech_Device_DHCP: %d\r\n",gstech_Device_DHCP);
//
//	//-------------------------------------------------------------------------------------------------------------------------
//	//printf("origin gstech_Mqtt_IP : %3d.%3d.%3d.%3d\r\n", gstech_Mqtt_IP[0],gstech_Mqtt_IP[1],gstech_Mqtt_IP[2],gstech_Mqtt_IP[3]);
//	//printf("origin gstech_Mqtt_PORT: [0x%x] = %d\r\n",gstech_Mqtt_PORT,gstech_Mqtt_PORT);
// 
//	//-------------------------------------------------------------------------------------------------------------------------
//	memcpy(&gstech_Mqtt_UserName , &targetusername , 6);
//	memcpy(&gstech_Mqtt_PW , &targetpassword , 6);
//	//printf("origin gstech_Mqtt_UserName: %s\r\n",gstech_Mqtt_UserName);
//	//printf("origin gstech_Mqtt_PW: %s\r\n",gstech_Mqtt_PW);
//
//	//-------------------------------------------------------------------------------------------------------------------------
//	//printf("origin gstech_Update_IP : %3d.%3d.%3d.%3d\r\n", gstech_Update_IP[0],gstech_Update_IP[1],gstech_Update_IP[2],gstech_Update_IP[3]);
//	//printf("origin gstech_Update_PORT: %d\r\n",gstech_Update_PORT);
//
//	//gstech_FW_Version[4] = "v0.0";
//	//HAL_I2C_Mem_Write(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_ADDR_FIRMWARE_VERSION, I2C_MEMADD_SIZE_8BIT, (BYTE *)gstech_FW_Version, 4, 500);  
//	//gstech_FW_Version = 0;
//
//	//TempBF = (BYTE)(gstech_FW_Version>>8);
//	//HAL_I2C_Mem_Write(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_ADDR_FIRMWARE_VERSION+0, I2C_MEMADD_SIZE_8BIT, &TempBF, 1, 50);  
// 	//HAL_Delay(100);   
//	//TempBF = (BYTE)(gstech_FW_Version);
//	//HAL_I2C_Mem_Write(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_ADDR_FIRMWARE_VERSION+1, I2C_MEMADD_SIZE_8BIT, &TempBF, 1, 50);  
// 	//HAL_Delay(100);   
//
//	//-------------------------------------------------------------------------------------------------------------------------
//	//gstech_StatusCycle = 0;
//	//gstech_Period = 0;
//	//printf("origin gstech_StatusCycle: %d\r\n",gstech_StatusCycle);
//	//printf("origin gstech_Period: %d\r\n\r\n\r\n",gstech_Period);
//
//	//-------------------------------------------------------------------------------------------------------------------------
//	EEPromFLAGSbits.BitWord = 0x7FFF;
//	GSTECH_EEPROM_SAVE_ALL();
//}

//****************************************************************************************************************************
//
// FUNCTION       : void EEP_CHECK_BLANK(void)
//
// USAGE          : EEPROM Blank Check
//
// INPUT          : None
//
// OUTPUT         : None
//
//****************************************************************************************************************************
void EEP_CHECK_BLANK(void)
{
	//BYTE TempBF;
    //
	//HAL_I2C_Mem_Read(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_INIT_ADDRESS, I2C_MEMADD_SIZE_8BIT, &TempBF, 1, 10);
    //
	//while(_SET)
	//{
	//	if(TempBF != _CHIP_BLANK_ID)
	//	{
	//		GSTECH_INITIAL_DEFAULT_EEPROM();
    //
	//		TempBF = _CHIP_BLANK_ID;
	//		HAL_I2C_Mem_Write(&hi2c2, _EEP_DEVICE_ADDRESS, _EEP_INIT_ADDRESS, I2C_MEMADD_SIZE_8BIT, &TempBF, 1, 10);  
	//		printf("EEP_CHECK_BLANK Initial Done..............\r\n");
	//		break;	
	//	}
	//	else
	//		break;
	//}			
    
	GSTECH_FLASH_READ_ALL();
}

/* USER CODE END 1 */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
