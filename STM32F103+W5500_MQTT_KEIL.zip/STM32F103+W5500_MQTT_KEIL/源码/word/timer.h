#ifndef __TIMER_H_
#define __TIMER_H_
void TIM2_Configuration(void);
void TIM2_NVIC_Configuration(void);	
#endif