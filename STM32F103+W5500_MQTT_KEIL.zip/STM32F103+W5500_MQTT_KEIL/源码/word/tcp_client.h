#ifndef __TCP_CLIENT_H_
#define __TCP_CLIENT_H_

void MQTT_CON_ALI(void);
void replace_string(char *result, char *source, char* s1, char *s2);
#endif

