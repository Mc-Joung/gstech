#ifndef __AUTO_UPDATE_H
#define	__AUTO_UPDATE_H

#define __AUTO_UPDATE_DEBUG__

#define NORMAL_STATE            			0
#define NEW_APP_IN_BACK         			1           	// there is new app in back address
#define CONFIGTOOL_FW_UP        			2           	// configtool update f/w in app
//#define BootAddress 	 					0x08000000u 	// 0x08000000-0x0800FFFF Boot size is 64K
//#define ApplicationAddress 	 				0x08012000u 	// 0x08013000-0x08028FFF App size is 95K
//#define VerAddr                 			0x08029000u  	// Version

//#define AppBackupAddress     				0x08022000u 	// 0x08026000-0x0802FFFF App back start address and size is 64k
//#define ConfigAddr		     			0x08032000u 	// 0x08039000-0x0803AFFF APP backup and configaddr start address is 64k 


#include <stdio.h>
#include <string.h>    // strcat �Լ��� ����� ��� ����
//#include "types.h"
//#include "w5500_conf.h"
//#include "string.h"
#include "socket.h"
#include "w5500.h"
//#include "utility.h"
#define  W5500_UPDATE  4
#define  AUTO_UPDATE_PORT 30000
extern uint8 update_flag;

void w5500_version(void);
char C2D(uint8 c);
uint32 ATOI32(char* str,uint16 base	);
void GSTECH_MQTT_APPLICATION_UPDATE_PROCESS(BYTE PortNo);
void GSTECH_WRITE_VER_TO_FLASH(WORD Version);

extern void GSTECH_DELAY_1mS(WORD Delay);
extern void mid(char* src, char* s1, char* s2, char* sub);
extern GlobalFlagsType GLOBAL2FLAGSbits;
extern int8 sub[10];

#endif
