#include <stdio.h>
#include <stdlib.h>    // strcat �Լ��� ����� ��� ����
#include "define.h"
#include "extern.h"
#include "stm32f1xx_hal.h"
#include "stm32f1xx_hal_flash.h"
#include "auto_update.h"


#define Sn_DIPR0(ch)                    (0x000C08 + (ch<<5))
#define Sn_DIPR1(ch)                    (0x000D08 + (ch<<5))
#define Sn_DIPR2(ch)                    (0x000E08 + (ch<<5))
#define Sn_DIPR3(ch)                    (0x000F08 + (ch<<5))
#define Sn_DPORT0(ch)                   (0x001008 + (ch<<5))
#define Sn_DPORT1(ch)                   (0x001108 + (ch<<5))
#define Sn_RX_RD0(ch)                   (0x002808 + (ch<<5))
#define Sn_RX_RD1(ch)                   (0x002908 + (ch<<5))

uint8_t flg=0;
uint8_t tail;
uint32 fLen=0;
uint32_t data_len;
uint16_t rx_len;
int8 sub[10];
uint8_t Buffer[BUFFER_SIZE]={0};

uint32_t content_len=0;
uint32_t recv_count=0;

#define FLASH_BANK_SIZE 		(0x34000)		//104Page
#define FLASH_PAGE_SIZE_USER 	(0x800)			//2kB

void mid(int8* src, int8* s1, int8* s2, int8* sub)
{
	int8* sub1;
	int8* sub2;
	uint16_t n;

  	sub1=strstr(src,s1);
  	sub1+=strlen(s1);
  	sub2=strstr(sub1,s2);
  	n=sub2-sub1;
  	strncpy(sub,sub1,n);
  	sub[n]=0;
}
/**
*@brief  	This function is being called by recv() also.
					This function read the Rx read pointer register
					and after copy the data from receive buffer update the Rx write pointer register.
					User should read upper byte first and lower byte later to get proper value.
*@param		s: socket number
*@param		Writedata: data buffer to receive
*@param		len: data length
*@return  None
*/
uint32 ATOI32(char* str,uint16 base	)
{
  uint32 num = 0;
  while (*str !=0)
          num = num * base + C2D(*str++);
  return num;
}
char C2D(uint8 c)
{
	if (c >= '0' && c <= '9')
		return c - '0';
	if (c >= 'a' && c <= 'f')
		return 10 + c -'a';
	if (c >= 'A' && c <= 'F')
		return 10 + c -'A';
	return (char)c;
}

uint8 connect2(SOCKET s, uint8 * addr, uint16 port)
{
    uint8 ret;

    if(((addr[0] == 0xFF) && (addr[1] == 0xFF) && (addr[2] == 0xFF) && (addr[3] == 0xFF)) ||
       ((addr[0] == 0x00) && (addr[1] == 0x00) && (addr[2] == 0x00) && (addr[3] == 0x00)) ||
        (port == 0x00))
    {
      ret = 0;
    }
    else
    {
        ret = 1;
        // set destination IP
        WIZCHIP_WRITE( Sn_DIPR0(s), addr[0]);
        WIZCHIP_WRITE( Sn_DIPR1(s), addr[1]);
        WIZCHIP_WRITE( Sn_DIPR2(s), addr[2]);
        WIZCHIP_WRITE( Sn_DIPR3(s), addr[3]);
        WIZCHIP_WRITE( Sn_DPORT0(s), (uint8)((port & 0xff00) >> 8));
        WIZCHIP_WRITE( Sn_DPORT1(s), (uint8)(port & 0x00ff));
        WIZCHIP_WRITE( Sn_CR(s) ,Sn_CR_CONNECT);

        /* wait for completion */
        while ( WIZCHIP_READ(Sn_CR(s) ) ) ;

        while ( WIZCHIP_READ(Sn_SR(s)) != SOCK_SYNSENT )
        {
            if(WIZCHIP_READ(Sn_SR(s)) == SOCK_ESTABLISHED)
            {
                break;
            }
            if (getSn_IR(s) & Sn_IR_TIMEOUT)
            {
                WIZCHIP_WRITE(Sn_IR(s), (Sn_IR_TIMEOUT));  // clear TIMEOUT Interrupt
                ret = 0;
                break;
            }
        }
    }

   return ret;
}

void unlockFlashAndEraseMemory(void)
{
	FLASH_EraseInitTypeDef EraseInitStruct;
	uint32_t PageError;

	/* Unock the Flash to enable the flash control register access *************/
	while(HAL_FLASH_Unlock()!=HAL_OK)
	{
		while(HAL_FLASH_Lock()!=HAL_OK);//Weird fix attempt
	}

	/* Allow Access to option bytes sector */
	while(HAL_FLASH_OB_Unlock()!=HAL_OK)
	{
		while(HAL_FLASH_OB_Lock()!=HAL_OK);//Weird fix attempt
	}

	/* Fill EraseInit structure*/
	EraseInitStruct.TypeErase = FLASH_TYPEERASE_PAGES;
	EraseInitStruct.PageAddress = ApplicationAddress;
	EraseInitStruct.NbPages = FLASH_BANK_SIZE/FLASH_PAGE_SIZE_USER;
 
	HAL_FLASHEx_Erase(&EraseInitStruct, &PageError);
}

void lockFlash(void)
{
	/* Lock the Flash to enable the flash control register access *************/
	while(HAL_FLASH_Lock()!=HAL_OK)
	{
		while(HAL_FLASH_Unlock()!=HAL_OK);//Weird fix attempt
	}

	/* Lock Access to option bytes sector */
	while(HAL_FLASH_OB_Lock()!=HAL_OK)
	{
		while(HAL_FLASH_OB_Unlock()!=HAL_OK);//Weird fix attempt
	}
}

//void GSTECH_WRITE_VER_TO_FLASH(WORD Version)//flash
//{
// 	FLASH_EraseInitTypeDef EraseInitStruct;
//	//volatile HAL_StatusTypeDef status_erase;
//	uint32_t PageError;
//
//	flashVersion = VersionAddr;
//
//	/* Unock the Flash to enable the flash control register access *************/
//	while(HAL_FLASH_Unlock()!=HAL_OK)
//	{
//		while(HAL_FLASH_Lock()!=HAL_OK);//Weird fix attempt
//	}
//
//	/* Allow Access to option bytes sector */
//	while(HAL_FLASH_OB_Unlock()!=HAL_OK)
//	{
//		while(HAL_FLASH_OB_Lock()!=HAL_OK);//Weird fix attempt
//	}
//
//	/* Fill EraseInit structure*/
//	EraseInitStruct.TypeErase = FLASH_TYPEERASE_PAGES;
//	EraseInitStruct.PageAddress = flashVersion;
//	EraseInitStruct.NbPages = 1;
// 
//	HAL_FLASHEx_Erase(&EraseInitStruct, &PageError);
//   
//	HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, flashVersion, Version);
//  	HAL_FLASH_Lock();
//
// 	printf("Write Boot flashVersion[0x%lx] = [v%d.%d] \r\n", flashVersion, (uint8_t)(Version)/10, (uint8_t)(Version)%10);
//}
 
//****************************************************************************************************************************
//
// FUNCTION       : void GSTECH_MQTT_APPLICATION_UPDATE_PROCESS(BYTE PortNo)
//
// USAGE          : Application Firmware Download and FLash Write
//
// INPUT          : Port Number
//
// OUTPUT         : None
//
//****************************************************************************************************************************
void GSTECH_MQTT_APPLICATION_UPDATE_PROCESS(BYTE PortNo)
{
	char *p;
	uint32_t i = _CLR;
	uint16_t len = _CLR;
	uint32_t rxlen = _CLR;
  	uint32_t tmplen = _CLR;
	uint32_t flashdest = ApplicationAddress;
	uint16_t Writedata;
    uint8_t pagecount = _CLR;
  	uint32_t FileSize = _CLR;

  	switch(getSn_SR(PortNo))
  	{
		case SOCK_ESTABLISHED:
    		#ifdef __AUTO_UPDATE_DEBUG__
			printf("connected server ..... \r\n");
    		#endif

  	  		if(getSn_IR(PortNo) & Sn_IR_CON)
  	  		{
  	  		  	setSn_IR(PortNo, Sn_IR_CON);
  	  		}

  	  		send(PortNo,(uint8 *)POST_UPDATE_MSG,sizeof(POST_UPDATE_MSG));	

			if ((len = getSn_RX_RSR(PortNo)) > _CLR)		
  	  		{
 	          	len = recv(PortNo, (uint8*)Buffer, len);
    			#ifdef __AUTO_UPDATE_DEBUG__
				printf("len:0x%x - [%d]\r\n",(uint16_t)(len),(uint16_t)(len));
			    printf("%s\r\n",Buffer);			   
   				#endif
 				mid((char*)Buffer,"Content-Length: ","\r\n",sub);
				p=strstr((char*)Buffer,"\r\n\r\n");
				tmplen =len-( p-(char*)Buffer)-5;
				content_len = FileSize = ATOI32(sub,10);
            
				flg = _CLR;
				BitMqttMessageStatus = _CLR;
				if(((len - tmplen)%2)==_CLR)
					BitMqttMessageStatus = _SET;
				pagecount = _CLR;

    			#ifdef __AUTO_UPDATE_DEBUG__
				printf("tmplen:0x%lx - [%ld]\r\n",tmplen, tmplen);
				printf("len - tmplen:0x%lx - [%ld]\r\n",(len - tmplen),(len - tmplen));
				printf("content_len:0x%lx - [%ld]\r\n",content_len,content_len);
 				printf("BitMqttMessageStatus = 0x%x\r\n",(BYTE)BitMqttMessageStatus);
  				#endif

				if(content_len >= 1000)	// File Size 1000Byte Over
				{	// HTTP/1.1 200 OK 
					//========================================================================
					gstech_W5500TimeOutCount = _TIME_60000MS_VALUE;
					BitTimeOverW5500Check = _CLR;
           			unlockFlashAndEraseMemory();

					//========================================================================
					while((rxlen!=content_len))	// && !BitTimeOverW5500Check)
					{ 						
	   					//========================================================================
 						BitTimeToggle = ~BitTimeToggle;
 						if(BitTimeToggle)
 							HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_7);
 						else
 							HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_8);
    					
    					//========================================================================
 	            		if(rxlen == 0)
  	            		{
							if(BitMqttMessageStatus)
							{
							  	flg = 1;
								tail = Buffer[len-1];
								printf("Start tail:0x%x - [%d]\r\n",tail,tail);
							}
                	
							for(i=0;i<tmplen-(BYTE)(BitMqttMessageStatus);i=i+2) 
							{
								Writedata = *(p+4+i+1);
								Writedata=(Writedata<<8) + (*(p+4+i));
								HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, flashdest, Writedata);
								recv_count++;
								flashdest += 2;
							}									
							rxlen = tmplen + (BYTE)BitMqttMessageStatus;
 							tmplen=0;
						}
						else
						{
							tmplen = getSn_RX_RSR(PortNo);
                	
							if(tmplen>0)
							{	
								if(BitMqttMessageStatus)
								{
								  	tmplen=recv(PortNo, (uint8*)(Buffer+1),tmplen);
									
									Buffer[0] = tail;
								  	//	flg=0;
									if(BitMqttMessageStatus)
								  	{
								    	flg=1;
								    	tail=Buffer[tmplen];
										data_len = tmplen+1;
								  	}
								  	else
									{
									  	flg=0;
										tail=0;
										data_len = tmplen+1;
									}	
								}
								else
								{	
						          	tmplen=recv(PortNo, (uint8*)Buffer,tmplen);
									if(BitMqttMessageStatus)
									{
									  	flg=1;
									  	tail=Buffer[tmplen-1];
									}
									data_len = tmplen;
								}
                	           
								if((rxlen+tmplen)==content_len)
								{   
								  	data_len =	data_len +2;
								}
                	
								for(i = 0; i<data_len-(BYTE)(BitMqttMessageStatus); i += 2)
								{
									Writedata = Buffer[i+1];
									Writedata =(Writedata<<8) + Buffer[i];
								  	HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, flashdest, Writedata);
								  	flashdest += 2;
								  	recv_count++;
								}						
                	
  	            	     		rxlen += tmplen;	            					 
							    tmplen = 0;
							}
							else 
								break;
						}
						++pagecount;
   						#ifdef __AUTO_UPDATE_DEBUG__
						printf("download pagecount = [%d]\r\n",pagecount);
 						#endif
					}

	 				#ifdef __AUTO_UPDATE_DEBUG__
					printf("download %ld bytes ok\r\n\r\n",rxlen);
					#endif

 					//========================================================================
					lockFlash();
 				}
 				else
 				{	// TTP/1.1 404 Not Found                  
	 				FileSize = _CLR;
	 				BitTimeOverW5500Check = _CLR;
	 				BitFirmwareFileNotFined = _SET;
	 				#ifdef __AUTO_UPDATE_DEBUG__
					printf("FIle Is Empty ...... \r\n\r\n");
					#endif
				}
  	    	}					

			close(PortNo);

  	  		if((FileSize <= rxlen) && (FileSize != _CLR))
  	  		{
   	  			BitEnableGetFirmwareFile = _CLR;

				//GSTECH_FLASH_READ_ALL();
	            GSTECH_INITIAL_FLASH_SAVE_ALL(gstech_Server_FW_Version);

     			#ifdef __AUTO_UPDATE_DEBUG__
	  			printf("Write Done Version Data to Flash Area .........\r\n");
	  			printf("Exit from Firmware Write Routine, and Jump to MQTT Application .........\r\n");
	  			#endif
  				//HAL_Delay(1000);
	  		}
 
			//========================================================================
 			if(BitTimeOverW5500Check)
 			{
     			#ifdef __AUTO_UPDATE_DEBUG__
	  			printf("W5500 Soft Reset .........\r\n");
	  			#endif
 				wizphy_reset();
 			} 
  	  		break;
  		case SOCK_CLOSE_WAIT:
  		  	break;
  		case SOCK_CLOSED:
  		  	socket(PortNo,Sn_MR_TCP,AUTO_UPDATE_PORT,Sn_MR_ND);
  		  	break;
  		case SOCK_INIT:
    		#ifdef __AUTO_UPDATE_DEBUG__
			printf("init socket\r\n");
			#endif
  		   	connect2(PortNo, gstech_Update_IP  ,gstech_Update_PORT);
  		  	
  		  	if((++gstech_Application_Count) >= 10)
  		  	{
 				if(gstech_Application_Data != 0xFFFF)
 				{
   	  				BitEnableGetFirmwareFile = _CLR;
					printf("BIN File Not Found Jump to Application Program [Application Download Skip]......\r\n\r\n");
   	  			}
   	  		
   	  			gstech_Application_Count = _CLR;
   	  		}
  		  	break;
  	}
}
