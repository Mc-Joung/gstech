#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "define.h"
#include "extern.h"
#include "wizchip_conf.h"
#include "msg_command.h"
#include "cJSON.h"

#define GSTECH_TYPE 			"type"
#define GSTECH_ID 				"idx"
#define STATUS     				"status"
#define OPERATION_TIME  		"time"
#define GSTECH_PASSWORD   		"passwd"

#define GSTECH_DEVICE_ID 		"deviceId"
#define GSTECH_DHCP 			"dhcp"
#define GSTECH_IP     			"ip"
#define GSTECH_SUBNET  			"subnet"
#define GSTECH_GATEWAY   		"gateway"

#define GSTECH_MQTT_IP   		"mqttIp"
#define GSTECH_MQTT_PORT   		"mqttPort"
#define GSTECH_MQTT_ID   		"mqttId"
#define GSTECH_MQTT_PW   		"mqttPw"

#define GSTECH_UPDATE_IP   		"updateIp"
#define GSTECH_UPDATE_PORT   	"updatePort"
#define GSTECH_STATUS_CYCLE   	"statusCycle"
#define GSTECH_PERIOD   		"period"

char Gstech_Temp[30];
char Gstech_Type[30];
char Relay_Index[30];
char Relay_Status[30];
char Operation_time[3];
char Board_password[30];

int TEMPIP[4];
BYTE GetCommandType = _MQTT_COMMAND_NONE;
BYTE Gstech_RelayIdx = _CLR;
WORD Gstech_OperationTime = _CLR;
WORD Gstech_Password = _CLR;

const WORD RELAY_CONTROL_MASK_TABLE[8] =
{
	_WBIT08, _WBIT09, _WBIT10, _WBIT11, _WBIT12, _WBIT13, _WBIT14, _WBIT15
};

char* parse_command(char* msg,const char* type, char* value)
{ 
	char * string; 
   	cJSON *root = cJSON_Parse(msg);
	 
	if(root != NULL)
	{	
      	string=cJSON_GetObjectItem(root,type)->valuestring;
      	//printf("string: %s\r\n",string);	
      	memset(value,0,strlen(value)); 
		memcpy(value,string,strlen(string));
	   	cJSON_Delete(root); 
	   	//printf("parse: %s\r\n",value);
	   	return value;
	}
	return NULL;
}

void GSTECH_PARSE_UDP_TOPIC(char* msg)
{
	WORD TempBF;

	if(strstr(msg, GSTECH_DEVICE_ID)!=NULL)
	{
	   	//parse_command(msg,GSTECH_DEVICE_ID, (char*) Gstech_Temp);

		//gstech_MacAddID = atoi(Gstech_Temp);        // ���ڿ��� ������ ��ȯ�Ͽ� num1�� �Ҵ�
		//printf("SET gstech_MacAddID = %04d\r\n",gstech_MacAddID);
		printf("SET MacAddID: %02X%02X%02X\r\n\r\n",gstech_Device_MAC[3],gstech_Device_MAC[4],gstech_Device_MAC[5]);
	}
	else
	{
		printf("SET Device Id Error .....\r\n");
		return;		
	}

	if(strstr(msg, GSTECH_DHCP)!=NULL)
	{
	   	parse_command(msg,GSTECH_DHCP, (char*) Gstech_Temp);

		if(strcmp(Gstech_Temp,"True") == _CLR)
		{
			if(gstech_Device_DHCP == NETINFO_STATIC)
			{
				BitEEPSaveDone = _SET;
				BitEEPSaveDeviceDHCP = _SET;
			}
			gstech_Device_DHCP = NETINFO_DHCP;		//< Dynamic IP configruation from a DHCP sever.
			printf("SET < Dynamic IP configruation from a DHCP sever. >\r\n");
		}
		else
		{
			if(gstech_Device_DHCP == NETINFO_DHCP)
			{
				BitEEPSaveDone = _SET;
				BitEEPSaveDeviceDHCP = _SET;
			}
			gstech_Device_DHCP = NETINFO_STATIC;	//< Static IP configuration by manually.
			printf("SET < Static IP configuration by manually. >\r\n");
		}
	}
	else
	{
		printf("SET Device DHCP Error .....\r\n");
		return;		
	}

	if(strstr(msg, GSTECH_IP)!=NULL)
	{
	   	parse_command(msg,GSTECH_IP, (char*) Gstech_Temp);

		sscanf(Gstech_Temp, "%d.%d.%d.%d", &TEMPIP[0],&TEMPIP[1],&TEMPIP[2],&TEMPIP[3]);
		if(((BYTE)(TEMPIP[0]) != gstech_Device_IP[0]) ||
		   ((BYTE)(TEMPIP[1]) != gstech_Device_IP[1]) ||
		   ((BYTE)(TEMPIP[2]) != gstech_Device_IP[2]) ||
		   ((BYTE)(TEMPIP[3]) != gstech_Device_IP[3]))
		{
			BitEEPSaveDone = _SET;
			BitEEPSaveDeviceIP = _SET;

			gstech_Device_IP[0] = (BYTE)(TEMPIP[0]);
			gstech_Device_IP[1] = (BYTE)(TEMPIP[1]);
			gstech_Device_IP[2] = (BYTE)(TEMPIP[2]);
			gstech_Device_IP[3] = (BYTE)(TEMPIP[3]);
		}
		printf("SET - SIP: %3d.%3d.%3d.%3d\r\n", gstech_Device_IP[0],gstech_Device_IP[1],gstech_Device_IP[2],gstech_Device_IP[3]);
		//printf("gstech_Device_IP[0] = %d\r\n",gstech_Device_IP[0]);
		//printf("gstech_Device_IP[1] = %d\r\n",gstech_Device_IP[1]);
		//printf("gstech_Device_IP[2] = %d\r\n",gstech_Device_IP[2]);
		//printf("gstech_Device_IP[3] = %d\r\n",gstech_Device_IP[3]);

		//num1 = atoi(s1);        // ���ڿ��� ������ ��ȯ�Ͽ� num1�� �Ҵ�

		//printf("GSTECH_IP = %s\r\n",Gstech_Temp);
	}
	else
	{
		printf("SET Device IP Error .....\r\n");
		return;		
	}

	if(strstr(msg, GSTECH_SUBNET)!=NULL)
	{
	   	parse_command(msg,GSTECH_SUBNET, (char*) Gstech_Temp);

		sscanf(Gstech_Temp, "%d.%d.%d.%d", &TEMPIP[0],&TEMPIP[1],&TEMPIP[2],&TEMPIP[3]);
		if(((BYTE)(TEMPIP[0]) != gstech_Device_SN[0]) ||
		   ((BYTE)(TEMPIP[1]) != gstech_Device_SN[1]) ||
		   ((BYTE)(TEMPIP[2]) != gstech_Device_SN[2]) ||
		   ((BYTE)(TEMPIP[3]) != gstech_Device_SN[3]))
		{
			BitEEPSaveDone = _SET;
			BitEEPSaveDeviceSN = _SET;

			gstech_Device_SN[0] = (BYTE)(TEMPIP[0]);
			gstech_Device_SN[1] = (BYTE)(TEMPIP[1]);
			gstech_Device_SN[2] = (BYTE)(TEMPIP[2]);
			gstech_Device_SN[3] = (BYTE)(TEMPIP[3]);
		}
		printf("SET - SUB: %3d.%3d.%3d.%3d\r\n", gstech_Device_SN[0],gstech_Device_SN[1],gstech_Device_SN[2],gstech_Device_SN[3]);
		//printf("gstech_Device_SN[0] = %d\r\n",gstech_Device_SN[0]);
		//printf("gstech_Device_SN[1] = %d\r\n",gstech_Device_SN[1]);
		//printf("gstech_Device_SN[2] = %d\r\n",gstech_Device_SN[2]);
		//printf("gstech_Device_SN[3] = %d\r\n",gstech_Device_SN[3]);

		//num1 = atoi(s1);        // ���ڿ��� ������ ��ȯ�Ͽ� num1�� �Ҵ�

		//printf("GSTECH_SUBNET = %s\r\n",Gstech_Temp);
	}
	else
	{
		printf("SET subnet Error .....\r\n");
		return;		
	}

	if(strstr(msg, GSTECH_GATEWAY)!=NULL)
	{
	   	parse_command(msg,GSTECH_GATEWAY, (char*) Gstech_Temp);

		sscanf(Gstech_Temp, "%d.%d.%d.%d", &TEMPIP[0],&TEMPIP[1],&TEMPIP[2],&TEMPIP[3]);
		if(((BYTE)(TEMPIP[0]) != gstech_Device_GW[0]) ||
		   ((BYTE)(TEMPIP[1]) != gstech_Device_GW[1]) ||
		   ((BYTE)(TEMPIP[2]) != gstech_Device_GW[2]) ||
		   ((BYTE)(TEMPIP[3]) != gstech_Device_GW[3]))
		{
			BitEEPSaveDone = _SET;
			BitEEPSaveDeviceGW = _SET;

			gstech_Device_GW[0] = (BYTE)(TEMPIP[0]);
			gstech_Device_GW[1] = (BYTE)(TEMPIP[1]);
			gstech_Device_GW[2] = (BYTE)(TEMPIP[2]);
			gstech_Device_GW[3] = (BYTE)(TEMPIP[3]);
		}
		printf("SET - GAR: %3d.%3d.%3d.%3d\r\n", gstech_Device_GW[0],gstech_Device_GW[1],gstech_Device_GW[2],gstech_Device_GW[3]);
		//printf("gstech_Device_GW[0] = %d\r\n",gstech_Device_GW[0]);
		//printf("gstech_Device_GW[1] = %d\r\n",gstech_Device_GW[1]);
		//printf("gstech_Device_GW[2] = %d\r\n",gstech_Device_GW[2]);
		//printf("gstech_Device_GW[3] = %d\r\n",gstech_Device_GW[3]);

		//num1 = atoi(s1);        // ���ڿ��� ������ ��ȯ�Ͽ� num1�� �Ҵ�

		//printf("GSTECH_GATEWAY = %s\r\n",Gstech_Temp);
	}
	else
	{
		printf("SET gateway Error .....\r\n");
		return;		
	}

	if(strstr(msg, GSTECH_MQTT_IP)!=NULL)
	{
	   	parse_command(msg,GSTECH_MQTT_IP, (char*) Gstech_Temp);

		sscanf(Gstech_Temp, "%d.%d.%d.%d", &TEMPIP[0],&TEMPIP[1],&TEMPIP[2],&TEMPIP[3]);
		if(((BYTE)(TEMPIP[0]) != gstech_Mqtt_IP[0]) ||
		   ((BYTE)(TEMPIP[1]) != gstech_Mqtt_IP[1]) ||
		   ((BYTE)(TEMPIP[2]) != gstech_Mqtt_IP[2]) ||
		   ((BYTE)(TEMPIP[3]) != gstech_Mqtt_IP[3]))
		{
			BitEEPSaveDone = _SET;
			BitEEPSaveMqttIP = _SET;

			gstech_Mqtt_IP[0] = (BYTE)(TEMPIP[0]);
			gstech_Mqtt_IP[1] = (BYTE)(TEMPIP[1]);
			gstech_Mqtt_IP[2] = (BYTE)(TEMPIP[2]);
			gstech_Mqtt_IP[3] = (BYTE)(TEMPIP[3]);
		}
		printf("SET - MQTT IP : %3d.%3d.%3d.%3d\r\n", gstech_Mqtt_IP[0],gstech_Mqtt_IP[1],gstech_Mqtt_IP[2],gstech_Mqtt_IP[3]);
		//printf("gstech_Mqtt_IP[0] = %d\r\n",gstech_Mqtt_IP[0]);
		//printf("gstech_Mqtt_IP[1] = %d\r\n",gstech_Mqtt_IP[1]);
		//printf("gstech_Mqtt_IP[2] = %d\r\n",gstech_Mqtt_IP[2]);
		//printf("gstech_Mqtt_IP[3] = %d\r\n",gstech_Mqtt_IP[3]);

		//num1 = atoi(s1);        // ���ڿ��� ������ ��ȯ�Ͽ� num1�� �Ҵ�

		//printf("GSTECH_MQTT_IP = %s\r\n",Gstech_Temp);
	}
	else
	{
		printf("SET mqtt IP Error .....\r\n");
		return;		
	}

	if(strstr(msg, GSTECH_MQTT_PORT)!=NULL)
	{
	   	parse_command(msg,GSTECH_MQTT_PORT, (char*) Gstech_Temp);

		TempBF = atoi(Gstech_Temp);        // ���ڿ��� ������ ��ȯ�Ͽ� num1�� �Ҵ�
		if(gstech_Mqtt_PORT != TempBF)
		{
			BitEEPSaveDone = _SET;
			BitEEPSaveMqttPORT = _SET;
			gstech_Mqtt_PORT = TempBF;
		}

		printf("SET gstech_Mqtt_PORT = %d\r\n",gstech_Mqtt_PORT);
	}
	else
	{
		printf("SET mqtt Port Error .....\r\n");
		return;		
	}

	if(strstr(msg, GSTECH_MQTT_ID)!=NULL)
	{
	   	parse_command(msg,GSTECH_MQTT_ID, (char*) gstech_Mqtt_UserName);

		BitEEPSaveDone = _SET;
		BitEEPSaveMqttID = _SET;

		printf("SET gstech_Mqtt_UserName = %s\r\n",gstech_Mqtt_UserName);
	}
	else
	{
		printf("SET mqtt ID Error .....\r\n");
		return;		
	}

	if(strstr(msg, GSTECH_MQTT_PW)!=NULL)
	{
	   	parse_command(msg,GSTECH_MQTT_PW, (char*) gstech_Mqtt_PW);

		BitEEPSaveDone = _SET;
		BitEEPSaveMqttPW = _SET;

		printf("SET gstech_Mqtt_PW = %s\r\n",gstech_Mqtt_PW);
	}
	else
	{
		printf("SET mqtt PW Error .....\r\n");
		return;		
	}

	if(strstr(msg, GSTECH_UPDATE_IP)!=NULL)
	{
	   	parse_command(msg,GSTECH_UPDATE_IP, (char*) Gstech_Temp);

		sscanf(Gstech_Temp, "%d.%d.%d.%d", &TEMPIP[0],&TEMPIP[1],&TEMPIP[2],&TEMPIP[3]);
		if(((BYTE)(TEMPIP[0]) != gstech_Update_IP[0]) ||
		   ((BYTE)(TEMPIP[1]) != gstech_Update_IP[1]) ||
		   ((BYTE)(TEMPIP[2]) != gstech_Update_IP[2]) ||
		   ((BYTE)(TEMPIP[3]) != gstech_Update_IP[3]))
		{
			BitEEPSaveDone = _SET;
			BitEEPSaveUpdateIP = _SET;

			gstech_Update_IP[0] = (BYTE)(TEMPIP[0]);
			gstech_Update_IP[1] = (BYTE)(TEMPIP[1]);
			gstech_Update_IP[2] = (BYTE)(TEMPIP[2]);
			gstech_Update_IP[3] = (BYTE)(TEMPIP[3]);
		}
		printf("SET - UPDATE IP : %3d.%3d.%3d.%3d\r\n", gstech_Update_IP[0],gstech_Update_IP[1],gstech_Update_IP[2],gstech_Update_IP[3]);
		//printf("gstech_Update_IP[0] = %d\r\n",gstech_Update_IP[0]);
		//printf("gstech_Update_IP[1] = %d\r\n",gstech_Update_IP[1]);
		//printf("gstech_Update_IP[2] = %d\r\n",gstech_Update_IP[2]);
		//printf("gstech_Update_IP[3] = %d\r\n",gstech_Update_IP[3]);

		//num1 = atoi(s1);        // ���ڿ��� ������ ��ȯ�Ͽ� num1�� �Ҵ�

		//printf("GSTECH_UPDATE_IP = %s\r\n",Gstech_Temp);
	}
	else
	{
		printf("SET update IP Error .....\r\n");
		return;		
	}

	if(strstr(msg, GSTECH_UPDATE_PORT)!=NULL)
	{
	   	parse_command(msg,GSTECH_UPDATE_PORT, (char*) Gstech_Temp);

		TempBF = atoi(Gstech_Temp);        // ���ڿ��� ������ ��ȯ�Ͽ� num1�� �Ҵ�
		if(gstech_Update_PORT != TempBF)
		{
			BitEEPSaveDone = _SET;
			BitEEPSaveUpdatePORT = _SET;
			gstech_Update_PORT = TempBF;
		}

		printf("SET gstech_Update_PORT = %d\r\n",gstech_Update_PORT);
	}
	else
	{
		printf("SET update Port Error .....\r\n");
		return;		
	}

	if(strstr(msg, GSTECH_STATUS_CYCLE)!=NULL)
	{
	   	parse_command(msg,GSTECH_STATUS_CYCLE, (char*) Gstech_Temp);

		TempBF = atoi(Gstech_Temp);        // ���ڿ��� ������ ��ȯ�Ͽ� num1�� �Ҵ�
		if(gstech_StatusCycle != (BYTE)TempBF)
		{
			BitEEPSaveDone = _SET;
			BitEEPSavePeriod = _SET;
			gstech_StatusCycle = (BYTE)TempBF;
		}

		printf("SET gstech_StatusCycle = %d\r\n",gstech_StatusCycle);
	}
	else
	{
		printf("SET status cycle Error .....\r\n");
		return;		
	}

	if(strstr(msg, GSTECH_PERIOD)!=NULL)
	{
	   	parse_command(msg,GSTECH_PERIOD, (char*) Gstech_Temp);

		TempBF = atoi(Gstech_Temp);        // ���ڿ��� ������ ��ȯ�Ͽ� num1�� �Ҵ�
		if(gstech_Period != TempBF)
		{
			BitEEPSaveDone = _SET;
			BitEEPSavePeriod = _SET;
			gstech_Period = TempBF;
		}

		printf("SET gstech_Period = %d\r\n\r\n",gstech_Period);
	}
	else
	{
		printf("SET period Error .....\r\n\r\n");
		return;		
	}

	printf("Set DHCP data and Rebooting RCU Board .........\r\n\r\n");
}

//{
//"type": "REQUEST_SETUP",
//"deviceId": "1234",
//"dhcp": "True",
//"ip": "172.30.0.3",
//"subnet": "255.255.0.0",
//"gateway": "172.30.0.1",
//"mqttIp": "121.160.67.34",
//"mqttPort": "1883",
//"mqttId": "gstech",
//"mqttPw": "gs7011",
//"updateIp": "121.160.67.34",
//"updatePort": "69",
//"statusCycle": "False",
//"period": "0"
//}

//void make_cmd_response(char *buf,int type,char*bookcaseId,char*bookcellId,int code,char* bookId,char*booklsbn,char*RFID)
//{
//   switch (type)
//	 {
//		 case 1://�����
//			 sprintf(buf,"{\"bookcaseId\":\"%s\",\"code\":\"%d\"}",bookcaseId,code);//�򿪹ر������Ӧ����
//			 break;
//		 case 2:
//			 sprintf(buf,"{\"bookcellId\":\"%s\",\"code\":\"%d\",\"bookId\":\"%s\"}",bookcellId,code,bookId);//ȡ����Ӧ����
//		 
//			 break;
//		 case 3:
//			 sprintf(buf,"{\"bookcellId\":\"%s\",\"code\":\"%d\",\"booklsbn\":\"%s\"}",bookcellId,code,booklsbn);//������Ӧ����
//		 
//			 break;
//		 case 4://�����
//			 sprintf(buf,"{\"bookcaseId\":\"%s\",\"code\":\"%d\",\"RFID\":\"%s\"}",bookcaseId,code,RFID);//��ӡ������Ӧ����
//			 break;
//		 default:
//		  break;
//	}  			 
//}