//****************************************************************************************************************************
//  I N C L U D E    F I L E S
//****************************************************************************************************************************
#include <stdio.h>
#include <string.h>    // strcat �Լ��� ����� ��� ����
#include <stdarg.h>
#include <stddef.h>
#include "stm32f1xx_hal.h"
#include "define.h"
#include "extern.h"
#include "w5500.h"
#include "spi.h"

#define _W5500_SPI_VDM_OP_          0x00
#define _W5500_SPI_FDM_OP_LEN1_     0x01
#define _W5500_SPI_FDM_OP_LEN2_     0x02
#define _W5500_SPI_FDM_OP_LEN4_     0x03

#define _CHIP_SELECT_DELAY_TIME		10000
uint16_t spidelay;
uint8_t spi_data[4];

uint8_t WIZCHIP_READ(uint32_t AddrSel)
{
   	uint8_t ret;

	W5500_CS_LOW();
 
   	AddrSel |= (_W5500_SPI_READ_ | _W5500_SPI_VDM_OP_);

	spi_data[0] = (AddrSel & 0x00FF0000) >> 16;
	spi_data[1] = (AddrSel & 0x0000FF00) >> 8;
	spi_data[2] = (AddrSel & 0x000000FF) >> 0;
	HAL_SPI_Transmit(&hspi1, &spi_data[0], 3, 100);	//WIZCHIP.IF.SPI._write_burst(spi_data, 3);
 
   	HAL_SPI_Receive(&hspi1, &ret, 1, 1000);	//WIZCHIP.IF.SPI._read_byte();

 	W5500_CS_HIGH();
 	for(spidelay=0;spidelay<_CHIP_SELECT_DELAY_TIME;spidelay++);//  HAL_Delay(10);
   	return ret;
}

void WIZCHIP_WRITE(uint32_t AddrSel, uint8_t wb )
{
 	W5500_CS_LOW();	

   	AddrSel |= (_W5500_SPI_WRITE_ | _W5500_SPI_VDM_OP_);

	spi_data[0] = (AddrSel & 0x00FF0000) >> 16;
	spi_data[1] = (AddrSel & 0x0000FF00) >> 8;
	spi_data[2] = (AddrSel & 0x000000FF) >> 0;
	spi_data[3] = wb;
	HAL_SPI_Transmit(&hspi1, &spi_data[0], 4, 100);

   	W5500_CS_HIGH();
 	for(spidelay=0;spidelay<_CHIP_SELECT_DELAY_TIME;spidelay++);
}
       
void WIZCHIP_READ_BUF (uint32_t AddrSel, uint8_t* pBuf, uint16_t len)
{
 	W5500_CS_LOW();	

   	AddrSel |= (_W5500_SPI_READ_ | _W5500_SPI_VDM_OP_);

	spi_data[0] = (AddrSel & 0x00FF0000) >> 16;
	spi_data[1] = (AddrSel & 0x0000FF00) >> 8;
	spi_data[2] = (AddrSel & 0x000000FF) >> 0;
	HAL_SPI_Transmit(&hspi1, &spi_data[0], 3, 100);
 
	HAL_SPI_Receive(&hspi1, &pBuf[0], len, 1000);

 	W5500_CS_HIGH();
 	for(spidelay=0;spidelay<_CHIP_SELECT_DELAY_TIME;spidelay++);
}

void WIZCHIP_WRITE_BUF(uint32_t AddrSel, uint8_t* pBuf, uint16_t len)
{
 	W5500_CS_LOW();	

   	AddrSel |= (_W5500_SPI_WRITE_ | _W5500_SPI_VDM_OP_);

	spi_data[0] = (AddrSel & 0x00FF0000) >> 16;
	spi_data[1] = (AddrSel & 0x0000FF00) >> 8;
	spi_data[2] = (AddrSel & 0x000000FF) >> 0;
	HAL_SPI_Transmit(&hspi1, &spi_data[0], 3, 100);	
 
	HAL_SPI_Transmit(&hspi1, &pBuf[0], len, 1000);

 	W5500_CS_HIGH();
 	for(spidelay=0;spidelay<_CHIP_SELECT_DELAY_TIME;spidelay++);//  
}

uint16_t getSn_TX_FSR(uint8_t sn)
{
   uint16_t val=0,val1=0;

   do
   {
      val1 = WIZCHIP_READ(Sn_TX_FSR(sn));
      val1 = (val1 << 8) + WIZCHIP_READ(WIZCHIP_OFFSET_INC(Sn_TX_FSR(sn),1));
      if (val1 != 0)
      {
        val = WIZCHIP_READ(Sn_TX_FSR(sn));
        val = (val << 8) + WIZCHIP_READ(WIZCHIP_OFFSET_INC(Sn_TX_FSR(sn),1));
      }
   }while (val != val1);

   return val;
}


uint16_t getSn_RX_RSR(uint8_t sn)
{
   uint16_t val=0,val1=0;

   do
   {
      val1 = WIZCHIP_READ(Sn_RX_RSR(sn));

      val1 = (val1 << 8) + WIZCHIP_READ(WIZCHIP_OFFSET_INC(Sn_RX_RSR(sn),1));

      if (val1 != 0)
      {
        val = WIZCHIP_READ(Sn_RX_RSR(sn));
        val = (val << 8) + WIZCHIP_READ(WIZCHIP_OFFSET_INC(Sn_RX_RSR(sn),1));
      }
   }while (val != val1);

   return val;
}

void wiz_send_data(uint8_t sn, uint8_t *wizdata, uint16_t len)
{
   	uint16_t ptr = 0;
   	uint32_t addrsel = 0;

   	if(len == 0)  
   		return;
   	ptr = getSn_TX_WR(sn);

   	addrsel = ((uint32_t)ptr << 8) + (WIZCHIP_TXBUF_BLOCK(sn) << 3);
   	//
   	WIZCHIP_WRITE_BUF(addrsel,wizdata, len);
   
   	ptr += len;
   	setSn_TX_WR(sn,ptr);
}

void wiz_recv_data(uint8_t sn, uint8_t *wizdata, uint16_t len)
{
   uint16_t ptr = 0;
   uint32_t addrsel = 0;
   
   if(len == 0) return;
   ptr = getSn_RX_RD(sn);

   addrsel = ((uint32_t)ptr << 8) + (WIZCHIP_RXBUF_BLOCK(sn) << 3);
   //
   WIZCHIP_READ_BUF(addrsel, wizdata, len);
   ptr += len;
   
   setSn_RX_RD(sn,ptr);
}


void wiz_recv_ignore(uint8_t sn, uint16_t len)
{
   uint16_t ptr = 0;

   ptr = getSn_RX_RD(sn);
   ptr += len;
   setSn_RX_RD(sn,ptr);
}
