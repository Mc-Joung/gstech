#ifndef _EXTERN_H_
#define _EXTERN_H_

	/******************** (C) COPYRIGHT 2009 STMicroelectronics ********************
	* File Name          : extern.h
	* Author             : www.nexonchip.com Benjamin LEE
	* Version            : V2.0.0
	* Date               : 04/16/2011
	* Description        : Header for extern.h module
	********************************************************************************
	* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
	* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
	* AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
	* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
	* CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
	* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
	*******************************************************************************/
	extern BYTE gstech_Timer10mSec;
	extern BYTE gstech_Timer25mSec;
	extern BYTE gstech_Timer50mSec;
	extern BYTE gstech_Timer100mSec;
	extern WORD gstech_Timer250mSec;
	extern WORD gstech_Timer500mSec;
	extern WORD gstech_Timer1000mSec;
	extern WORD gstech_TimerxxxxmSec;
	extern WORD gstech_TimeOverI2C;

	//=================================================================================================================================
	extern TimerFlagsType TIMERFLAGSbits;
	extern GlobalFlagsType USARTFLAGSbits;
	extern GlobalFlagsType GLOBAL1FLAGSbits;
	extern GlobalFlagsType GLOBAL2FLAGSbits;
	extern GlobalFlagsType GLOBAL3FLAGSbits;
	extern GlobalFlagsType PORTDET1FLAGSbits;
	extern GlobalFlagsType PORTDET2FLAGSbits;
	extern GlobalFlagsType PORTCTRL1FLAGSbits;
	extern GlobalFlagsType PORTCTRL2FLAGSbits;
	extern GlobalFlagsType PORTCTRLEn1FLAGSbits;
	extern GlobalFlagsType PORTCTRLEn2FLAGSbits;
	extern GlobalFlagsType EEPromFLAGSbits;

	//=================================================================================================================================
	extern BYTE gstech_ModBusCoil[_MAX_COIL_BUFFER];
	extern WORD gstech_ModBusRegister[_MAX_REGISTER_BUFFER];

	//=================================================================================================================================
	// USART 1
	extern BYTE gstech_COM1_Rx_BF[_MAX_COMx_RX_BUFFER_SIZE];
	extern BYTE gstech_COM1_Tx_BF[_MAX_COMx_TX_BUFFER_SIZE];
	extern BYTE ProcessCOM1RxBuffer[_MAX_COMx_RX_BUFFER_SIZE];
	extern BYTE gstech_Com1ReceiveBuffer;
	extern BYTE gstech_Com1ReceiveCount;
	extern BYTE gstech_Com1TimeOutCount;
	extern BYTE gstech_Com1ProcesseCount;
	extern WORD gstech_Com1ACKSendTimeCount;

	//=================================================================================================================================
	// USART 2
	extern BYTE gstech_COM2_Rx_BF[_MAX_COMx_RX_BUFFER_SIZE];
	extern BYTE gstech_COM2_Tx_BF[_MAX_COMx_TX_BUFFER_SIZE];
	extern BYTE ProcessCOM2RxBuffer[_MAX_COMx_RX_BUFFER_SIZE];
	extern BYTE gstech_Com2ReceiveBuffer;
	extern BYTE gstech_Com2ReceiveCount;
	extern BYTE gstech_Com2TimeOutCount;
	extern BYTE gstech_Com2ProcesseCount;
	extern WORD gstech_Com2ACKSendTimeCount;

	//=================================================================================================================================
	extern BYTE gstech_W5500TXBuffer[DATA_BUF_SIZE + 3];
	extern BYTE gstech_W5500RXBuffer[DATA_BUF_SIZE + 3];
	extern WORD gstech_W5500TimeOutCount;
	extern WORD gstech_sntpTimeOutCount;

	//=================================================================================================================================
	extern BYTE gstech_Device_IP[4];
	extern BYTE gstech_Device_SN[4];
	extern BYTE gstech_Device_GW[4];
	extern BYTE gstech_Device_DNS[4];
	extern BYTE gstech_Device_DHCP;
	extern WORD gstech_Device_PORT;
	extern BYTE gstech_Device_MAC[6];
	//extern WORD gstech_MacAddID;
	
	//-------------------------------------------------------------------------------------------------------------------------
	extern BYTE gstech_Mqtt_IP[4];
	extern WORD gstech_Mqtt_PORT;
	extern char gstech_Mqtt_UserName[_MQTT_MAX_ID_COUNT+3];
	extern BYTE gstech_UserNameLength;
	extern char gstech_Mqtt_PW[_MQTT_MAX_PW_COUNT+3];
	extern BYTE gstech_PasswordLength;
	//extern char gstech_FW_Version[4];
	//extern WORD gstech_FW_Version;
	extern WORD gstech_Read_FW_Version;

	//-------------------------------------------------------------------------------------------------------------------------
	extern BYTE gstech_Update_IP[4];
	extern WORD gstech_Update_PORT;
	extern BYTE gstech_StatusCycle;
	extern WORD gstech_Period;
	extern WORD gstech_PeriodCount;

	//=================================================================================================================================
	extern WORD gstech_CurrentTemperatureAverage[_INITIAL_ADC_AVERAGE_COUNT];
	extern WORD gstech_CurrentTemperature;
	extern BYTE gstech_CurrentTemperatureStableCount;

	//=================================================================================================================================
	extern BYTE etem_W5500TXBuffer[DATA_BUF_SIZE + 3];
	extern BYTE etem_W5500RXBuffer[DATA_BUF_SIZE + 3];
	extern WORD etem_W5500TimeOutCount;
	extern char ser_cmd[BUFFER_SIZE];
	extern int GSTECH_MQTT_PARSE_UDP_TOPIC(char* msg);
	extern int GSTECH_DEVICE_SETUP_PARSE_UDP_TOPIC(char* msg);
	extern void GSTECH_DEVICE_SETUP_MESSAGE_OUTPUT_PROCESS(void);
	extern WORD local_port;
	extern BYTE targetIP[4];
	extern WORD targetPort;
	extern BYTE UpdateIP[4];
	extern WORD UpdatePort;
	extern char targetusername[6];
	extern char targetpassword[6];
	extern char Board_out_Format[DATA_BUF_SIZE];
	extern WORD gstech_OutputCount;

	//=================================================================================================================================
	extern BYTE gstech_Port1StableCount;
	extern BYTE gstech_Port2StableCount;
	extern BYTE gstech_Port3StableCount;
	extern BYTE gstech_Port4StableCount;
	extern BYTE gstech_Port5StableCount;
	extern BYTE gstech_Port6StableCount;
	extern BYTE gstech_Port7StableCount;
	extern BYTE gstech_Port8StableCount;

	//-------------------------------------------------------------------------------------------------------------------------
	extern BYTE gstech_Port1UnStableCount;
	extern BYTE gstech_Port2UnStableCount;
	extern BYTE gstech_Port3UnStableCount;
	extern BYTE gstech_Port4UnStableCount;
	extern BYTE gstech_Port5UnStableCount;
	extern BYTE gstech_Port6UnStableCount;
	extern BYTE gstech_Port7UnStableCount;
	extern BYTE gstech_Port8UnStableCount;

	//-------------------------------------------------------------------------------------------------------------------------
	extern DWORD gstech_RelayTimeCount[33];
	//extern WORD gstech_RelayTimeCount;
	//extern WORD gstech_RelayTimeCount;
	//extern WORD gstech_RelayTimeCount;
	//extern WORD gstech_RelayTimeCount;
	//extern WORD gstech_RelayTimeCount;
	//extern WORD gstech_RelayTimeCount;
	//extern WORD gstech_RelayTimeCount;

	extern DWORD gstech_MqttSendStartTimeCount;
	extern WORD gstech_pingMessageTimeCount;
	extern BYTE Gstech_ResetRelayIdx;

	//=================================================================================================================================
	//=================================================================================================================================
	extern char gstech_topic[30];
	extern char topic_Output[30];
	extern char new_topic[30];
	extern char Gstech_Type[30];
	extern BYTE GetCommandType;

	//extern void GSTECH_WRITE_VER_TO_FLASH(WORD Version);//flash
	extern void GSTECH_NETWORK_SET_COMMON_PROCESS(void);
	extern void GSTECH_DELAY_1mS(WORD Delay);
	extern void GSTECH_MQTT_MESSAGE_OUTPUT_PROCESS(void);
	extern char* GSTECH_PARSE_COMMAND(char* msg,const char* type, char* value);

	//=================================================================================================================================
	extern void GSTECH_BOOT_CODE_JUMP(void); 
	extern void EEP_CHECK_BLANK(void);
	extern void GSTECH_FLASH_SAVE_ALL(void);
	extern void EEP_WRITE_FIRMWARE_VERSION(WORD Version);
	extern void EEP_READ_MQTT_ID(void);

	//-------------------------------------------------------------------------------------------------------------------------
	extern void GSTECH_USART_COM1_RX_COMMAND_PROCESS(void);
	extern void GSTECH_USART_COM2_RX_COMMAND_PROCESS(void);

	extern void GSTECHGPIO_PORT1_STATUS_PORT_CHECK_PROCESS(void);
	extern void GSTECHGPIO_PORT2_STATUS_PORT_CHECK_PROCESS(void);
	extern void GSTECHGPIO_PORT3_STATUS_PORT_CHECK_PROCESS(void);
	extern void GSTECHGPIO_PORT4_STATUS_PORT_CHECK_PROCESS(void);
	extern void GSTECHGPIO_PORT5_STATUS_PORT_CHECK_PROCESS(void);
	extern void GSTECHGPIO_PORT6_STATUS_PORT_CHECK_PROCESS(void);
	extern void GSTECHGPIO_PORT7_STATUS_PORT_CHECK_PROCESS(void);
	extern void GSTECHGPIO_PORT8_STATUS_PORT_CHECK_PROCESS(void);

	extern void GSTECH_MQTT_RELAY_CONTROL_PROCESS(BYTE RelayIndex);

	//=================================================================================================================================

#endif	//_DEFINE_H_
