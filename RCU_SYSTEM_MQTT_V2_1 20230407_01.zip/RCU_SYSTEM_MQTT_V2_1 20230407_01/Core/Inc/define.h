/******************** (C) COPYRIGHT 2008 STMicroelectronics ********************
* File Name          : define.h
* Author             : www.nexonchip.com Benjamin LEE
* Version            : V2.0.0
* Date               : 04/16/2011
* Description        : This file contains all the functions prototypes for the
*                      EEProm firmware driver.
********************************************************************************
* THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
* WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE TIME.
* AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY DIRECT,
* INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING FROM THE
* CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE CODING
* INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
*******************************************************************************/

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef	__DEFINE_H
#define	__DEFINE_H

	typedef unsigned long long  	QWORD;
	typedef unsigned long  			DWORD;
	typedef signed long  			SDWORD;
	typedef unsigned short 			WORD;
	typedef signed short 			SWORD;
	typedef unsigned char  			BYTE;
	typedef signed char  			SBYTE;
	typedef unsigned int    		BOOL;  // Boolean

	//***************************************************************************************************************************************
	typedef char 					int8;
	typedef volatile char 			vint8;
	typedef unsigned char 			uint8;
	typedef int 					int16;
	typedef unsigned short 			uint16;
	typedef long 					int32;
	typedef unsigned long 			uint32;

	typedef unsigned char 			uint8_t;
	typedef unsigned short 			uint16_t;
	typedef unsigned long 			uint32_t;

  	//---------------------------------------------------------------------------------------------------------------------------------------
	typedef uint8					u_char;		/**< 8-bit value */
	typedef uint8 					SOCKET;
	typedef uint16					u_short;	/**< 16-bit value */
	typedef uint32					u_long;		/**< 32-bit value */

	//***************************************************************************************************************************************
	//  C O M P I L E R   O P I I O N	D E F I N E
	//***************************************************************************************************************************************
	#define ENABLE_PRINTF_DEBUG					1
	#define SUPPORT_NTP_TIME					1
	#define __RELAY_DEFAULT_HIGH				1

	#define __MAIN_DEBUG__
	#define __EEPROM_DEBUG__
	#define __DHCP_DEBUG__
	#define __SNTP_DEBUG__
	#define __HTTPCLIENT_DEBUG__			// HTTP client debug message enable
	#define __MQTTCLIENT_DEBUG__			// MQTT client debug message enable
	#define __LOOPBACK_DEBUG__
	#define __MESSAGE_DEBUG__

	//***************************************************************************************************************************************
	//  F L A S H 	M E M O R Y  M A P	D E F I N E
	//***************************************************************************************************************************************
	#define BootAddress 	 					0x08000000u 	// 	0x08000000-0x08011FFF Boot size is 73K
	#define ApplicationAddress 	 				0x08012000u 	// 	0x0800FFFF-0x0802E7FF App size is 122K

	//=================================================================================================================================
	#define VersionAddr                 		0x0803E800u  	// 	Version
	#define MemoryDeviceIPAddr              	0x0803E810u  	// 	Device IP
	#define MemoryDeviceSNAddr              	0x0803E820u  	// 	Device SN
	#define MemoryDeviceGWAddr              	0x0803E830u  	// 	Device GW
	#define MemoryDeviceDNSAddr             	0x0803E840u  	// 	Device DNS
	#define MemoryDevicePORTAddr            	0x0803E850u  	// 	Device Port
	#define MemoryDeviceDHCPAddr            	0x0803E860u  	// 	Device DHCP
	#define MemoryDeviceMACAddr             	0x0803E870u  	// 	Device Mac
	#define MemoryDeviceMACdAddr            	0x0803E880u  	// 	Device Mac Id
	#define MemoryMqttIDAddr                 	0x0803E890u  	// 	ID
	#define MemoryMqttPWAddr                 	0x0803E8C0u  	// 	PW
	#define MemoryMqttIDLengthAddr              0x0803E8F0u  	// 	ID Length
	#define MemoryMqttPWLengthAddr              0x0803E900u  	// 	PW Length
	#define MemoryMqttIPAddr               		0x0803E910u  	// 	MQTT IP
	#define MemoryMqttPORTAddr              	0x0803E920u  	// 	MQTT Port
	#define MemoryUpdateIPAddr              	0x0803E930u  	// 	MQTT IP
	#define MemoryUpdatePORTAddr            	0x0803E940u  	// 	MQTT Port
	#define MemoryUpdateStatusAddr          	0x0803E950u  	// 	MQTT Status
	#define MemoryUpdatePeriodAddr          	0x0803E960u  	// 	MQTT Period

	//=================================================================================================================================
	#define DEFAULT_VERSION						21				// 	V2.0

	//=================================================================================================================================
	//***************************************************************************************************************************************
	//  G L O B A L    B I T	D E F I N E
	//***************************************************************************************************************************************
	#define	_CLR								0
	#define	_SET								1

	#define	_OFF								0
	#define	_ON									1
	                                    		
	#define _STOP								0
	#define _START								1

	#define	__NULL								0xFF
	#define _FALSE								0
	#define _TRUE								1

	#define _CS_LOW								0
	#define _CS_HIGH							1

	#define _DISABLE							0
	#define _ENABLE								1

	#define _MIN_DATA							0
	#define _MAX_DATA							1

	#define _INPUT								0
	#define _OUTPUT								1

	#define _OPEN								0
	#define _CLOSE								1

	#define _I2C_WRITE							0
	#define _I2C_READ							1

	#define _I2C_ACK							0
	#define _I2C_NONE_ACK						1

	#define _DEVICE_TX							0x00
	#define _DEVICE_RX							0x01

	#define _UP_STREAM							0
	#define _DOWN_STREAM						1

	#define _TCP_PORT_0							0
	#define _TCP_PORT_1							1

	//***************************************************************************************************************************************
	#define _BIT0        						0x01
	#define _BIT1        						0x02
	#define _BIT2        						0x04
	#define _BIT3        						0x08
	#define _BIT4        						0x10
	#define _BIT5        						0x20
	#define _BIT6        						0x40
	#define _BIT7        						0x80

	#define _WBIT00        						0x0001
	#define _WBIT01        						0x0002
	#define _WBIT02        						0x0004
	#define _WBIT03        						0x0008
	#define _WBIT04        						0x0010
	#define _WBIT05        						0x0020
	#define _WBIT06        						0x0040
	#define _WBIT07        						0x0080
	#define _WBIT08        						0x0100
	#define _WBIT09        						0x0200
	#define _WBIT10        						0x0400
	#define _WBIT11        						0x0800
	#define _WBIT12        						0x1000
	#define _WBIT13        						0x2000
	#define _WBIT14        						0x4000
	#define _WBIT15        						0x8000

	//***************************************************************************************************************************************
	typedef union
	{
		WORD BitWord;
		struct
		{
			WORD TimerBit0		:1; 
			WORD TimerBit1		:1;  
			WORD TimerBit2		:1;  
			WORD TimerBit3		:1; 
			WORD TimerBit4		:1; 
			WORD TimerBit5		:1; 
			WORD TimerBit6		:1; 
			WORD TimerBit7		:1; 
			WORD TimerBit8		:1; 
			WORD TimerBit9		:1;  
			WORD TimerBit10 	:1;  
			WORD TimerBit11 	:1; 
			WORD TimerBit12 	:1; 
			WORD TimerBit13 	:1; 
			WORD TimerBit14 	:1; 
			WORD TimerBit15 	:1; 
		}bit;
	}TimerFlagsType;  

	#define Bit1mS										TIMERFLAGSbits.bit.TimerBit0
	#define Bit10mS										TIMERFLAGSbits.bit.TimerBit1
	#define Bit25mS										TIMERFLAGSbits.bit.TimerBit2
	#define Bit50mS										TIMERFLAGSbits.bit.TimerBit3 
	#define Bit100mS									TIMERFLAGSbits.bit.TimerBit4
	#define Bit250mS									TIMERFLAGSbits.bit.TimerBit5
	#define Bit500mS									TIMERFLAGSbits.bit.TimerBit6
	#define Bit1000mS									TIMERFLAGSbits.bit.TimerBit7

	#define BitxxxxmS									TIMERFLAGSbits.bit.TimerBit8
	#define BitTimeToggle								TIMERFLAGSbits.bit.TimerBit9

	#define BitTimeOverI2C								TIMERFLAGSbits.bit.TimerBit15
 
	//***************************************************************************************************************************************
	typedef union
	{
		WORD BitWord;
		struct
		{
			WORD KeyBit0		:1; 
			WORD KeyBit1		:1;  
			WORD KeyBit2		:1;  
			WORD KeyBit3		:1; 
			WORD KeyBit4		:1; 
			WORD KeyBit5		:1; 
			WORD KeyBit6		:1; 
			WORD KeyBit7		:1; 
			WORD KeyBit8		:1; 
			WORD KeyBit9		:1;  
			WORD KeyBit10		:1;  
			WORD KeyBit11		:1; 
			WORD KeyBit12		:1; 
			WORD KeyBit13		:1; 
			WORD KeyBit14		:1; 
			WORD KeyBit15		:1; 
		}bit;
	}KeyFlagsType;  

	#define BitKeyProcDone 									KEYFLAGSbits.bit.KeyBit0 
	#define BitKeyPressed									KEYFLAGSbits.bit.KeyBit1 
	#define BitLongKeyPressed								KEYFLAGSbits.bit.KeyBit2
	#define BitKeyCont										KEYFLAGSbits.bit.KeyBit3 

	//***************************************************************************************************************************************
	typedef union
	{
		WORD BitWord;
		struct
		{
			WORD GlobalBit0		:1; 
			WORD GlobalBit1		:1;  
			WORD GlobalBit2		:1;  
			WORD GlobalBit3		:1; 
			WORD GlobalBit4		:1; 
			WORD GlobalBit5		:1; 
			WORD GlobalBit6		:1; 
			WORD GlobalBit7		:1; 
			WORD GlobalBit8		:1; 
			WORD GlobalBit9		:1;  
			WORD GlobalBit10	:1;  
			WORD GlobalBit11	:1; 
			WORD GlobalBit12	:1; 
			WORD GlobalBit13	:1; 
			WORD GlobalBit14	:1; 
			WORD GlobalBit15	:1; 
		}bit;
	}GlobalFlagsType;  

  	//---------------------------------------------------------------------------------------------------------------------------------------
	#define BitTimeOverCom1Rx							GLOBAL1FLAGSbits.bit.GlobalBit0
	#define BitTimeOverCom2Rx							GLOBAL1FLAGSbits.bit.GlobalBit1
	#define BitTimeOverW5500Check						GLOBAL1FLAGSbits.bit.GlobalBit2
	#define BitOneTimeInitialDone						GLOBAL1FLAGSbits.bit.GlobalBit3
	#define BitTimeOversntpCheck						GLOBAL1FLAGSbits.bit.GlobalBit4

 	//---------------------------------------------------------------------------------------------------------------------------------------
	#define BitModbusBroadcastMode 						GLOBAL2FLAGSbits.bit.GlobalBit0 
	#define BitEnableDHCPFunction 						GLOBAL2FLAGSbits.bit.GlobalBit1 
	#define BitEnableGetVersionFile 					GLOBAL2FLAGSbits.bit.GlobalBit2 
	#define BitEnableGetFirmwareFile 					GLOBAL2FLAGSbits.bit.GlobalBit3 

	#define BitPHYStatuscheckflag 						GLOBAL2FLAGSbits.bit.GlobalBit8 

  	//---------------------------------------------------------------------------------------------------------------------------------------
	#define BitMqttSendDataStart						GLOBAL3FLAGSbits.bit.GlobalBit0	   
	#define BitMqttConnectionDone						GLOBAL3FLAGSbits.bit.GlobalBit1   
	#define BitMqttContinueSendEnable					GLOBAL3FLAGSbits.bit.GlobalBit2   
	#define BitMqttResetCommandSetDone					GLOBAL3FLAGSbits.bit.GlobalBit3   
	#define BitMqttReConnectionStart						GLOBAL3FLAGSbits.bit.GlobalBit4   

	#define BitJumpBootCodeStart						GLOBAL3FLAGSbits.bit.GlobalBit15	   

 	//---------------------------------------------------------------------------------------------------------------------------------------
	#define BitPort1DetStatus 							PORTDET1FLAGSbits.bit.GlobalBit0 
	#define BitPort2DetStatus 							PORTDET1FLAGSbits.bit.GlobalBit1 
	#define BitPort3DetStatus 							PORTDET1FLAGSbits.bit.GlobalBit2 
	#define BitPort4DetStatus 							PORTDET1FLAGSbits.bit.GlobalBit3 
	#define BitPort5DetStatus 							PORTDET1FLAGSbits.bit.GlobalBit4 
	#define BitPort6DetStatus 							PORTDET1FLAGSbits.bit.GlobalBit5 
	#define BitPort7DetStatus 							PORTDET1FLAGSbits.bit.GlobalBit6 
	#define BitPort8DetStatus 							PORTDET1FLAGSbits.bit.GlobalBit7 
	#define BitPort9DetStatus 							PORTDET1FLAGSbits.bit.GlobalBit8  
	#define BitPort10DetStatus 							PORTDET1FLAGSbits.bit.GlobalBit9  
	#define BitPort11DetStatus 							PORTDET1FLAGSbits.bit.GlobalBit10 
	#define BitPort12DetStatus 							PORTDET1FLAGSbits.bit.GlobalBit11 
	#define BitPort13DetStatus 							PORTDET1FLAGSbits.bit.GlobalBit12 
	#define BitPort14DetStatus 							PORTDET1FLAGSbits.bit.GlobalBit13 
	#define BitPort15DetStatus 							PORTDET1FLAGSbits.bit.GlobalBit14 
	#define BitPort16DetStatus 							PORTDET1FLAGSbits.bit.GlobalBit15 

 	//---------------------------------------------------------------------------------------------------------------------------------------
	#define BitPort17DetStatus 							PORTDET2FLAGSbits.bit.GlobalBit0 
	#define BitPort18DetStatus 							PORTDET2FLAGSbits.bit.GlobalBit1 
	#define BitPort19DetStatus 							PORTDET2FLAGSbits.bit.GlobalBit2 
	#define BitPort20DetStatus 							PORTDET2FLAGSbits.bit.GlobalBit3 
	#define BitPort21DetStatus 							PORTDET2FLAGSbits.bit.GlobalBit4 
	#define BitPort22DetStatus 							PORTDET2FLAGSbits.bit.GlobalBit5 
	#define BitPort23DetStatus 							PORTDET2FLAGSbits.bit.GlobalBit6 
	#define BitPort24DetStatus 							PORTDET2FLAGSbits.bit.GlobalBit7 
	#define BitPort25DetStatus 							PORTDET2FLAGSbits.bit.GlobalBit8  
	#define BitPort26DetStatus 							PORTDET2FLAGSbits.bit.GlobalBit9  
	#define BitPort27DetStatus 							PORTDET2FLAGSbits.bit.GlobalBit10 
	#define BitPort28DetStatus 							PORTDET2FLAGSbits.bit.GlobalBit11 
	#define BitPort29DetStatus 							PORTDET2FLAGSbits.bit.GlobalBit12 
	#define BitPort30DetStatus 							PORTDET2FLAGSbits.bit.GlobalBit13 
	#define BitPort31DetStatus 							PORTDET2FLAGSbits.bit.GlobalBit14 
	#define BitPort32DetStatus 							PORTDET2FLAGSbits.bit.GlobalBit15 

 	//---------------------------------------------------------------------------------------------------------------------------------------
	#define BitPort1Control 							PORTCTRL1FLAGSbits.bit.GlobalBit0
	#define BitPort2Control 							PORTCTRL1FLAGSbits.bit.GlobalBit1
	#define BitPort3Control 							PORTCTRL1FLAGSbits.bit.GlobalBit2 
	#define BitPort4Control 							PORTCTRL1FLAGSbits.bit.GlobalBit3 
	#define BitPort5Control 							PORTCTRL1FLAGSbits.bit.GlobalBit4 
	#define BitPort6Control 							PORTCTRL1FLAGSbits.bit.GlobalBit5 
	#define BitPort7Control 							PORTCTRL1FLAGSbits.bit.GlobalBit6 
	#define BitPort8Control 							PORTCTRL1FLAGSbits.bit.GlobalBit7 
	#define BitPort9Control 							PORTCTRL1FLAGSbits.bit.GlobalBit8 
	#define BitPort10Control 							PORTCTRL1FLAGSbits.bit.GlobalBit9 
	#define BitPort11Control 							PORTCTRL1FLAGSbits.bit.GlobalBit10 
	#define BitPort12Control 							PORTCTRL1FLAGSbits.bit.GlobalBit11 
	#define BitPort13Control 							PORTCTRL1FLAGSbits.bit.GlobalBit12 
	#define BitPort14Control 							PORTCTRL1FLAGSbits.bit.GlobalBit13 
	#define BitPort15Control 							PORTCTRL1FLAGSbits.bit.GlobalBit14 
	#define BitPort16Control 							PORTCTRL1FLAGSbits.bit.GlobalBit15 

 	//---------------------------------------------------------------------------------------------------------------------------------------
	#define BitPort17Control 							PORTCTRL2FLAGSbits.bit.GlobalBit0
	#define BitPort18Control 							PORTCTRL2FLAGSbits.bit.GlobalBit1
	#define BitPort19Control 							PORTCTRL2FLAGSbits.bit.GlobalBit2 
	#define BitPort20Control 							PORTCTRL2FLAGSbits.bit.GlobalBit3 
	#define BitPort21Control 							PORTCTRL2FLAGSbits.bit.GlobalBit4 
	#define BitPort22Control 							PORTCTRL2FLAGSbits.bit.GlobalBit5 
	#define BitPort23Control 							PORTCTRL2FLAGSbits.bit.GlobalBit6 
	#define BitPort24Control 							PORTCTRL2FLAGSbits.bit.GlobalBit7 
	#define BitPort25Control 							PORTCTRL2FLAGSbits.bit.GlobalBit8 
	#define BitPort26Control 							PORTCTRL2FLAGSbits.bit.GlobalBit9 
	#define BitPort27Control 							PORTCTRL2FLAGSbits.bit.GlobalBit10 
	#define BitPort28Control 							PORTCTRL2FLAGSbits.bit.GlobalBit11 
	#define BitPort29Control 							PORTCTRL2FLAGSbits.bit.GlobalBit12 
	#define BitPort30Control 							PORTCTRL2FLAGSbits.bit.GlobalBit13 
	#define BitPort31Control 							PORTCTRL2FLAGSbits.bit.GlobalBit14 
	#define BitPort32Control 							PORTCTRL2FLAGSbits.bit.GlobalBit15 

	//---------------------------------------------------------------------------------------------------------------------------------------
	#define BitPort1CtrlEnable 							PORTCTRLEn1FLAGSbits.bit.GlobalBit0
	#define BitPort2CtrlEnable 							PORTCTRLEn1FLAGSbits.bit.GlobalBit1
	#define BitPort3CtrlEnable 							PORTCTRLEn1FLAGSbits.bit.GlobalBit2 
	#define BitPort4CtrlEnable 							PORTCTRLEn1FLAGSbits.bit.GlobalBit3 
	#define BitPort5CtrlEnable 							PORTCTRLEn1FLAGSbits.bit.GlobalBit4 
	#define BitPort6CtrlEnable 							PORTCTRLEn1FLAGSbits.bit.GlobalBit5 
	#define BitPort7CtrlEnable 							PORTCTRLEn1FLAGSbits.bit.GlobalBit6 
	#define BitPort8CtrlEnable 							PORTCTRLEn1FLAGSbits.bit.GlobalBit7 
	#define BitPort9CtrlEnable 							PORTCTRLEn1FLAGSbits.bit.GlobalBit8 
	#define BitPort10CtrlEnable							PORTCTRLEn1FLAGSbits.bit.GlobalBit9 
	#define BitPort11CtrlEnable							PORTCTRLEn1FLAGSbits.bit.GlobalBit10 
	#define BitPort12CtrlEnable							PORTCTRLEn1FLAGSbits.bit.GlobalBit11 
	#define BitPort13CtrlEnable							PORTCTRLEn1FLAGSbits.bit.GlobalBit12 
	#define BitPort14CtrlEnable							PORTCTRLEn1FLAGSbits.bit.GlobalBit13 
	#define BitPort15CtrlEnable							PORTCTRLEn1FLAGSbits.bit.GlobalBit14 
	#define BitPort16CtrlEnable							PORTCTRLEn1FLAGSbits.bit.GlobalBit15 

 	//---------------------------------------------------------------------------------------------------------------------------------------
	#define BitPort17CtrlEnable 						PORTCTRLEn2FLAGSbits.bit.GlobalBit0
	#define BitPort18CtrlEnable 						PORTCTRLEn2FLAGSbits.bit.GlobalBit1
	#define BitPort19CtrlEnable 						PORTCTRLEn2FLAGSbits.bit.GlobalBit2 
	#define BitPort20CtrlEnable 						PORTCTRLEn2FLAGSbits.bit.GlobalBit3 
	#define BitPort21CtrlEnable 						PORTCTRLEn2FLAGSbits.bit.GlobalBit4 
	#define BitPort22CtrlEnable 						PORTCTRLEn2FLAGSbits.bit.GlobalBit5 
	#define BitPort23CtrlEnable 						PORTCTRLEn2FLAGSbits.bit.GlobalBit6 
	#define BitPort24CtrlEnable 						PORTCTRLEn2FLAGSbits.bit.GlobalBit7 
	#define BitPort25CtrlEnable							PORTCTRLEn2FLAGSbits.bit.GlobalBit8 
	#define BitPort26CtrlEnable							PORTCTRLEn2FLAGSbits.bit.GlobalBit9 
	#define BitPort27CtrlEnable							PORTCTRLEn2FLAGSbits.bit.GlobalBit10 
	#define BitPort28CtrlEnable							PORTCTRLEn2FLAGSbits.bit.GlobalBit11 
	#define BitPort29CtrlEnable							PORTCTRLEn2FLAGSbits.bit.GlobalBit12 
	#define BitPort30CtrlEnable							PORTCTRLEn2FLAGSbits.bit.GlobalBit13 
	#define BitPort31CtrlEnable							PORTCTRLEn2FLAGSbits.bit.GlobalBit14 
	#define BitPort32CtrlEnable							PORTCTRLEn2FLAGSbits.bit.GlobalBit15 

  	//---------------------------------------------------------------------------------------------------------------------------------------
	#define BitEEPSaveDeviceIP							EEPromFLAGSbits.bit.GlobalBit0	   
	#define BitEEPSaveDeviceSN							EEPromFLAGSbits.bit.GlobalBit1	   
	#define BitEEPSaveDeviceGW							EEPromFLAGSbits.bit.GlobalBit2	   
	#define BitEEPSaveDeviceDNS							EEPromFLAGSbits.bit.GlobalBit3	   
	#define BitEEPSaveDeviceDHCP						EEPromFLAGSbits.bit.GlobalBit4	   
	#define BitEEPSaveDevicePORT						EEPromFLAGSbits.bit.GlobalBit5	   
	#define BitEEPSaveMqttIP							EEPromFLAGSbits.bit.GlobalBit6	   
	#define BitEEPSaveMqttPORT							EEPromFLAGSbits.bit.GlobalBit7	   

	#define BitEEPSaveMqttID							EEPromFLAGSbits.bit.GlobalBit8	   
	#define BitEEPSaveMqttPW							EEPromFLAGSbits.bit.GlobalBit9	   
	#define BitEEPSaveUpdateIP							EEPromFLAGSbits.bit.GlobalBit10	   
	#define BitEEPSaveUpdatePORT						EEPromFLAGSbits.bit.GlobalBit11	   
	#define BitEEPSaveStatusCycle						EEPromFLAGSbits.bit.GlobalBit12   
	#define BitEEPSavePeriod							EEPromFLAGSbits.bit.GlobalBit13   
	//#define BitDHCPSetDataSaveDone 						EEPromFLAGSbits.bit.GlobalBit14 
	#define BitEEPSaveDone								EEPromFLAGSbits.bit.GlobalBit15	   

	//=================================================================================================================================
	//***************************************************************************************************************************************
	//  G L O B A L    Time Data	D E F I N E
	//***************************************************************************************************************************************
	#define _TIME_2MS_VALUE											2		// 1mSec * 2    = 2ms	
	#define _TIME_3MS_VALUE											3		// 1mSec * 3    = 3ms	
	#define _TIME_4MS_VALUE											4		// 1mSec * 4    = 4ms	
	#define _TIME_5MS_VALUE											5		// 1mSec * 5    = 5ms	
	#define _TIME_6MS_VALUE											6		// 1mSec * 6    = 6ms	
	#define _TIME_7MS_VALUE											7		// 1mSec * 7    = 7ms	
	#define _TIME_8MS_VALUE											8		// 1mSec * 8    = 8ms	
	#define _TIME_9MS_VALUE											9		// 1mSec * 9    = 9ms	
	#define _TIME_10MS_VALUE										10		// 1mSec * 10   = 10ms	
	#define _TIME_20MS_VALUE										20		// 1mSec * 20   = 20ms	
	#define _TIME_25MS_VALUE										25		// 1mSec * 25   = 25ms	
	#define _TIME_30MS_VALUE										30		// 1mSec * 30   = 30ms	
	#define _TIME_33MS_VALUE										33		// 1mSec * 30   = 30ms	
	#define _TIME_40MS_VALUE										40		// 1mSec * 40   = 40ms	
	#define _TIME_50MS_VALUE										50		// 1mSec * 50   = 50ms	
	#define _TIME_60MS_VALUE										60		// 1mSec * 60   = 60ms	
	#define _TIME_70MS_VALUE										70		// 1mSec * 70   = 70ms	
	#define _TIME_80MS_VALUE										80		// 1mSec * 80   = 80ms	
	#define _TIME_90MS_VALUE										90		// 1mSec * 90   = 90ms	
	#define _TIME_100MS_VALUE										100		// 1mSec * 100	= 100ms
	#define _TIME_200MS_VALUE										200		// 1mSec * 200	= 200ms
	#define _TIME_250MS_VALUE										300		// 1mSec * 300	= 300ms
	#define _TIME_300MS_VALUE										500		// 1mSec * 500	= 500ms
	#define _TIME_500MS_VALUE										500		// 1mSec * 500	= 500ms
	#define _TIME_1000MS_VALUE										1000	// 1mSec * 1000	= 1000ms
	#define _TIME_1500MS_VALUE										1500	// 1mSec * 1500	= 1500ms
	#define _TIME_2000MS_VALUE										2000	// 1mSec * 2000	= 2000ms
	#define _TIME_3000MS_VALUE										3000	// 1mSec * 3000	= 3000ms
	#define _TIME_4000MS_VALUE										4000	// 1mSec * 4000	= 4000ms
	#define _TIME_5000MS_VALUE										5000	// 1mSec * 5000	= 5000ms
	#define _TIME_8000MS_VALUE										8000	// 1mSec * 8000	= 8000ms
	#define _TIME_10000MS_VALUE										10000	// 1mSec * 10000	= 10000ms
	#define _TIME_15000MS_VALUE										15000	// 1mSec * 15000	= 15000ms
	#define _TIME_20000MS_VALUE										20000	// 1mSec * 20000	= 20000ms
	#define _TIME_30000MS_VALUE										30000	// 1mSec * 30000	= 30000ms
	#define _TIME_40000MS_VALUE										40000	// 1mSec * 40000	= 40000ms

	//#define _TIME_300MS_VALUE										3		// 100mSec * 3	= 300ms
	//#define _TIME_400MS_VALUE										4		// 100mSec * 4	= 300ms
	//#define _TIME_500MS_VALUE										5		// 100mSec * 5	= 500ms
	//#define _TIME_600MS_VALUE										6		// 100mSec * 6	= 600ms
	//#define _TIME_700MS_VALUE										7		// 100mSec * 7	= 700ms
	//#define _TIME_800MS_VALUE										8		// 100mSec * 8	= 800ms
	//#define _TIME_900MS_VALUE										9		// 100mSec * 9	= 900ms
	//#define _TIME_1000MS_VALUE										10		// 100mSec * 10 = 1000ms
	//#define _TIME_2000MS_VALUE										20		// 100mSec * 20 = 2000ms
	//#define _TIME_3000MS_VALUE										30		// 100mSec * 30 = 3000ms
	//#define _TIME_5000MS_VALUE										50		// 100mSec * 50 = 5000ms
	#define _TIME_xxxxMS_VALUE										90		// 100mSec * 90 = 9000ms
	                                                        		
	#define _TIME_1S_VALUE											10		// 100mSec * 10 = 1000ms
	#define _TIME_1_5S_VALUE										15		// 100mSec * 15 = 1500ms
	#define _TIME_2S_VALUE											20		// 100mSec * 20 = 2S 
	#define _TIME_3S_VALUE											30		// 100mSec * 30 = 3S 
	#define _TIME_4S_VALUE											40		// 100mSec * 40 = 4S 
	#define _TIME_5S_VALUE											50		// 100mSec * 50 = 5S
	#define _TIME_10S_VALUE											100		// 100mSec * 100 = 10S
	#define _TIME_15S_VALUE											150		// 100mSec * 150 = 15S
	#define _TIME_16S_VALUE											160		// 100mSec * 160 = 16S
	#define _TIME_17S_VALUE											170		// 100mSec * 170 = 17S
	#define _TIME_18S_VALUE											180		// 100mSec * 180 = 18S
	#define _TIME_19S_VALUE											190		// 100mSec * 190 = 19S
	#define _TIME_20S_VALUE											200		// 100mSec * 200 = 20S
	#define _TIME_25S_VALUE											250		// 100mSec * 250 = 25S
	#define _TIME_30S_VALUE											300		// 100mSec * 300 = 30S
	#define _TIME_40S_VALUE											400		// 100mSec * 400 = 40S
	#define _TIME_50S_VALUE											500		// 100mSec * 500 = 50S
	#define _TIME_60S_VALUE											600		// 100mSec * 600 = 60S
	#define _TIME_3SECOND_VALUE										3		// 1Sec * 3 = 3Sec
	#define _TIME_1MINUTE_VALUE										60		// 1Sec * 60 = 60Sec
	#define _TIME_5MINUTE_VALUE										300		// 1Sec * 300 = 300Sec
	#define _TIME_10MINUTE_VALUE									600		// 1Sec * 600 = 600Sec
	#define _TIME_1HOUR_VALUE										60		// 1Min * 60 = 3600Sec

	//=================================================================================================================================
	//***************************************************************************************************************************************
	//  G L O B A L     K E Y   D E F I N I T I O N S    P R O T O T Y P E S
	//***************************************************************************************************************************************
	#define _CONT_KEY_TIME_START									50  //10mS * xx  (ex: 300mS.250mS.200mS .....)
	#define _CONT_KEY_STEP     										3  	//step down every 30mS
	#define _MAX_SPEED_TIME 										1
	                                    							
	#define	_KEY_xxxxmS												65000 // 10mSec * 500 = 5000ms
	#define	_KEY_5000mS												500/10 // 10mSec * 500 = 5000ms
	#define	_KEY_3000mS												300/10 // 10mSec * 300 = 3000ms
	#define	_KEY_2000mS												200/10 // 10mSec * 200 = 2000ms
	#define	_KEY_1000mS												100/10 // 10mSec * 100 = 1000ms
	#define	_KEY_800mS												80 /10 // 10mSec * 80 = 800ms
	#define	_KEY_700mS												70 /10 // 10mSec * 50 = 500ms
	#define	_KEY_500mS												50 /10 // 10mSec * 50 = 500ms
	#define	_KEY_100mS												10 /10 // 10mSec * 10 = 100ms

	#define	_KEY_50mS												5	  // 10mSec * 5 = 500ms
	#define _KEY_30mS       										3	  // 10mSec * 3 = 300ms
	#define _KEY_10mS       										1	  // 10mSec * 1 = 100ms

	#define _KEY_SET												1             
	#define _KEY_JOG_UP												2             
	#define _KEY_JOG_DOWN											3             

	#define	_KEY_NO_KEY												0xFF

 	//=========================================================================================================================
	//*************************************************************************************************************************
	//  G L O B A L    A  S  C  I  I    D E F I N I T I O N S    P R O T O T Y P E S
	//*************************************************************************************************************************
	#define _TEXT_NUL												0x00  //  NUL    (���ڿ��� ��: Null char)
	#define _TEXT_SOH												0x01  //  SOH    (Start of Heading)
	#define _TEXT_STX												0x02  //  STX    (Start of Text)
	#define _TEXT_ETX												0x03  //  ETX    (End of Text)
	#define _TEXT_EOT												0x04  //  EOT    (End of Transmission)
	#define _TEXT_ENQ												0x05  //  ENQ    (Enquiry)
	#define _TEXT_ACK												0x06  //  ACK    (Acknowledgment)
	#define _TEXT_BEL												0x07  //  BEL    (������: Bell)
	#define _TEXT_BS												0x08  //   BS    (�齺���̽�: Backspace)
	#define _TEXT_HT												0x09  //   HT    (��: Horizontal Tab)
	#define _TEXT_LF												0x0A  //   LF    (�ٹٲ�: NL Line Feed/New Line)
	#define _TEXT_VT												0x0B  //   VT    (Vertical Tab)
	#define _TEXT_FF												0x0C  //   FF    (������ ���� ����: Form Feed/New Page)
	#define _TEXT_CR												0x0D  //   CR    (�ٹٲ�: Carriage Return)
	#define _TEXT_SO												0x0E  //   SO    (Shift Out)
	#define _TEXT_SI												0x0F  //   SI    (Shift In)
	#define _TEXT_DLE												0x10  //  DLE    (Data Link Escape)
	#define _TEXT_DC1												0x11  //  DC1    (Device Control 1)
	#define _TEXT_DC2												0x12  //  DC2    (Device Control 2)
	#define _TEXT_DC3												0x13  //  DC3    (Device Control 3)
	#define _TEXT_DC4												0x14  //  DC4    (Device Control 4)
	#define _TEXT_NAK												0x15  //  NAK    (Negative Acknowledge)
	#define _TEXT_SYN												0x16  //  SYN    (Synchronous Idle)
	#define _TEXT_ETB												0x17  //  ETB    (End of Transmission Block)
	#define _TEXT_CAN												0x18  //  CAN    (Cancel)
	#define _TEXT_EM												0x19  //   EM    (End of Medium)
	#define _TEXT_SUB												0x1A  //  SUB    (Substitute / End of File; EOF)
	#define _TEXT_ESC												0x1B  //  ESC    (EscŰ: Escape)
	#define _TEXT_FS												0x1C  //   FS    (File Separator)
	#define _TEXT_GS												0x1D  //   GS    (Group Separator)
	#define _TEXT_RS												0x1E  //   RS    (Request to Send / Record Separator)
	#define _TEXT_US												0x1F  //   US    (Unit Separator)
	#define _TEXT_SP												0x20  //   SP    (1����Ʈ ����: Space)
	#define _TEXT_EXCLAMATION_MARK									0x21  //    !    (����ǥ: exclamation mark)
	#define _TEXT_D_QUOTE											0x22  //    "    (ū����ǥ: double quote)
	#define _TEXT_SHARTP											0x23  //    #    (����: number sign)
	#define _TEXT_DOLLAR											0x24  //    $    (�޷�: dollar sign)
	#define _TEXT_PERCENT											0x25  //    %    (�ۼ�Ʈ: percent)
	#define _TEXT_AMPERSAND											0x26  //    &    (���ۻ���: ampersand)
	#define _TEXT_S_QUOTE											0x27  //    '    (��������ǥ: single quote)
	#define _TEXT_L_PARENTHESIS										0x28  //    (    (�Ұ�ȣ: left/opening parenthesis)
	#define _TEXT_R_PARENTHESIS										0x29  //    )    (�Ұ�ȣ:right/closing parenthesis)
	#define _TEXT_ASTERISK											0x2A  //    *    (��ǥ: asterisk)
	#define _TEXT_PLUS												0x2B  //    +    (�÷���: plus)
	#define _TEXT_COMMA												0x2C  //    ,    (��ǥ: comma)
	#define _TEXT_MINUS												0x2D  //    -    (���̳ʽ�: minus or dash)
	#define _TEXT_DOT												0x2E  //    .    (��ħǥ: dot)
	#define _TEXT_SLASH												0x2F  //    /    (������: forward slash)
	#define _TEXT_COLON												0x3A  //    :    (�ݷ�: colon)
	#define _TEXT_SEMI_COLON										0x3B  //    ;    (�����ݷ�: semi-colon)
	#define _TEXT_LESS												0x3C  //    <    (�ε�ȣ: less than)
	#define _TEXT_EQUAL												0x3D  //    =    (��ȣ: equal sign)
	#define _TEXT_GREATER											0x3E  //    >    (�ε�ȣ: greater than)
	#define _TEXT_QUESTION											0x3F  //    ?    (����ǥ: question mark)
	#define _TEXT_AT_SYMBOL											0x40  //    @    (�� ����, �����: AT symbol)
	#define _TEXT_L_BRACKET											0x5B  //    [    (���ȣ: left/opening bracket)
	#define _TEXT_B_SLASH											0x5C  //    \    (�齽����: back slash)
	#define _TEXT_R_BRACKET											0x5D  //    ]    (���ȣ: right/closing bracket)
	#define _TEXT_CIRCUMFLEX										0x5E  //    ^    (ĳ��: caret/circumflex)
	#define _TEXT_UNDERSCORE										0x5F  //    _    (����: underscore)
	#define _TEXT_BACKQUOTE											0x60  //    `    (��ƽ: acute accent / backquote / backtick)
	#define _TEXT_L_BRACE											0x7B  //    {    (�߰�ȣ: left/opening brace)
	#define _TEXT_V_BAR												0x7C  //    |    (������: vertical bar)
	#define _TEXT_R_BRACE											0x7D  //    }    (�߰�ȣ: right/closing brace)
	#define _TEXT_TILDE												0x7E  //    ~    (���ṫ��: tilde)
	#define _TEXT_DEL												0x7F  //  DEL    (����: delete)

	//-------------------------------------------------------------------------------------------------------------------------
	#define _TEXT_0													0x30	// "0"
	#define _TEXT_1													0x31	// "1"
	#define _TEXT_2													0x32	// "2"
	#define _TEXT_3													0x33	// "3"
	#define _TEXT_4													0x34	// "4"
	#define _TEXT_5													0x35	// "5"
	#define _TEXT_6													0x36	// "6"
	#define _TEXT_7													0x37	// "7"
	#define _TEXT_8													0x38	// "8"
	#define _TEXT_9													0x39	// "9"

	//-------------------------------------------------------------------------------------------------------------------------
	#define _TEXT_A													0x41	// "A"
	#define _TEXT_B													0x42	// "B"
	#define _TEXT_C													0x43	// "C"
	#define _TEXT_D													0x44	// "D"
	#define _TEXT_E													0x45	// "E"
	#define _TEXT_F													0x46	// "F"
	#define _TEXT_G													0x47	// "G"
	#define _TEXT_H													0x48	// "H"
	#define _TEXT_I													0x49	// "I"
	#define _TEXT_J													0x4A	// "J"
	#define _TEXT_K													0x4B	// "K"
	#define _TEXT_L													0x4C	// "L"
	#define _TEXT_M													0x4D	// "M"
	#define _TEXT_N													0x4E	// "N"
	#define _TEXT_O													0x4F	// "O"
	#define _TEXT_P													0x50	// "P"
	#define _TEXT_Q													0x51	// "Q"
	#define _TEXT_R													0x52	// "R"
	#define _TEXT_S													0x53	// "S"
	#define _TEXT_T													0x54	// "T"
	#define _TEXT_U													0x55	// "U"
	#define _TEXT_V													0x56	// "V"
	#define _TEXT_W													0x57	// "W"
	#define _TEXT_X													0x58	// "X"
	#define _TEXT_Y													0x59	// "Y"
	#define _TEXT_Z													0x5A	// "Z"

	//-------------------------------------------------------------------------------------------------------------------------
	#define _TEXT_a													0x61	// "a"
	#define _TEXT_b													0x62	// "b"
	#define _TEXT_c													0x63	// "c"
	#define _TEXT_d													0x64	// "d"
	#define _TEXT_e													0x65	// "e"
	#define _TEXT_f													0x66	// "f"
	#define _TEXT_g													0x67	// "g"
	#define _TEXT_h													0x68	// "h"
	#define _TEXT_i													0x69	// "i"
	#define _TEXT_j													0x6A	// "j"
	#define _TEXT_k													0x6B	// "k"
	#define _TEXT_l													0x6C	// "l"
	#define _TEXT_m													0x6D	// "m"
	#define _TEXT_n													0x6E	// "n"
	#define _TEXT_o													0x6F	// "o"
	#define _TEXT_p													0x70	// "p"
	#define _TEXT_q													0x71	// "q"
	#define _TEXT_r													0x72	// "r"
	#define _TEXT_s													0x73	// "s"
	#define _TEXT_t													0x74	// "t"
	#define _TEXT_u													0x75	// "u"
	#define _TEXT_v													0x76	// "v"
	#define _TEXT_w													0x77	// "w"
	#define _TEXT_x													0x78	// "x"
	#define _TEXT_y													0x79	// "y"
	#define _TEXT_z													0x7A	// "z"

	//============================================================================================================================
	//***************************************************************************************************************************************
	//  G L O B A L  	M O D B U S / T C P		D E F I N E
	//***************************************************************************************************************************************
	#define _MAX_ETHERNET_BUFFER_SIZE								300

	#define _MAX_RECEIVE_DATA_COUNT									80
	#define _MIN_RECEIVE_DATA_COUNT									5
	#define _MIN_MODBUS_RECEIVE_DATA_COUNT							5

    //=======================================================================================================================================
	#define _MODBUS_DEVICE_ID										1
	#define _MODBUS_SLAVE_ADDRESS_INDEX								0
	#define _MODBUS_FUNCTION_CODE_INDEX								1

    //=======================================================================================================================================
	/* Modbus Receive code length */
	#define MODBUS_TCP_CODE_LENGTH                					12
	#define _CURRENT_ADDRESS_CODE									100// Address 100

    //=======================================================================================================================================
 	// 				0  1  2  3  4  5  6  7  8  9  10 11
	//Modbus TCP	00 0F 00 00 00 06 01 03 02 58 00 02
 	#define _MODBUS_TCP_RX_TRANSACTION_ID_HIGH_INDEX				0
 	#define _MODBUS_TCP_RX_TRANSACTION_ID_LOW_INDEX					1	// 2Byte
 	#define _MODBUS_TCP_RX_PROTOCOL_ID_HIGH_INDEX					2
 	#define _MODBUS_TCP_RX_PROTOCOL_ID_LOW_INDEX					3	// 2Byte
 	#define _MODBUS_TCP_RX_LENGTH_ID_HIGH_INDEX						4
 	#define _MODBUS_TCP_RX_LENGTH_ID_LOW_INDEX						5	// 2Byte
 	#define _MODBUS_TCP_RX_UNIT_ID_INDEX							6   // 1Byte
 	#define _MODBUS_TCP_RX_FUNCTION_CODE_INDEX						7   // 1Byte
 	#define _MODBUS_TCP_RX_START_ADDR_HIGH_INDEX					8
 	#define _MODBUS_TCP_RX_START_ADDR_LOW_INDEX						9	// 2Byte
 	#define _MODBUS_TCP_RX_GET_COUNT_HIGH_INDEX						10
 	#define _MODBUS_TCP_RX_GET_COUNT_LOW_INDEX						11	// 2Byte

 	//---------------------------------------------------------------------------------------------------------------------------------------
 	// 				0  1  2  3  4  5  6  7  8  9  10 11 12
	//Modbus TCP	00 0F 00 00 00 07 01 03 04 03 E8 13 88
 	#define _MODBUS_TCP_TX_TRANSACTION_ID_HIGH_INDEX				0
 	#define _MODBUS_TCP_TX_TRANSACTION_ID_LOW_INDEX					1	// 2Byte
 	#define _MODBUS_TCP_TX_PROTOCOL_ID_HIGH_INDEX					2
 	#define _MODBUS_TCP_TX_PROTOCOL_ID_LOW_INDEX					3	// 2Byte
 	#define _MODBUS_TCP_TX_LENGTH_ID_HIGH_INDEX						4
 	#define _MODBUS_TCP_TX_LENGTH_ID_LOW_INDEX						5	// 2Byte
 	#define _MODBUS_TCP_TX_UNIT_ID_INDEX							6   // 1Byte
 	#define _MODBUS_TCP_TX_FUNCTION_CODE_INDEX						7   // 1Byte
 	#define _MODBUS_TCP_TX_COUNT_INDEX								8   // 1Byte
 	#define _MODBUS_TCP_TX_START_DATA_INDEX							9	// 1Byte

  	//=======================================================================================================================================
	//***************************************************************************************************************************************
	//  G L O B A L    S D R A M	D E F I N E
	//***************************************************************************************************************************************
	#define SDRAM_BANK_ADDR                 						((uint32_t)0xC0000000)

  	//=======================================================================================================================================
	//***************************************************************************************************************************************
	//  G L O B A L    W 5 5 0 0 	D E F I N E
	//***************************************************************************************************************************************
	#define BUFFER_SIZE												2048
	#define DATA_BUF_SIZE   										2048

	#define SOCK_MQTT       										0
	#define SOCK_UDPS       										1
	#define SOCK_UDPS_SETUP       									2

	#define SOCK_SNTP       										4
	#define SOCK_VERSION       										5
	#define SOCK_DHCP       										6

	#define MAX_PORT_ANY											29999
	#define PORT_ANY												20000
	#define PORT_TCPS												6000
	#define PORT_UDPS_BROADCAST       								37011	// Server -> Device  Server Port
	#define PORT_UDPS_REPLY       									37012	// Device -> Server
	#define PORT_UDPS_SETUP    										37013	// Server -> Device
	#define PORT_DEST_TCPS											6000

  	//=======================================================================================================================================
	//***************************************************************************************************************************************
	//  G L O B A L    D E F I N E
	//***************************************************************************************************************************************
	#define GSTECH_TOPIC_IN_CTRL									"/in/control"
	#define GSTECH_TOPIC_IN_STATUS									"/in/status"

	#define GSTECH_TYPE 											"type"
	#define GSTECH_ID 												"idx"
	#define STATUS     												"status"
	#define OPERATION_TIME  										"time"
	#define GSTECH_PASSWORD   										"passwd"

	#define GSTECH_DEVICE_ID 										"deviceId"
	#define GSTECH_DHCP 											"dhcp"
	#define GSTECH_IP     											"ip"
	#define GSTECH_SUBNET  											"subnet"
	#define GSTECH_GATEWAY   										"gateway"

	#define GSTECH_MQTT_IP   										"mqttIp"
	#define GSTECH_MQTT_PORT   										"mqttPort"
	#define GSTECH_MQTT_ID   										"mqttId"
	#define GSTECH_MQTT_PW   										"mqttPw"

	#define GSTECH_UPDATE_IP   										"updateIp"
	#define GSTECH_UPDATE_PORT   									"updatePort"
	#define GSTECH_STATUS_CYCLE   									"statusCycle"
	#define GSTECH_PERIOD   										"period"

	#define GSTECH_ON_OFF   										"ON/OFF"
	#define GSTECH_DELAY   											"DELAY"
	#define GSTECH_JOGGING   										"JOGGING"
	#define GSTECH_ALL_ON_OFF										"ALL_ON/OFF"
	#define GSTECH_RESET   											"RESET"
	#define GSTECH_UPDATE   										"UPDATE"
	#define GSTECH_REBOOT   										"REBOOT"

	//-------------------------------------------------------------------------------------------------------------------------
	#define _MQTT_MAX_ID_COUNT										10
	#define _MQTT_MAX_PW_COUNT										15

	//-------------------------------------------------------------------------------------------------------------------------
	#define _MQTT_REBOOT_TIME_OUT_COUNT								30		//30 Second

	//=================================================================================================================================
	#define _MAX_COMx_RX_BUFFER_SIZE								200
	#define _MAX_COMx_TX_BUFFER_SIZE								200

	#define _MAX_COIL_BUFFER										200		// (������ ���忡 ���Ǵ� Coil�� 300 Coil) / 8 Byte = 37.5 Byte
	#define _MAX_REGISTER_BUFFER									125

 	#define _USART_RECEIVED_TIME_OVER                              	_TIME_5MS_VALUE		// 5msec                          		

	//=================================================================================================================================
	#define _GPIO_PORT_STABLE_COUNT									5                                                    	
	#define _GPIO_PORT_UNSTABLE_COUNT								5                                                    	
	#define _INITIAL_ADC_AVERAGE_COUNT								10
	#define _CENTRE_ADC_AVERAGE_COUNT								(_INITIAL_ADC_AVERAGE_COUNT/2)
	#define _MAX_TEMP												100		// 100��

	//=================================================================================================================================
	#define _MQTT_COMMAND_NONE										0
	#define _MQTT_COMMAND_ON_OFF									1
	#define _MQTT_COMMAND_DELAY										2
	#define _MQTT_COMMAND_JOGGING									3
	#define _MQTT_COMMAND_ALL_ON_OFF								4
	#define _MQTT_COMMAND_RESET										5
	#define _MQTT_COMMAND_UPDATE									6
	#define _MQTT_COMMAND_REBOOT									7

	//-------------------------------------------------------------------------------------------------------------------------
	#define _MQTT_RELAY_1_INDEX										1
	#define _MQTT_RELAY_2_INDEX										2
	#define _MQTT_RELAY_3_INDEX										3
	#define _MQTT_RELAY_4_INDEX										4
	#define _MQTT_RELAY_5_INDEX										5
	#define _MQTT_RELAY_6_INDEX										6
	#define _MQTT_RELAY_7_INDEX										7
	#define _MQTT_RELAY_8_INDEX										8

	#define _TEMP_SENSOR_STEP										40.95	// 4095 / 100 ��

	//=================================================================================================================================
	#define _MAX_RELAY_COUNT										4

	//=================================================================================================================================
	//***************************************************************************************************************************************
	//  G L O B A L  	W I N D O W		M O D E 	D E F I N E
	//***************************************************************************************************************************************
	#define _WINDOW_NORMAL_MODE							0

	//=================================================================================================================================
	//***************************************************************************************************************************************
	//  G L O B A L    E R R O R	C O D E 	D E F I N E
	//***************************************************************************************************************************************
	#define _ERROR_CODE_USB_NOT_IN						0
	#define _ERROR_CODE_USB_MOUNT_FAIL					1
	#define _ERROR_CODE_USB_SIZE_OVER					2
	#define _ERROR_CODE_TIME							3
	#define _ERROR_CODE_USB_WRITE_FAIL					4

	#define _ERROR_STABLE_COUNT							10

	//=================================================================================================================================
	//***************************************************************************************************************************************
	//  G L O B A L    E E P M A P  	D E F I N E
	//***************************************************************************************************************************************
	//EEP-MAP
	#define _EEPROM_PAGE											16				//Max page-write bytes
	#define _EEPROM_READ_WRITE_TIME_OVER							100				// 100 * 1 msec = 100 msec
	#define _EEPROM_DATA_SAVE_TIME									_TIME_1000MS_VALUE	// 1000 * 1 msec = 1000 msec
	#define	_I2C_RETRY_COUNT										5				//Count of I2C error

	//-------------------------------------------------------------------------------------------------------------------------
	#define	_EEP_DEVICE_ADDRESS										0xA0
	#define _EEPROM_TX_ADDRESS										0xA0			//Write address of EEP-ROM
	#define _EEPROM_RX_ADDRESS										0xA1			//Read address of EEP-ROM
	#define	_EEP_RETRY_COUNT										5

	//-------------------------------------------------------------------------------------------------------------------------
	#define	_CHIP_BLANK_ID											0x68

	//=========================================================================================================================
	#define _EEP_ADDR_DEVICE_IP      								0x00							// Current IP Address
	#define _EEP_ADDR_DEVICE_SN      								0x04//(_EEP_ADDR_DEVICE_IP    + 4	)	// Current Subnet Mask
	#define _EEP_ADDR_DEVICE_GW      								0x08//(_EEP_ADDR_DEVICE_SN    + 4	)	// Current Gateway
	#define _EEP_ADDR_DEVICE_DNS      								0x0C//(_EEP_ADDR_DEVICE_GW    + 4	)	// Current Domain Name Server
	#define _EEP_ADDR_DEVICE_PORT									0x10//(_EEP_ADDR_DEVICE_DNS   + 4	)	// Current Port
	#define _EEP_ADDR_DEVICE_DHCP 									0x12//(_EEP_ADDR_DEVICE_PORT  + 2	)	// Current < Dynamic IP configruation from a DHCP sever
	#define _EEP_ADDR_MQTT_IP 										0x13//(_EEP_ADDR_DEVICE_DHCP  + 1	)	// Mqtt IP Address
	#define _EEP_ADDR_MQTT_PORT										0x17//(_EEP_ADDR_MQTT_IP 	    + 4	)	// Mqtt Port
	#define _EEP_ADDR_UPDATE_IP 									0x1B//(_EEP_ADDR_MQTT_PW      + 16)		// Update IP Address
	#define _EEP_ADDR_UPDATE_PORT									0x1F//(_EEP_ADDR_UPDATE_IP    + 4	)	// Update Port
	#define _EEP_ADDR_STATUS_CYCLE									0x22//(_EEP_ADDR_UPDATE_IP    + 2	)	// Update Status Cycle = 'True' , 'False'
	#define _EEP_ADDR_PERIOD										0x23//(_EEP_ADDR_STATUS_CYCLE + 1	)	// Update Period

	//-------------------------------------------------------------------------------------------------------------------------
	#define _EEP_ADDR_MQTT_ID										0x30//(_EEP_ADDR_PERIOD	  + 2	)	// Mqtt ID
	#define _EEP_ADDR_MQTT_PW										0x40//(_EEP_ADDR_MQTT_ID	  + 16	)	// Mqtt PW

	//-------------------------------------------------------------------------------------------------------------------------
	#define _EEP_ADDR_FIRMWARE_VERSION								0x50//(_EEP_ADDR_MQTT_PW	  + 16	)	// Mqtt PW
	#define _EEP_ADDR_MQTT_ID_LENGTH								0x54
	#define _EEP_ADDR_MQTT_PW_LENGTH								0x55
	#define _EEP_ADDR_FIRMWARE_VERSION_ENABLE						0x5F//(_EEP_ADDR_FIRMWARE_VERSION	  + 15	)	// Mqtt PW

	//-------------------------------------------------------------------------------------------------------------------------
	#define _EEP_INIT_ADDRESS										0x60//(_EEP_ADDR_FIRMWARE_VERSION + 16	)	// 0x70

	//-------------------------------------------------------------------------------------------------------------------------
	#define _EEP_ADDR_DEVICE_MAC 									0xFA						// MAC Address 6 Byte

	//=================================================================================================================================
	//***************************************************************************************************************************************
	//  G L O B A L    I 2 C   P O R T 	   D E F I N E
	//***************************************************************************************************************************************
	#define EEPROM_I2C_CLK_HIGH()	        						HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, GPIO_PIN_SET)
	#define EEPROM_I2C_CLK_LOW()	        						HAL_GPIO_WritePin(GPIOB, GPIO_PIN_10, GPIO_PIN_RESET)

	#define EEPROM_I2C_DATA_HIGH()	        						HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, GPIO_PIN_SET)
	#define EEPROM_I2C_DATA_LOW()	        						HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, GPIO_PIN_RESET)

	#define EEPROM_I2C_DATA_INPUT_PORT()							HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_11)	
	#define EEPROM_I2C_DATA_IN()									HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_11)	

	//=================================================================================================================================
	//***************************************************************************************************************************************
	//  G L O B A L    P O R T 	   D E F I N E
	//***************************************************************************************************************************************
	#define USART2_RX_ENABLE_ON()	        						HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_RESET)     
	#define USART2_TX_ENABLE_ON()	        						HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, GPIO_PIN_SET)	     

	//=======================================================================================================================================
	// SD Card Chip Select Port
	#define SD_CARD_CS_OFF()	        							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_10, GPIO_PIN_SET)		
	#define SD_CARD_CS_ON()	        								HAL_GPIO_WritePin(GPIOC, GPIO_PIN_10, GPIO_PIN_RESET)	

	//-------------------------------------------------------------------------------------------------------------------------
	// SD Card Detect Port
	#define SD_CARD_IN_DETECT()										HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_6)

	//=======================================================================================================================================
	// Serial Flase Chip Select Port
	#define FLASH_CS_OFF()	        								HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, GPIO_PIN_SET)		
	#define FLASH_CS_ON()	        								HAL_GPIO_WritePin(GPIOB, GPIO_PIN_11, GPIO_PIN_RESET)	

	//-------------------------------------------------------------------------------------------------------------------------
	// Serial Flase Write Protect Port
	#define FLASH_WP_OFF()	        								HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_SET)		
	#define FLASH_WP_ON()	        								HAL_GPIO_WritePin(GPIOB, GPIO_PIN_1, GPIO_PIN_RESET)	

	//=======================================================================================================================================
	// W5500 Chip Select Port
	#define W5500_CS_HIGH()	        								HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET)		
	#define W5500_CS_LOW()	        								HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET)	

	//-------------------------------------------------------------------------------------------------------------------------
	// W5500 rESET Port
	#define W5500_RESET_HIGH()	        							HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_SET)		
	#define W5500_RESET_LOW()	        							HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, GPIO_PIN_RESET)	

	//=======================================================================================================================================
	// Port Output
	#define RELAY_PORT_1_ON()	        							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_SET)		//;BitPort1DetStatus = _SET;}	
	#define RELAY_PORT_1_OFF()	        							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_2, GPIO_PIN_RESET)	//;BitPort1DetStatus = _CLR;}	

	//-------------------------------------------------------------------------------------------------------------------------
	#define RELAY_PORT_2_ON()	        							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_SET)		//;BitPort2DetStatus = _SET;}		
	#define RELAY_PORT_2_OFF()	        							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_1, GPIO_PIN_RESET)	//;BitPort2DetStatus = _CLR;}	

	//-------------------------------------------------------------------------------------------------------------------------
	#define RELAY_PORT_3_ON()	        							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_SET)		//;BitPort3DetStatus = _SET;}		
	#define RELAY_PORT_3_OFF()	        							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_0, GPIO_PIN_RESET)	//;BitPort3DetStatus = _CLR;}	

	//-------------------------------------------------------------------------------------------------------------------------
	#define RELAY_PORT_4_ON()	        							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_SET)	//;BitPort4DetStatus = _SET;}		
	#define RELAY_PORT_4_OFF()	        							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET)	//;BitPort4DetStatus = _CLR;}	

	//-------------------------------------------------------------------------------------------------------------------------
	#define RELAY_PORT_5_ON()	        							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_SET)		//;BitPort5DetStatus = _SET;}		
	#define RELAY_PORT_5_OFF()	        							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_5, GPIO_PIN_RESET)	//;BitPort5DetStatus = _CLR;}	

	//-------------------------------------------------------------------------------------------------------------------------
	#define RELAY_PORT_6_ON()	        							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_SET)		//;BitPort6DetStatus = _SET;}		
	#define RELAY_PORT_6_OFF()	        							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_4, GPIO_PIN_RESET)	//;BitPort6DetStatus = _CLR;}	

	//-------------------------------------------------------------------------------------------------------------------------
	#define RELAY_PORT_7_ON()	        							HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_SET)		//;BitPort7DetStatus = _SET;}		
	#define RELAY_PORT_7_OFF()	        							HAL_GPIO_WritePin(GPIOA, GPIO_PIN_0, GPIO_PIN_RESET)	//;BitPort7DetStatus = _CLR;}	

	//-------------------------------------------------------------------------------------------------------------------------
	#define RELAY_PORT_8_ON()	        							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_SET)		//;BitPort8DetStatus = _SET;}		
	#define RELAY_PORT_8_OFF()	        							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3, GPIO_PIN_RESET)	//;BitPort8DetStatus = _CLR;}	

	//-------------------------------------------------------------------------------------------------------------------------
	#define CTRL_PORT_1_ON()	        							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, GPIO_PIN_SET)		
	#define CTRL_PORT_1_OFF()	        							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_9, GPIO_PIN_RESET)	

	//-------------------------------------------------------------------------------------------------------------------------
	#define CTRL_PORT_2_ON()	        							HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_SET)		
	#define CTRL_PORT_2_OFF()	        							HAL_GPIO_WritePin(GPIOA, GPIO_PIN_8, GPIO_PIN_RESET)	

	//=======================================================================================================================================
	// Status LED Port
	#define STATUS_LED_1_OFF()	        							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_SET)		
	#define STATUS_LED_1_ON()	        							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_7, GPIO_PIN_RESET)	

	//-------------------------------------------------------------------------------------------------------------------------
	#define STATUS_LED_2_OFF()	        							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, GPIO_PIN_SET)		
	#define STATUS_LED_2_ON()	        							HAL_GPIO_WritePin(GPIOC, GPIO_PIN_8, GPIO_PIN_RESET)	

	//=======================================================================================================================================
	// Port Input
	#define PORT_1_DETECT()											HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_9)
	#define PORT_2_DETECT()											HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_8)
	#define PORT_3_DETECT()											HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_7)
	#define PORT_4_DETECT()											HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_6)
	#define PORT_5_DETECT()											HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_5)
	#define PORT_6_DETECT()											HAL_GPIO_ReadPin(GPIOD, GPIO_PIN_2)
	#define PORT_7_DETECT()											HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_12)
	#define PORT_8_DETECT()											HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_11)

	//-------------------------------------------------------------------------------------------------------------------------
	#define PORT_1_INPUT()											HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_11)
	#define PORT_2_INPUT()											HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_12)

	//=======================================================================================================================================
	#define DEBUG_ON()	        									HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_SET)	 
	#define DEBUG_OFF()	        									HAL_GPIO_WritePin(GPIOB, GPIO_PIN_2, GPIO_PIN_RESET) 

	//=======================================================================================================================================

#endif	//__DEFINE_H

/******************* (C) COPYRIGHT 2014 NEXON chip co., *********END OF FILE****/
