#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "define.h"
#include "extern.h"
#include "loopback.h"
#include "socket.h"
#include "wizchip_conf.h"
#include "MQTTClient.h"

#define REQUEST_INFO 		"REQUEST_INFO"
#define REQUEST_SETUP 		"REQUEST_SETUP"

int32_t loopback_tcps(uint8_t sn, uint8_t* buf, uint16_t port)
{
   	int32_t ret;
   	uint16_t size = 0, sentsize=0;

	#ifdef __LOOPBACK_DEBUG__
  	uint8_t destip[4];
   	uint16_t destport;
	#endif

   	switch(getSn_SR(sn))
   	{
   	   	case SOCK_ESTABLISHED :
   	      	if(getSn_IR(sn) & Sn_IR_CON)
   	      	{
				#ifdef __LOOPBACK_DEBUG__
				getSn_DIPR(sn, destip);
				destport = getSn_DPORT(sn);
   	      	
				printf("%d:Connected - %d.%d.%d.%d : %d\r\n",sn, destip[0], destip[1], destip[2], destip[3], destport);
				#endif
				setSn_IR(sn,Sn_IR_CON);
   	      	}
   	
			if((size = getSn_RX_RSR(sn)) > 0) // Don't need to check SOCKERR_BUSY because it doesn't not occur.
   	      	{
				if(size > DATA_BUF_SIZE) 
					size = DATA_BUF_SIZE;
				ret = recv(sn, buf, size);
   	
				if(ret <= 0) 
					return ret;      // check SOCKERR_BUSY & SOCKERR_XXX. For showing the occurrence of SOCKERR_BUSY.

				size = (uint16_t) ret;
				sentsize = 0;
   	
				while(size != sentsize)
				{
					ret = send(sn, buf+sentsize, size-sentsize);
					if(ret < 0)
					{
						close(sn);
						return ret;
					}
					sentsize += ret; // Don't care SOCKERR_BUSY, because it is zero.
				}
   	      	}
   	      	break;
   	   case SOCK_CLOSE_WAIT :
   	      	if((ret = disconnect(sn)) != SOCK_OK)
   	      	 	return ret;
   	      	break;
   	   case SOCK_INIT :
   	      	if( (ret = listen(sn)) != SOCK_OK) 
   	      		return ret;
   	      	break;
   	   case SOCK_CLOSED:
   	      	if((ret = socket(sn, Sn_MR_TCP, port, 0x00)) != sn) 
   	      		return ret;
   	      	break;
   	   default:
   	      	break;
   	}
 
   	return 1;
}

int32_t loopback_tcpc(uint8_t sn, uint8_t* buf, uint8_t* destip, uint16_t destport)
{
   	int32_t ret; // return value for SOCK_ERRORs
   	uint16_t size = 0, sentsize=0;

   	static uint16_t any_port = 	50000;

   	switch(getSn_SR(sn))
   	{
   	   	case SOCK_ESTABLISHED :
   	      	if(getSn_IR(sn) & Sn_IR_CON)	// Socket n interrupt register mask; TCP CON interrupt = connection with peer is successful
   	     	{
				setSn_IR(sn, Sn_IR_CON);  // this interrupt should be write the bit cleared to '1'
   	     	}
   	
   	      	//////////////////////////////////////////////////////////////////////////////////////////////
   	      	// Data Transaction Parts; Handle the [data receive and send] process
   	      	//////////////////////////////////////////////////////////////////////////////////////////////
			if((size = getSn_RX_RSR(sn)) > 0) // Sn_RX_RSR: Socket n Received Size Register, Receiving data length
   	      	{
				if(size > DATA_BUF_SIZE) 
					size = DATA_BUF_SIZE; // DATA_BUF_SIZE means user defined buffer size (array)
				ret = recv(sn, buf, size); // Data Receive process (H/W Rx socket buffer -> User's buffer)
   	
				if(ret <= 0) 
					return ret; // If the received data length <= 0, receive failed and process end
				size = (uint16_t) ret;
				sentsize = 0;
   	
				// Data sentsize control
				while(size != sentsize)
				{
					ret = send(sn, buf+sentsize, size-sentsize); // Data send process (User's buffer -> Destination through H/W Tx socket buffer)
					if(ret < 0) // Send Error occurred (sent data length < 0)
					{
						close(sn); // socket close
						return ret;
					}
					sentsize += ret; // Don't care SOCKERR_BUSY, because it is zero.
				}
   	      	}
			//////////////////////////////////////////////////////////////////////////////////////////////
   	     	break;
   	
   	   case SOCK_CLOSE_WAIT :
   	      	if((ret=disconnect(sn)) != SOCK_OK) 
   	      		return ret;
			#ifdef __LOOPBACK_DEBUG__
   	      	printf("%d:Socket Closed\r\n", sn);
			#endif
   	      	break;
   	   case SOCK_INIT :
   	 	 	if( (ret = connect(sn, destip, destport)) != SOCK_OK) 
   	 	 		return ret;	//	Try to TCP connect to the TCP server (destination)
   	      	break;
   	   case SOCK_CLOSED:
   	 	  	close(sn);
   	 	  	if((ret=socket(sn, Sn_MR_TCP, any_port++, 0x00)) != sn)
   	 	  	{
   	      		if(any_port == 0xffff) 
   	      			any_port = 50000;
   	      		return ret; // TCP socket open with 'any_port' port number
   	     	} 
   	      	break;
   	   default:
   	      	break;
   	}
   	return 1;
}


int32_t loopback_udps(uint8_t sn, uint8_t* buf, uint16_t port)
{
   	int32_t  ret;
   	uint16_t size;//, sentsize;
   	uint8_t  destip[4];
   	uint16_t destport;

   	switch(getSn_SR(sn))
   	{
   	   	case SOCK_UDP :
   	      	if((size = getSn_RX_RSR(sn)) > 0)
   	      	{
   	      	   	if(size > DATA_BUF_SIZE) 
   	      	   		size = DATA_BUF_SIZE;
   	      	   	ret = recvfrom(sn, buf, size, destip, (uint16_t*)&destport);

				if(strstr((char *)buf,REQUEST_INFO) !=NULL)
				{
					#ifdef __LOOPBACK_DEBUG__
   	      			printf("\r\nloopback_udps buf = %s\r\n", buf);
					#endif
  	      	   		if(ret <= 0)
   	      	   		{
   	      	   		   	return ret;
   	      	   		}
      	   			destport = PORT_UDPS_REPLY;

					GSTECH_DEVICE_SETUP_MESSAGE_OUTPUT_PROCESS();
 					#ifdef __LOOPBACK_DEBUG__
     				printf("loopback_udps server port = %d\r\n", destport);
					printf("loopback_udps server ip: %3d.%3d.%3d.%3d\r\n", destip[0],destip[1],destip[2],destip[3]);
    	  			printf("loopback_udps out_Format length = %d\r\n", gstech_OutputCount);
    	  			printf("loopback_udps sizeof(Board_out_Format) = %d\r\n", sizeof(Board_out_Format));
	      			printf("\r\nloopback_udps out_Format Data .... \r\n");
	      			printf("%s\r\n", Board_out_Format);
 					#endif
           		
      	   			//while(sentsize != size)
      	   			{
	      			   	ret = sendto(sn, (BYTE *)Board_out_Format, gstech_OutputCount, destip, destport);
						#ifdef __LOOPBACK_DEBUG__
    	  				printf("loopback_udps send data length = %d\r\n", (WORD)ret);
						#endif
      	   			   	if(ret < 0)
      	   			   	{
							#ifdef __LOOPBACK_DEBUG__
      	   			   	   	printf("%d: sendto error. %ld\r\n",sn,ret);
							#endif
      	   			   	   	return ret;
      	   			   	}
      	   			   	//sentsize += ret; // Don't care SOCKERR_BUSY, because it is zero.
      	   			}
   	      	   	}
   	      	}
   	      	break;
   	   case SOCK_CLOSED:
			#ifdef __LOOPBACK_DEBUG__
   	      	printf("%d:SOCK_UDPS loopback_udps start\r\n",sn);
			#endif
   	      	if((ret = socket(sn, Sn_MR_UDP, port, 0x00)) != sn)
   	         	return ret;
			#ifdef __LOOPBACK_DEBUG__
   	      	printf("%d:Opened, SOCK_UDPS loopback_udps, port [%d]\r\n", sn, port);
			#endif
   	      	break;
   	   default :
   	      	break;
   	}
 
   	return 1;
}

int32_t loopback_udpc(uint8_t sn, uint8_t* buf, uint16_t port)
{
   	int32_t  ret;
   	uint16_t size;//, sentsize;
   	uint8_t  destip[4];
   	uint16_t destport;

   	switch(getSn_SR(sn))
   	{
   	   	case SOCK_UDP :        					//0x22
   	      	if((size = getSn_RX_RSR(sn)) > 0)
   	      	{
   	      	   	if(size > DATA_BUF_SIZE) 
   	      	   		size = DATA_BUF_SIZE;
   	      	   	ret = recvfrom(sn, buf, size, destip, (uint16_t*)&destport);

				if(strstr((char *)buf,REQUEST_SETUP) != NULL)
				{
					#ifdef __LOOPBACK_DEBUG__
   	      			printf("loopback_udpc buf = %s\r\n", buf);
					printf("loopback_udpc Receive ip: %3d.%3d.%3d.%3d\r\n", destip[0],destip[1],destip[2],destip[3]);
					#endif

  	      	   		if(ret <= 0)
   	      	   		{
						#ifdef __LOOPBACK_DEBUG__
   	      	   		   	printf("%d: recvfrom error. %ld\r\n",sn,ret);
						#endif
   	      	   		   	return ret;
   	      	   		}
  	      	   		close(SOCK_UDPS);
  	      	   		close(SOCK_UDPS_SETUP);
 
  	      	   		destport = PORT_UDPS_SETUP;
  	      	   		
  	      	   		if(GSTECH_DEVICE_SETUP_PARSE_UDP_TOPIC((char *)buf) == SUCCESSS)
  	      	   		{
 	      	   			EEPromFLAGSbits.BitWord = 0xFFFF;
					}

      	   			close(SOCK_MQTT);
					#ifdef __LOOPBACK_DEBUG__
   					printf("socket[SOCK_MQTT] close done ..........\r\n");
					#endif
      	   			GSTECH_NETWORK_SET_COMMON_PROCESS();
   	      	   		//BitDHCPSetDataSaveDone = _SET;
   	      	   	}
   	      	}
   	      	break;
   	   case SOCK_CLOSED:             			// 0x00
			#ifdef __LOOPBACK_DEBUG__
   	      	printf("%d:SOCK_UDPC_SETUP loopback_udpc start\r\n",sn);
			#endif
   	      	if((ret = socket(sn, Sn_MR_UDP, port, 0x00)) != sn)
   	         	return ret;
			#ifdef __LOOPBACK_DEBUG__
   	      	printf("%d:Opened, SOCK_UDPC_SETUP loopback_udpc, port [%d]\r\n", sn, port);
			#endif
   	      	break;
   	   default :
   	      	break;
   	}
 
   	return 1;
}
