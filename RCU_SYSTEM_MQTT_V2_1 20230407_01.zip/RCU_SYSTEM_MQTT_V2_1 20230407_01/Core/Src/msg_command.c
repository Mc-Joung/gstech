/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : msgcommand.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */
/* USER CODE END Header */
//****************************************************************************************************************************
//  I N C L U D E    F I L E S
//****************************************************************************************************************************
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "define.h"
#include "extern.h"
#include "msg_command.h"
#include "cJSON.h"
#include "MQTTClient.h"
#include "wizchip_conf.h"

//****************************************************************************************************************************
//  G L O B  A L    F U N C T I O N    P R O T O T Y P E S
//****************************************************************************************************************************
char* GSTECH_PARSE_COMMAND(char* msg,const char* type, char* value);

//****************************************************************************************************************************
//  E X T E R N A L     F U N C T I O N    P R O T O T Y P E S
//****************************************************************************************************************************

//****************************************************************************************************************************
//  L O C A L   D E F I N E D    P R O T O T Y P E S
//****************************************************************************************************************************
char Gstech_Temp[30];
char Gstech_Type[30];
char Relay_Index[30];
char Relay_Status[30];
char Operation_time[3];
char Board_password[30];

int TEMPIP[4];
BYTE GetCommandType = _MQTT_COMMAND_NONE;
BYTE Gstech_RelayIdx = _CLR;
BYTE Gstech_Status = _CLR;
WORD Gstech_OperationTime = _CLR;
WORD Gstech_Password = _CLR;
WORD Gstech_PasingLength = _CLR;

//****************************************************************************************************************************
//  L O C A L   D E F I N E D    P R O T O T Y P E S
//****************************************************************************************************************************
const WORD RELAY_CONTROL_MASK_TABLE[16] =
{
	_WBIT00, _WBIT01, _WBIT02, _WBIT03, _WBIT04, _WBIT05, _WBIT06, _WBIT07,
	_WBIT08, _WBIT09, _WBIT10, _WBIT11, _WBIT12, _WBIT13, _WBIT14, _WBIT15
};

//****************************************************************************************************************************
//  U S E R 	C O D E
//****************************************************************************************************************************

//****************************************************************************************************************************
//
// FUNCTION       : BYTE GSTECH_PARSE_COMMAND(BYTE RelayIndex)
//
// USAGE          : MQTT Message parsing Process
//
// INPUT        :   None
//
// USED			:   None
//				
// OUTPUT       :   None
//
//****************************************************************************************************************************
char* GSTECH_PARSE_COMMAND(char* msg,const char* type, char* value)
{ 
	char  *string; 
   	cJSON *root = cJSON_Parse(msg);
	 
	Gstech_PasingLength = _CLR;

	if(root != NULL)
	{	
      	string = cJSON_GetObjectItem(root,type)->valuestring;
		Gstech_PasingLength = strlen(string);
		#ifdef __MESSAGE_DEBUG__
      	//printf("string: %s\r\n",string);	
 	   	//printf("parse length: %d\r\n",Gstech_PasingLength);
		#endif
      	memset(value,0,strlen(value)); 
		memcpy(value,string,Gstech_PasingLength);
	   	cJSON_Delete(root); 
		#ifdef __MESSAGE_DEBUG__
 	   	//printf("parse: %s\r\n",value);
		#endif
	   	return value;
	}
	return NULL;
}

//****************************************************************************************************************************
//
// FUNCTION       : BYTE GSTECH_MQTT_RELAY_CONTROL_PROCESS(BYTE RelayIndex)
//
// USAGE          : MQTT Message Realy Control Process
//
// INPUT        :   None
//
// USED			:   None
//				
// OUTPUT       :   None
//
//****************************************************************************************************************************
void GSTECH_MQTT_RELAY_CONTROL_PROCESS(BYTE RelayIndex)
{
	switch(RelayIndex)
	{
		case 1: BitPort1Control ? RELAY_PORT_1_ON() : RELAY_PORT_1_OFF(); break;
		case 2: BitPort2Control ? RELAY_PORT_2_ON() : RELAY_PORT_2_OFF(); break;
		case 3: BitPort3Control ? RELAY_PORT_3_ON() : RELAY_PORT_3_OFF(); break;
		case 4: BitPort4Control ? RELAY_PORT_4_ON() : RELAY_PORT_4_OFF(); break;
		case 5: BitPort5Control ? RELAY_PORT_5_ON() : RELAY_PORT_5_OFF(); break;
		case 6: BitPort6Control ? RELAY_PORT_6_ON() : RELAY_PORT_6_OFF(); break;
		case 7: BitPort7Control ? RELAY_PORT_7_ON() : RELAY_PORT_7_OFF(); break;
		case 8: BitPort8Control ? RELAY_PORT_8_ON() : RELAY_PORT_8_OFF(); break;

		//case 1: if(BitPort1Control) {RELAY_PORT_1_ON();} else {RELAY_PORT_1_OFF();} break;
		//case 2: if(BitPort2Control) {RELAY_PORT_2_ON();} else {RELAY_PORT_2_OFF();} break;
		//case 3: if(BitPort3Control) {RELAY_PORT_3_ON();} else {RELAY_PORT_3_OFF();} break;
		//case 4: if(BitPort4Control) {RELAY_PORT_4_ON();} else {RELAY_PORT_4_OFF();} break;
		//case 5: if(BitPort5Control) {RELAY_PORT_5_ON();} else {RELAY_PORT_5_OFF();} break;
		//case 6: if(BitPort6Control) {RELAY_PORT_6_ON();} else {RELAY_PORT_6_OFF();} break;
		//case 7: if(BitPort7Control) {RELAY_PORT_7_ON();} else {RELAY_PORT_7_OFF();} break;
		//case 8: if(BitPort8Control) {RELAY_PORT_8_ON();} else {RELAY_PORT_8_OFF();} break;

		//case  9: break;
		//case 10: break;
		//case 11: break;
		//case 12: break;
		//case 13: break;
		//case 14: break;
		//case 15: break;
		//case 16: break;
        //
		//case 17: break;
		//case 18: break;
		//case 19: break;
		//case 20: break;
		//case 21: break;
		//case 22: break;
		//case 23: break;
		//case 24: break;
        //
		//case 25: break;
		//case 26: break;
		//case 27: break;
		//case 28: break;
		//case 29: break;
		//case 30: break;
		//case 31: break;
		//case 32: break;

		default: break;
	}
}

//****************************************************************************************************************************
//
// FUNCTION       : int GSTECH_MQTT_PARSE_TOPIC_RELAY_ID(char* msg)
//
// USAGE          : MQTT Message parsing Relay ID Process
//
// INPUT        :   Message
//
// USED			:   None
//				
// OUTPUT       :   Check Success or Failure
//
//****************************************************************************************************************************
int GSTECH_MQTT_PARSE_TOPIC_RELAY_ID(char* msg)	
{

	//============================================================================
	if(strstr(msg,GSTECH_ID)!=NULL)
	{
	   	GSTECH_PARSE_COMMAND(msg,GSTECH_ID,Relay_Index);

		Gstech_RelayIdx = atoi(Relay_Index);

		if(Gstech_RelayIdx > _MAX_RELAY_COUNT)
 			return FAILURE;		

		#ifdef __MESSAGE_DEBUG__
		printf("Relay_Index = [%d]\r\n", Gstech_RelayIdx);
		#endif
	}		
	else
	{
		#ifdef __MESSAGE_DEBUG__
		printf("Gstech_RelayIdx Error .....\r\n");
		#endif
		return FAILURE;		
	}

	return SUCCESSS;
}

//****************************************************************************************************************************
//
// FUNCTION       : int GSTECH_MQTT_PARSE_TOPIC_STATUS_COMMAND(char* msg)
//
// USAGE          : MQTT Message parsing Relay Control Command Process
//
// INPUT        :   Message
//
// USED			:   None
//				
// OUTPUT       :   Check Success or Failure
//
//****************************************************************************************************************************
int GSTECH_MQTT_PARSE_TOPIC_STATUS_COMMAND(char* msg)	
{
	//============================================================================
	PORTCTRLEn1FLAGSbits.BitWord = _CLR;
	PORTCTRLEn2FLAGSbits.BitWord = _CLR;

	if(strstr(msg,STATUS)!=NULL)
	{
	   	GSTECH_PARSE_COMMAND(msg,STATUS,Relay_Status);

		Gstech_Status = atoi(Relay_Status);

		if(Gstech_RelayIdx <= _MAX_RELAY_COUNT)
		{
			if(Gstech_RelayIdx)	// Relay ���� 1 ~ 32
			{
				//-------------------------------------------------------------------
				// Enable Relay Control
				if(Gstech_RelayIdx <= 16)
					PORTCTRLEn1FLAGSbits.BitWord |= RELAY_CONTROL_MASK_TABLE[Gstech_RelayIdx - 1];
				else
					PORTCTRL2FLAGSbits.BitWord |= RELAY_CONTROL_MASK_TABLE[Gstech_RelayIdx - 1];

				//-------------------------------------------------------------------
				if(strcmp(Relay_Status,"ON") == 0)
				{
					#ifdef __MESSAGE_DEBUG__
					printf("Relay [ON] status\r\n");
					#endif
					if(Gstech_RelayIdx <= 16)
						PORTCTRL1FLAGSbits.BitWord |= RELAY_CONTROL_MASK_TABLE[Gstech_RelayIdx - 1];
					else
						PORTCTRL2FLAGSbits.BitWord |= RELAY_CONTROL_MASK_TABLE[Gstech_RelayIdx - 1];
				}

				//-------------------------------------------------------------------
				if(strcmp(Relay_Status,"OFF") == 0)
				{
					#ifdef __MESSAGE_DEBUG__
					printf("Relay [OFF] status\r\n");
					#endif
					if(Gstech_RelayIdx <= 16)
						PORTCTRL1FLAGSbits.BitWord &= (~RELAY_CONTROL_MASK_TABLE[Gstech_RelayIdx - 1]);
					else
						PORTCTRL2FLAGSbits.BitWord &= (~RELAY_CONTROL_MASK_TABLE[Gstech_RelayIdx - 1]);
				}
			}
			else if(GetCommandType == _MQTT_COMMAND_ALL_ON_OFF)	// Relay 0 : All Relay ����
			{
				//-------------------------------------------------------------------
				// Enable Relay Control
				PORTCTRLEn1FLAGSbits.BitWord = 0xFFFF;
				PORTCTRLEn2FLAGSbits.BitWord = 0xFFFF;

				//-------------------------------------------------------------------
				if(strcmp(Relay_Status,"ON") == 0)
				{
					#ifdef __MESSAGE_DEBUG__
					printf("Relay All [ON] status\r\n");
					#endif
					PORTCTRL1FLAGSbits.BitWord |= 0xFFFF;
					PORTCTRL2FLAGSbits.BitWord |= 0xFFFF;
				}

				//-------------------------------------------------------------------
				if(strcmp(Relay_Status,"OFF") == 0)
				{
					#ifdef __MESSAGE_DEBUG__
					printf("Relay All [OFF] status\r\n");
					#endif
					PORTCTRL1FLAGSbits.BitWord = 0x0000;
					PORTCTRL2FLAGSbits.BitWord = 0x0000;
				}
			}
		}

		#ifdef __MESSAGE_DEBUG__
		printf("Relay_Status = [%s]\r\n", Relay_Status);
		#endif
	}		
	else
	{
		#ifdef __MESSAGE_DEBUG__
		printf("Gstech_RelayStatus Error 3 .....\r\n");
		#endif
		return FAILURE;		
	}

	return SUCCESSS;
}

//****************************************************************************************************************************
//
// FUNCTION       : int GSTECH_MQTT_PARSE_TOPIC_RELAY_DELAY_TIME(char* msg)
//
// USAGE          : MQTT Message parsing Relay Control Delay Time Process
//
// INPUT        :   Message
//
// USED			:   None
//				
// OUTPUT       :   Check Success or Failure
//
//****************************************************************************************************************************
int GSTECH_MQTT_PARSE_TOPIC_RELAY_DELAY_TIME(char* msg)	
{
	WORD TempTime;
	BYTE TempCount;

	//============================================================================
	if(strstr(msg,OPERATION_TIME)!=NULL)
	{
	   	GSTECH_PARSE_COMMAND(msg,OPERATION_TIME,Operation_time);

		TempTime = atoi(Operation_time);

		if((Gstech_RelayIdx == 0) && (GetCommandType == _MQTT_COMMAND_ALL_ON_OFF))
		{
			gstech_RelayTimeCount[_SET] = _CLR;
			for(TempCount = 2; TempCount <= _MAX_RELAY_COUNT; TempCount++)
				gstech_RelayTimeCount[TempCount] = (TempCount - 1) * TempTime;

			#ifdef __MESSAGE_DEBUG__
			printf("ALL_ON_OFF RelayIdx All time Set = [%d Second]\r\n",TempTime);
			//printf("Set1 = [%ld Second]\r\n",gstech_RelayTimeCount[1]);
			//printf("Set2 = [%ld Second]\r\n",gstech_RelayTimeCount[2]);
			//printf("Set3 = [%ld Second]\r\n",gstech_RelayTimeCount[3]);
			//printf("Set4 = [%ld Second]\r\n",gstech_RelayTimeCount[4]);
			#endif
		}
		else if((Gstech_RelayIdx <= _MAX_RELAY_COUNT) && (GetCommandType == _MQTT_COMMAND_ON_OFF))
		{
			gstech_RelayTimeCount[Gstech_RelayIdx] = _CLR;
		}
		else if((Gstech_RelayIdx <= _MAX_RELAY_COUNT) && (GetCommandType == _MQTT_COMMAND_DELAY))
		{
			gstech_RelayTimeCount[Gstech_RelayIdx] = TempTime;
		}
		else if((Gstech_RelayIdx <= _MAX_RELAY_COUNT) && (GetCommandType == _MQTT_COMMAND_RESET))
		{
			gstech_RelayTimeCount[Gstech_RelayIdx] = TempTime;
		}
		else if((Gstech_RelayIdx == _CLR) && ((GetCommandType == _MQTT_COMMAND_UPDATE)||(GetCommandType == _MQTT_COMMAND_REBOOT)))
		{
			Gstech_OperationTime = TempTime;
		}

		#ifdef __MESSAGE_DEBUG__
		printf("RESET RelayIdx time[%d] = [%ld Second]\r\n", Gstech_RelayIdx, gstech_RelayTimeCount[Gstech_RelayIdx]);
		printf("Relay Operation_time = [%s]\r\n", Operation_time);
		#endif
	}		
	else
	{
		#ifdef __MESSAGE_DEBUG__
		printf("Gstech_OperationTime Error 2 .....\r\n");
		#endif
		return FAILURE;		
	}

	return SUCCESSS;
}

//****************************************************************************************************************************
//
// FUNCTION       : int GSTECH_MQTT_PARSE_TOPIC_PASSWORD(char* msg)
//
// USAGE          : MQTT Message parsing Password Process
//
// INPUT        :   Message
//
// USED			:   None
//				
// OUTPUT       :   Check Success or Failure
//
//****************************************************************************************************************************
int GSTECH_MQTT_PARSE_TOPIC_PASSWORD(char* msg)	
{
	//============================================================================
	if(strstr(msg,GSTECH_PASSWORD)!=NULL)
	{
	   	GSTECH_PARSE_COMMAND(msg,GSTECH_PASSWORD,Board_password);

		#ifdef __MESSAGE_DEBUG__
		printf("Board_password = [%s]\r\n", Board_password);
		#endif
		Gstech_Password = atoi(Board_password);
	}		
	else
	{
		#ifdef __MESSAGE_DEBUG__
		printf("Board_password Error 2 .....\r\n");
		#endif
		return FAILURE;		
	}

	return SUCCESSS;
}

//****************************************************************************************************************************
//
// FUNCTION       : int GSTECH_MQTT_PARSE_UDP_TOPIC(char* msg)
//
// USAGE          : MQTT Message parsing Topic Command Process
//
// INPUT        :   Message
//
// USED			:   None
//				
// OUTPUT       :   Check Success or Failure
//
//****************************************************************************************************************************
int GSTECH_MQTT_PARSE_UDP_TOPIC(char* msg)
{
	BYTE TempCount;
	BYTE TempCommand = _CLR;

	//if(strstr(ser_cmd,GSTECH_TYPE) != NULL)
	//{
	//	GSTECH_PARSE_COMMAND(ser_cmd,GSTECH_TYPE, (char*) Gstech_Type);
	//	if(strcmp(Gstech_Type,"UPDATE") == 0)
	//		gstech_MqttSendStartTimeCount = 0;
	//}
    //
	////============================================================================
	//if(gstech_MqttSendStartTimeCount)
	//{
	//	#ifdef __MESSAGE_DEBUG__
	//	printf("MQTT Command Action Doing .....\r\n");
	//	#endif
	//	return FAILURE;		
	//}

	BitMqttResetCommandSetDone = _CLR;
	Gstech_ResetRelayIdx = _CLR;
 	BitJumpBootCodeStart = _CLR;
	GetCommandType = _MQTT_COMMAND_NONE;

	//============================================================================
	if(strstr(msg,GSTECH_TYPE)!=NULL)//&&strstr(msg,OPERATION)==NULL)
	{
	   	GSTECH_PARSE_COMMAND(msg,GSTECH_TYPE, (char*) Gstech_Type);
		#ifdef __MESSAGE_DEBUG__
		printf("Gstech_Type = %s\r\n",Gstech_Type);
		#endif

		if(strcmp(Gstech_Type,GSTECH_ON_OFF) == 0)
		{
			#ifdef __MESSAGE_DEBUG__
			printf("tyep:ON/OFF.....\r\n");
			#endif
			GetCommandType = _MQTT_COMMAND_ON_OFF;
		
			if((GSTECH_MQTT_PARSE_TOPIC_RELAY_ID(msg)) == FAILURE)
				return FAILURE;
			if(Gstech_RelayIdx == 0)
				return FAILURE;
			if((GSTECH_MQTT_PARSE_TOPIC_STATUS_COMMAND(msg)) == FAILURE)
				return FAILURE;
			if((GSTECH_MQTT_PARSE_TOPIC_RELAY_DELAY_TIME(msg)) == FAILURE)
				return FAILURE;
			if((GSTECH_MQTT_PARSE_TOPIC_PASSWORD(msg)) == FAILURE)
				return FAILURE;
		}
		else if(strcmp(Gstech_Type,GSTECH_DELAY) == 0)
		{
			#ifdef __MESSAGE_DEBUG__
			printf("tyep:DELAY.....\r\n");
			#endif
			GetCommandType = _MQTT_COMMAND_DELAY;
		
			if((GSTECH_MQTT_PARSE_TOPIC_RELAY_ID(msg)) == FAILURE)
				return FAILURE;
			if(Gstech_RelayIdx == 0)
				return FAILURE;
			if((GSTECH_MQTT_PARSE_TOPIC_STATUS_COMMAND(msg)) == FAILURE)
				return FAILURE;
			if((GSTECH_MQTT_PARSE_TOPIC_RELAY_DELAY_TIME(msg)) == FAILURE)
				return FAILURE;
			if((GSTECH_MQTT_PARSE_TOPIC_PASSWORD(msg)) == FAILURE)
				return FAILURE;
		}
		//else if(strcmp(Gstech_Type,GSTECH_JOGGING) == 0)
		//{
		//	#ifdef __MESSAGE_DEBUG__
		//	printf("tyep:JOGGING.....\r\n");
		//	#endif
		//	GetCommandType = _MQTT_COMMAND_JOGGING;
 		//	return FAILURE;		
		//}
		else if(strcmp(Gstech_Type,GSTECH_ALL_ON_OFF) == 0)
		{
			#ifdef __MESSAGE_DEBUG__
			printf("tyep:ALL_ON/OFF.....\r\n");
			#endif
			GetCommandType = _MQTT_COMMAND_ALL_ON_OFF;
		
			if((GSTECH_MQTT_PARSE_TOPIC_RELAY_ID(msg)) == FAILURE)
				return FAILURE;
			if(Gstech_RelayIdx != 0)
				return FAILURE;
			if((GSTECH_MQTT_PARSE_TOPIC_STATUS_COMMAND(msg)) == FAILURE)
				return FAILURE;
			if((GSTECH_MQTT_PARSE_TOPIC_RELAY_DELAY_TIME(msg)) == FAILURE)
				return FAILURE;
			if((GSTECH_MQTT_PARSE_TOPIC_PASSWORD(msg)) == FAILURE)
				return FAILURE;
		}
		else if(strcmp(Gstech_Type,GSTECH_RESET) == 0)
		{
			#ifdef __MESSAGE_DEBUG__
			printf("tyep:RESET.....\r\n");
			#endif
			GetCommandType = _MQTT_COMMAND_RESET;

			//---------------------------------------------------------------------------------------
			if((GSTECH_MQTT_PARSE_TOPIC_RELAY_ID(msg)) == FAILURE)
				return FAILURE;

			//---------------------------------------------------------------------------------------
			//if((GSTECH_MQTT_PARSE_TOPIC_STATUS_COMMAND(msg)) == FAILURE)
			//	return FAILURE;
			//---------------------------------------------------------------------------------------
			//if((GSTECH_MQTT_PARSE_TOPIC_RELAY_DELAY_TIME(msg)) == FAILURE)
			//	return FAILURE;
			//if(Gstech_OperationTime != 0)
			//	return FAILURE;

			//---------------------------------------------------------------------------------------
			if((GSTECH_MQTT_PARSE_TOPIC_PASSWORD(msg)) == FAILURE)
				return FAILURE;
			if(Gstech_Password != 0)
				return FAILURE;
		}
		else if(strcmp(Gstech_Type,GSTECH_UPDATE) == 0)
		{
 			//TempCommand = 0xFF;
			GetCommandType = _MQTT_COMMAND_UPDATE;

			//---------------------------------------------------------------------------------------
			if((GSTECH_MQTT_PARSE_TOPIC_RELAY_ID(msg)) == FAILURE)
				return FAILURE;
			if(Gstech_RelayIdx != 0)
				return FAILURE;

			//---------------------------------------------------------------------------------------
			if((GSTECH_MQTT_PARSE_TOPIC_STATUS_COMMAND(msg)) == FAILURE)
				return FAILURE;
			if(Gstech_Status != 0)
				return FAILURE;

			//---------------------------------------------------------------------------------------
			if((GSTECH_MQTT_PARSE_TOPIC_RELAY_DELAY_TIME(msg)) == FAILURE)
				return FAILURE;
			if(Gstech_OperationTime != 0)
				return FAILURE;

			//---------------------------------------------------------------------------------------
			if((GSTECH_MQTT_PARSE_TOPIC_PASSWORD(msg)) == FAILURE)
				return FAILURE;
			if(Gstech_Password != 0)
				return FAILURE;

			//---------------------------------------------------------------------------------------
			gstech_MqttSendStartTimeCount = _CLR;	// Message Send Stop

			//gstech_FW_Version = _SET;	//(BYTE)(Relay_Status[0] - 0x30);
			gstech_Read_FW_Version = _SET;
			#ifdef __MESSAGE_DEBUG__
			printf("Application Update Command Start ..............\r\n");
			#endif
			GSTECH_FLASH_SAVE_ALL();

			#ifdef __MESSAGE_DEBUG__
			printf("UPDATE Changed F/W Version[v%d.%d] Start .....\r\n", gstech_Read_FW_Version/10, gstech_Read_FW_Version%10);
			printf("UPDATE DEFAULT_VERSION[v%d.%d] Start .....\r\n", DEFAULT_VERSION/10, DEFAULT_VERSION%10);
			#endif

			BitJumpBootCodeStart = _SET;
 			//GSTECH_BOOT_CODE_JUMP();
			return SUCCESSS;
		}
		else if(strcmp(Gstech_Type,GSTECH_REBOOT) == 0)
		{
			GetCommandType = _MQTT_COMMAND_REBOOT;

			//---------------------------------------------------------------------------------------
			if((GSTECH_MQTT_PARSE_TOPIC_RELAY_ID(msg)) == FAILURE)
				return FAILURE;
			if(Gstech_RelayIdx != 0)
				return FAILURE;

			//---------------------------------------------------------------------------------------
			if((GSTECH_MQTT_PARSE_TOPIC_STATUS_COMMAND(msg)) == FAILURE)
				return FAILURE;
			if(Gstech_Status != 0)
				return FAILURE;

			//---------------------------------------------------------------------------------------
			if((GSTECH_MQTT_PARSE_TOPIC_RELAY_DELAY_TIME(msg)) == FAILURE)
				return FAILURE;
			if(Gstech_OperationTime != 0)
				return FAILURE;

			//---------------------------------------------------------------------------------------
			if((GSTECH_MQTT_PARSE_TOPIC_PASSWORD(msg)) == FAILURE)
				return FAILURE;
			if(Gstech_Password != 0)
				return FAILURE;

			//---------------------------------------------------------------------------------------
			#ifdef __MESSAGE_DEBUG__
			printf("REBOOT gstech_FW_Version[v%d.%d] Start .....\r\n", gstech_Read_FW_Version/10, gstech_Read_FW_Version%10);
			printf("REBOOT DEFAULT_VERSION[v%d.%d] Start .....\r\n", DEFAULT_VERSION/10, DEFAULT_VERSION%10);
			#endif

 			BitJumpBootCodeStart = _SET;
 			//GSTECH_BOOT_CODE_JUMP();
			return SUCCESSS;
		}
		else
		{
			#ifdef __MESSAGE_DEBUG__
			printf("Gstech_Type Error 1 .....\r\n");
			#endif
			return FAILURE;		
		}
	}
	else
	{
		#ifdef __MESSAGE_DEBUG__
		printf("Gstech_Type Error 2 .....\r\n");
		#endif
		return FAILURE;		
	}

	//============================================================================
	if(TempCommand == _CLR)
	{
   		BitMqttSendDataStart = _CLR;
		gstech_MqttSendStartTimeCount = _CLR;

		if(GetCommandType == _MQTT_COMMAND_ALL_ON_OFF)
		{
			if(gstech_RelayTimeCount[_MAX_RELAY_COUNT] == _CLR)
			{
				for(TempCount = _SET; TempCount <= _MAX_RELAY_COUNT; TempCount++)
					GSTECH_MQTT_RELAY_CONTROL_PROCESS(TempCount);

				BitMqttSendDataStart = _SET;
			}
			else
			{
		    	if(BitPort1Control)
		    	{
		    		RELAY_PORT_1_ON();
		    	}
		    	else //if(!BitPort1Control)
		    	{
		    		RELAY_PORT_1_OFF();
		    	}
				gstech_MqttSendStartTimeCount = gstech_RelayTimeCount[_MAX_RELAY_COUNT];
			}

			Bit1000mS = _CLR;
			gstech_Timer1000mSec = _CLR; 
		}
		else if(GetCommandType == _MQTT_COMMAND_RESET)
		{
			#ifdef __MESSAGE_DEBUG__
			printf("RESET Relay[%d] On .....\r\n", Gstech_RelayIdx);
			#endif
			#if __RELAY_DEFAULT_HIGH == _SET
			{
				if(Gstech_RelayIdx <= 16)
					PORTCTRL1FLAGSbits.BitWord &= (~RELAY_CONTROL_MASK_TABLE[Gstech_RelayIdx - 1]);
				else
					PORTCTRL2FLAGSbits.BitWord &= (~RELAY_CONTROL_MASK_TABLE[Gstech_RelayIdx - 1]);
            	
				//for(TempCount = _SET; TempCount <= _MAX_RELAY_COUNT; TempCount++)
					GSTECH_MQTT_RELAY_CONTROL_PROCESS(Gstech_RelayIdx);
            	
				if(Gstech_RelayIdx <= 16)
					PORTCTRL1FLAGSbits.BitWord |= RELAY_CONTROL_MASK_TABLE[Gstech_RelayIdx - 1];
				else
					PORTCTRL2FLAGSbits.BitWord |= RELAY_CONTROL_MASK_TABLE[Gstech_RelayIdx - 1];
			}
			#else
			{
				if(Gstech_RelayIdx <= 16)
					PORTCTRL1FLAGSbits.BitWord |= RELAY_CONTROL_MASK_TABLE[Gstech_RelayIdx - 1];
				else
					PORTCTRL2FLAGSbits.BitWord |= RELAY_CONTROL_MASK_TABLE[Gstech_RelayIdx - 1];

				//for(TempCount = _SET; TempCount <= _MAX_RELAY_COUNT; TempCount++)
					GSTECH_MQTT_RELAY_CONTROL_PROCESS(Gstech_RelayIdx);

				if(Gstech_RelayIdx <= 16)
					PORTCTRL1FLAGSbits.BitWord &= (~RELAY_CONTROL_MASK_TABLE[Gstech_RelayIdx - 1]);
				else
					PORTCTRL2FLAGSbits.BitWord &= (~RELAY_CONTROL_MASK_TABLE[Gstech_RelayIdx - 1]);
			}
			#endif

			BitMqttResetCommandSetDone = _SET;
			Gstech_ResetRelayIdx = Gstech_RelayIdx;

			Bit500mS = _CLR; 
			gstech_Timer500mSec = _CLR;
		}
		else
		{
			if(gstech_RelayTimeCount[Gstech_RelayIdx] == _CLR)
				GSTECH_MQTT_RELAY_CONTROL_PROCESS(Gstech_RelayIdx);

			if(gstech_RelayTimeCount[Gstech_RelayIdx] > _CLR)
				gstech_MqttSendStartTimeCount = gstech_RelayTimeCount[Gstech_RelayIdx];
			else
				BitMqttSendDataStart = _SET;
		}

		#ifdef __MESSAGE_DEBUG__
		printf("BitMqttSendDataStart[%d]\r\n", BitMqttSendDataStart);
		printf("gstech_MqttSendStartTimeCount[%ld]\r\n", gstech_MqttSendStartTimeCount);
		#endif
	}
	//else if(TempCommand == 0xFF)
	//{
	//	if((Gstech_RelayIdx == 0) &&
	//	   (Relay_Status[0] == 0x30) &&
	//	   (Operation_time[0] == 0x30) &&
	//	   (Board_password[0] == 0x30))
	//	{
 	//		gstech_FW_Version = 0x01;	//(BYTE)(Relay_Status[0] - 0x30);
 	//		EEP_WRITE_FIRMWARE_VERSION(gstech_FW_Version);
 	//		BitJumpBootCodeStart = _SET;
	//		#ifdef __MESSAGE_DEBUG__
	//		printf("gstech_FW_Version[v%2d] Update Start .....\r\n", gstech_FW_Version);
	//		#endif
 	//	}
	//}		

	return SUCCESSS;
}

//****************************************************************************************************************************
//
// FUNCTION       : int GSTECH_DEVICE_SETUP_PARSE_UDP_TOPIC(char* msg)
//
// USAGE          : Device Setup Message parsing Topic Command Process
//
// INPUT        :   Message
//
// USED			:   None
//				
// OUTPUT       :   Check Success or Failure
//
//****************************************************************************************************************************
int GSTECH_DEVICE_SETUP_PARSE_UDP_TOPIC(char* msg)                                                        
{                                                                                             
	char TempStringBF[30];
	BYTE TempBF;
	WORD Temp16BF;

	if(strstr(msg, GSTECH_DEVICE_ID)!=NULL)                                                   
	{                                                                                         
	   	//GSTECH_PARSE_COMMAND(msg,GSTECH_DEVICE_ID, (char*) Gstech_Temp);                             
        //                                                                                      
		//if(gstech_MacAddID != atoi(Gstech_Temp))        // ���ڿ��� ������ ��ȯ�Ͽ� num1�� �Ҵ�
		//{   
		//	#ifdef __MESSAGE_DEBUG__
 		//	printf("gstech_MacAddID = %d\r\n",gstech_MacAddID);                                   
		//	#endif
		//}

		#ifdef __MESSAGE_DEBUG__
		printf("gstech_MacAddID = %02X%02X%02X\r\n\r\n",gstech_Device_MAC[3],gstech_Device_MAC[4],gstech_Device_MAC[5]);
 		//printf("gstech_MacAddID = %d\r\n",gstech_MacAddID);                                   
		#endif
	}                                                                                         
	else                                                                                      
	{                                                                                         
		#ifdef __MESSAGE_DEBUG__
		printf("SETUP Device Id Error .....\r\n");                                            
		#endif
		return FAILURE;		                                                                          
	}                                                                                         
                                                                                              
	//=============================================================================================
	if(strstr(msg, GSTECH_DHCP)!=NULL)                                                        
	{                                                                                         
	   	GSTECH_PARSE_COMMAND(msg,GSTECH_DHCP, (char*) Gstech_Temp);                                  
                                                                                              
		if(strcmp(Gstech_Temp,"True") == 0)
			TempBF = NETINFO_DHCP;
		else if(strcmp(Gstech_Temp,"False") == 0)                                                                                              
			TempBF = NETINFO_STATIC;
		else                                                                                      
		{                                                                                         
			#ifdef __MESSAGE_DEBUG__
			printf("SETUP Device DHCP Error .....\r\n");                                          
			#endif
			return FAILURE;		                                                                          
		}                                                                                         

		if(gstech_Device_DHCP != TempBF)
		{
			GetCommandType = _MQTT_COMMAND_REBOOT;
 			BitJumpBootCodeStart = _SET;
		}

		gstech_Device_DHCP = TempBF;

		#ifdef __MESSAGE_DEBUG__
		if(gstech_Device_DHCP == NETINFO_DHCP)
			printf("gstech_Device_DHCP - NETINFO_DHCP\r\n");                             
		else
			printf("gstech_Device_DHCP - NETINFO_STATIC\r\n");                             
		#endif
	}                                                                                         
	else                                                                                      
	{                                                                                         
		#ifdef __MESSAGE_DEBUG__
		printf("SETUP Device DHCP Error .....\r\n");                                          
		#endif
		return FAILURE;		                                                                          
	}                                                                                         
                                                                                              
	//=============================================================================================
	if(strstr(msg, GSTECH_IP)!=NULL)                                                          
	{                                                                                         
	   	GSTECH_PARSE_COMMAND(msg,GSTECH_IP, (char*) Gstech_Temp);                                    
                                                                                              
		sscanf(Gstech_Temp, "%d.%d.%d.%d", &TEMPIP[0],&TEMPIP[1],&TEMPIP[2],&TEMPIP[3]);      

		if((gstech_Device_IP[0] != (BYTE)TEMPIP[0]) ||
		   (gstech_Device_IP[1] != (BYTE)TEMPIP[1]) ||
		   (gstech_Device_IP[2] != (BYTE)TEMPIP[2]) ||
		   (gstech_Device_IP[3] != (BYTE)TEMPIP[3]))
		{
			GetCommandType = _MQTT_COMMAND_REBOOT;
 			BitJumpBootCodeStart = _SET;
		}

		gstech_Device_IP[0]= (BYTE)(TEMPIP[0]);                                               
		gstech_Device_IP[1]= (BYTE)(TEMPIP[1]);                                               
		gstech_Device_IP[2]= (BYTE)(TEMPIP[2]);                                               
		gstech_Device_IP[3]= (BYTE)(TEMPIP[3]);                                               

		#ifdef __MESSAGE_DEBUG__
		printf("gstech_Device_IP[0] = %d\r\n",gstech_Device_IP[0]);                           
		printf("gstech_Device_IP[1] = %d\r\n",gstech_Device_IP[1]);                           
		printf("gstech_Device_IP[2] = %d\r\n",gstech_Device_IP[2]);                           
		printf("gstech_Device_IP[3] = %d\r\n",gstech_Device_IP[3]);                           
 		#endif
	}                                                                                         
	else                                                                                      
	{                                                                                         
		#ifdef __MESSAGE_DEBUG__
		printf("SETUP Device IP Error .....\r\n");                                            
 		#endif
		return FAILURE;		                                                                          
	}                                                                                         
                                                                                              
	//=============================================================================================
	if(strstr(msg, GSTECH_SUBNET)!=NULL)                                                      
	{                                                                                         
	   	GSTECH_PARSE_COMMAND(msg,GSTECH_SUBNET, (char*) Gstech_Temp);                                
                                                                                              
		sscanf(Gstech_Temp, "%d.%d.%d.%d", &TEMPIP[0],&TEMPIP[1],&TEMPIP[2],&TEMPIP[3]);      

		if((gstech_Device_SN[0] != (BYTE)TEMPIP[0]) ||
		   (gstech_Device_SN[1] != (BYTE)TEMPIP[1]) ||
		   (gstech_Device_SN[2] != (BYTE)TEMPIP[2]) ||
		   (gstech_Device_SN[3] != (BYTE)TEMPIP[3]))
		{
			GetCommandType = _MQTT_COMMAND_REBOOT;
 			BitJumpBootCodeStart = _SET;
		}

		gstech_Device_SN[0]= (BYTE)(TEMPIP[0]);                                               
		gstech_Device_SN[1]= (BYTE)(TEMPIP[1]);                                               
		gstech_Device_SN[2]= (BYTE)(TEMPIP[2]);                                               
		gstech_Device_SN[3]= (BYTE)(TEMPIP[3]);                                               

		#ifdef __MESSAGE_DEBUG__
		printf("gstech_Device_SN[0] = %d\r\n",gstech_Device_SN[0]);                           
		printf("gstech_Device_SN[1] = %d\r\n",gstech_Device_SN[1]);                           
		printf("gstech_Device_SN[2] = %d\r\n",gstech_Device_SN[2]);                           
		printf("gstech_Device_SN[3] = %d\r\n",gstech_Device_SN[3]);                           
 		#endif
 	}                                                                                         
	else                                                                                      
	{                                                                                         
		#ifdef __MESSAGE_DEBUG__
		printf("SETUP subnet Error .....\r\n");                                               
		#endif
		return FAILURE;		                                                                          
	}                                                                                         
                                                                                              
	//=============================================================================================
	if(strstr(msg, GSTECH_GATEWAY)!=NULL)                                                     
	{                                                                                         
	   	GSTECH_PARSE_COMMAND(msg,GSTECH_GATEWAY, (char*) Gstech_Temp);                               
                                                                                              
		sscanf(Gstech_Temp, "%d.%d.%d.%d", &TEMPIP[0],&TEMPIP[1],&TEMPIP[2],&TEMPIP[3]);      

		if((gstech_Device_GW[0] != (BYTE)TEMPIP[0]) ||
		   (gstech_Device_GW[1] != (BYTE)TEMPIP[1]) ||
		   (gstech_Device_GW[2] != (BYTE)TEMPIP[2]) ||
		   (gstech_Device_GW[3] != (BYTE)TEMPIP[3]))
		{
			GetCommandType = _MQTT_COMMAND_REBOOT;
 			BitJumpBootCodeStart = _SET;
		}

		gstech_Device_GW[0]= (BYTE)(TEMPIP[0]);                                               
		gstech_Device_GW[1]= (BYTE)(TEMPIP[1]);                                               
		gstech_Device_GW[2]= (BYTE)(TEMPIP[2]);                                               
		gstech_Device_GW[3]= (BYTE)(TEMPIP[3]);                                               

		#ifdef __MESSAGE_DEBUG__
		printf("gstech_Device_GW[0] = %d\r\n",gstech_Device_GW[0]);                           
		printf("gstech_Device_GW[1] = %d\r\n",gstech_Device_GW[1]);                           
		printf("gstech_Device_GW[2] = %d\r\n",gstech_Device_GW[2]);                           
		printf("gstech_Device_GW[3] = %d\r\n",gstech_Device_GW[3]);                           
		#endif
	}                                                                                         
	else                                                                                      
	{                                                                                         
		#ifdef __MESSAGE_DEBUG__
		printf("SETUP gateway Error .....\r\n");                                              
		#endif
		return FAILURE;		                                                                          
	}                                                                                         
                                                                                              
	//=============================================================================================
	if(strstr(msg, GSTECH_MQTT_IP)!=NULL)                                                     
	{                                                                                         
	   	GSTECH_PARSE_COMMAND(msg,GSTECH_MQTT_IP, (char*) Gstech_Temp);                               
                                                                                              
		sscanf(Gstech_Temp, "%d.%d.%d.%d", &TEMPIP[0],&TEMPIP[1],&TEMPIP[2],&TEMPIP[3]);      

		if((gstech_Mqtt_IP[0] != (BYTE)TEMPIP[0]) ||
		   (gstech_Mqtt_IP[1] != (BYTE)TEMPIP[1]) ||
		   (gstech_Mqtt_IP[2] != (BYTE)TEMPIP[2]) ||
		   (gstech_Mqtt_IP[3] != (BYTE)TEMPIP[3]))
		{
			GetCommandType = _MQTT_COMMAND_REBOOT;
 			BitJumpBootCodeStart = _SET;
		}

		gstech_Mqtt_IP[0]= (BYTE)(TEMPIP[0]);                                                 
		gstech_Mqtt_IP[1]= (BYTE)(TEMPIP[1]);                                                 
		gstech_Mqtt_IP[2]= (BYTE)(TEMPIP[2]);                                                 
		gstech_Mqtt_IP[3]= (BYTE)(TEMPIP[3]);                                                 

		#ifdef __MESSAGE_DEBUG__
		printf("gstech_Mqtt_IP[0] = %d\r\n",gstech_Mqtt_IP[0]);                               
		printf("gstech_Mqtt_IP[1] = %d\r\n",gstech_Mqtt_IP[1]);                               
		printf("gstech_Mqtt_IP[2] = %d\r\n",gstech_Mqtt_IP[2]);                               
		printf("gstech_Mqtt_IP[3] = %d\r\n",gstech_Mqtt_IP[3]);                               
		#endif
	}                                                                                         
	else                                                                                      
	{                                                                                         
		#ifdef __MESSAGE_DEBUG__
		printf("SETUP mqtt IP Error .....\r\n");                                              
		#endif
		return FAILURE;		                                                                          
	}                                                                                         
                                                                                              
	//=============================================================================================
	if(strstr(msg, GSTECH_MQTT_PORT)!=NULL)                                                   
	{                                                                                         
	   	GSTECH_PARSE_COMMAND(msg,GSTECH_MQTT_PORT, (char*) Gstech_Temp);                             
                                                                                              
		Temp16BF = atoi(Gstech_Temp);        // ���ڿ��� ������ ��ȯ�Ͽ� num1�� �Ҵ�  

		if(gstech_Mqtt_PORT != Temp16BF)
		{
			GetCommandType = _MQTT_COMMAND_REBOOT;
 			BitJumpBootCodeStart = _SET;
		}

		gstech_Mqtt_PORT = Temp16BF;
                                                                                              
		#ifdef __MESSAGE_DEBUG__
		printf("gstech_Mqtt_PORT = %d\r\n",gstech_Mqtt_PORT);                                 
		#endif
	}                                                                                         
	else                                                                                      
	{                                                                                         
		#ifdef __MESSAGE_DEBUG__
		printf("SETUP mqtt Port Error .....\r\n");                                            
		#endif
		return FAILURE;		                                                                          
	}                                                                                         
                                                                                              
	//=============================================================================================
	if(strstr(msg, GSTECH_MQTT_ID)!=NULL)                                                     
	{                                                                                         
	   	GSTECH_PARSE_COMMAND(msg,GSTECH_MQTT_ID, (char*)TempStringBF);                      

		//#ifdef __MESSAGE_DEBUG__
		//printf("gstech_Mqtt_UserName = %s, size = %d\r\n",TempStringBF, Gstech_PasingLength);                         
		//#endif
		if(Gstech_PasingLength <= _MQTT_MAX_ID_COUNT)	// Over 10Byte?
		{
			gstech_UserNameLength = Gstech_PasingLength;
			memset(&gstech_Mqtt_UserName[0],0,_MQTT_MAX_ID_COUNT);
			memcpy(&gstech_Mqtt_UserName[0] , &TempStringBF[0] , Gstech_PasingLength);    
			#ifdef __MESSAGE_DEBUG__
			printf("gstech_Mqtt_UserName = %s , Length = %dByte\r\n",gstech_Mqtt_UserName, Gstech_PasingLength);                         
			#endif
		}
		else                                                                                      
		{                                                                                         
			#ifdef __MESSAGE_DEBUG__
			printf("SETUP mqtt ID Length Error ..... [%d)Byte\r\n", Gstech_PasingLength);                                              
			#endif
			return FAILURE;		                                                                          
		}                                                                                         
	}                                                                                         
	else                                                                                      
	{                                                                                         
		#ifdef __MESSAGE_DEBUG__
		printf("SETUP mqtt ID Error .....\r\n");                                              
		#endif
		return FAILURE;		                                                                          
	}                                                                                         
                                                                                              
	//=============================================================================================
	if(strstr(msg, GSTECH_MQTT_PW)!=NULL)                                                     
	{                                                                                         
	   	GSTECH_PARSE_COMMAND(msg,GSTECH_MQTT_PW, (char*)TempStringBF);                      

		//#ifdef __MESSAGE_DEBUG__
		//printf("gstech_Mqtt_PW = %s, size = %d\r\n",TempStringBF, Gstech_PasingLength);                         
		//#endif
		if(Gstech_PasingLength <= _MQTT_MAX_PW_COUNT)	// Over 15Byte?
		{
			gstech_PasswordLength = Gstech_PasingLength;
			memset(&gstech_Mqtt_PW[0],0,_MQTT_MAX_PW_COUNT);
			memcpy(&gstech_Mqtt_PW[0] , &TempStringBF[0] , Gstech_PasingLength);    
			#ifdef __MESSAGE_DEBUG__
			printf("gstech_Mqtt_PW = %s , Length = %dByte\r\n",gstech_Mqtt_PW, Gstech_PasingLength);                         
			#endif
		}
		else                                                                                      
		{                                                                                         
			#ifdef __MESSAGE_DEBUG__
			printf("SETUP mqtt PW Length Error ..... [%d)Byte\r\n", Gstech_PasingLength);                                              
			#endif
			return FAILURE;		                                                                          
		}                                                                                         
	}                                                                                         
	else                                                                                      
	{                                                                                         
		#ifdef __MESSAGE_DEBUG__
		printf("SETUP mqtt PW Error .....\r\n");                                              
		#endif
		return FAILURE;		                                                                          
	}                                                                                         
                                                                                              
	//=============================================================================================
	if(strstr(msg, GSTECH_UPDATE_IP)!=NULL)                                                   
	{                                                                                         
	   	GSTECH_PARSE_COMMAND(msg,GSTECH_UPDATE_IP, (char*) Gstech_Temp);                             
                                                                                              
		sscanf(Gstech_Temp, "%d.%d.%d.%d", &TEMPIP[0],&TEMPIP[1],&TEMPIP[2],&TEMPIP[3]);      

		if((gstech_Update_IP[0] != (BYTE)TEMPIP[0]) ||
		   (gstech_Update_IP[1] != (BYTE)TEMPIP[1]) ||
		   (gstech_Update_IP[2] != (BYTE)TEMPIP[2]) ||
		   (gstech_Update_IP[3] != (BYTE)TEMPIP[3]))
		{
			GetCommandType = _MQTT_COMMAND_REBOOT;
 			BitJumpBootCodeStart = _SET;
		}

		gstech_Update_IP[0]= (BYTE)(TEMPIP[0]);                                               
		gstech_Update_IP[1]= (BYTE)(TEMPIP[1]);                                               
		gstech_Update_IP[2]= (BYTE)(TEMPIP[2]);                                               
		gstech_Update_IP[3]= (BYTE)(TEMPIP[3]);                                               

		#ifdef __MESSAGE_DEBUG__
		printf("gstech_Update_IP[0] = %d\r\n",gstech_Update_IP[0]);                           
		printf("gstech_Update_IP[1] = %d\r\n",gstech_Update_IP[1]);                           
		printf("gstech_Update_IP[2] = %d\r\n",gstech_Update_IP[2]);                           
		printf("gstech_Update_IP[3] = %d\r\n",gstech_Update_IP[3]);                           
		#endif
	}                                                                                         
	else                                                                                      
	{                                                                                         
		#ifdef __MESSAGE_DEBUG__
		printf("SETUP update IP Error .....\r\n");                                            
		#endif
		return FAILURE;		                                                                          
	}                                                                                         
                                                                                              
	//=============================================================================================
	if(strstr(msg, GSTECH_UPDATE_PORT)!=NULL)                                                 
	{                                                                                         
	   	GSTECH_PARSE_COMMAND(msg,GSTECH_UPDATE_PORT, (char*) Gstech_Temp);                           
                                                                                              
		Temp16BF = atoi(Gstech_Temp);        // ���ڿ��� ������ ��ȯ�Ͽ� num1�� �Ҵ�
                                                                                              
		if(gstech_Update_PORT != Temp16BF)
		{
			GetCommandType = _MQTT_COMMAND_REBOOT;
 			BitJumpBootCodeStart = _SET;
		}

		gstech_Update_PORT = Temp16BF;
                                                                                              
		#ifdef __MESSAGE_DEBUG__
		printf("gstech_Update_PORT = %d\r\n",gstech_Update_PORT);                             
		#endif
	}                                                                                         
	else                                                                                      
	{                                                                                         
		#ifdef __MESSAGE_DEBUG__
		printf("SETUP update Port Error .....\r\n");                                          
		#endif
		return FAILURE;		                                                                          
	}                                                                                         
                                                                                              
	//=============================================================================================
	if(strstr(msg, GSTECH_STATUS_CYCLE)!=NULL)                                                
	{                                                                                         
	   	GSTECH_PARSE_COMMAND(msg,GSTECH_STATUS_CYCLE, (char*) Gstech_Temp);                          
                                                                                              
		if(strcmp(Gstech_Temp,"True") == 0)
		{
			BitMqttContinueSendEnable = _SET;
			gstech_StatusCycle = _SET;
		}
		else if(strcmp(Gstech_Temp,"False") == 0)
		{                                                                                              
			BitMqttContinueSendEnable = _CLR;
			gstech_StatusCycle = _CLR;
		}
 		else                                                                                      
		{                                                                                         
			#ifdef __MESSAGE_DEBUG__
			printf("SETUP status cycle Error .....\r\n");                                         
			#endif
			return FAILURE;		                                                                          
		}                                                                                         

		#ifdef __MESSAGE_DEBUG__
		if(BitMqttContinueSendEnable)
			printf("gstech_StatusCycle - Enable \r\n");                             
		else
			printf("gstech_StatusCycle - Flase\r\n");                             
		#endif
	}                                                                                         
	else                                                                                      
	{                                                                                         
		#ifdef __MESSAGE_DEBUG__
		printf("SETUP status cycle Error .....\r\n");                                         
		#endif
		return FAILURE;		                                                                          
	}                                                                                         
                                                                                              
	//=============================================================================================
	if(strstr(msg, GSTECH_PERIOD)!=NULL)                                                      
	{                                                                                         
	   	GSTECH_PARSE_COMMAND(msg,GSTECH_PERIOD, (char*) Gstech_Temp);                                
                                                                                              
		gstech_Period = atoi(Gstech_Temp);        // ���ڿ��� ������ ��ȯ�Ͽ� num1�� �Ҵ�     

		gstech_PeriodCount = gstech_Period;
                                                                                              
		#ifdef __MESSAGE_DEBUG__
		printf("gstech_Period = %d\r\n",gstech_Period);                                       
		#endif
	}                                                                                         
	else                                                                                      
	{                                                                                         
		#ifdef __MESSAGE_DEBUG__
		printf("SETUP period Error .....\r\n");                                               
		#endif
		return FAILURE;		                                                                          
	}                                                                                         

	return SUCCESSS;
}
