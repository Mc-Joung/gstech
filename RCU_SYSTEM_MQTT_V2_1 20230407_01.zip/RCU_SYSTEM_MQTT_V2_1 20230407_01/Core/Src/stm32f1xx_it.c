/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    stm32f1xx_it.c
  * @brief   Interrupt Service Routines.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f1xx_it.h"
/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
//****************************************************************************************************************************
//  I N C L U D E    F I L E S
//****************************************************************************************************************************
#include <stdio.h>
#include <string.h>    // strcat �Լ��� ����� ��� ����
#include <stdarg.h>
#include "define.h"
#include "extern.h"
#include "dhcp.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN TD */

/* USER CODE END TD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/* External variables --------------------------------------------------------*/
extern UART_HandleTypeDef huart1;
extern UART_HandleTypeDef huart2;
/* USER CODE BEGIN EV */
unsigned long MilliTimer;

/* USER CODE END EV */

/******************************************************************************/
/*           Cortex-M3 Processor Interruption and Exception Handlers          */
/******************************************************************************/
/**
  * @brief This function handles Non maskable interrupt.
  */
void NMI_Handler(void)
{
  /* USER CODE BEGIN NonMaskableInt_IRQn 0 */

  /* USER CODE END NonMaskableInt_IRQn 0 */
  /* USER CODE BEGIN NonMaskableInt_IRQn 1 */
  while (1)
  {
  }
  /* USER CODE END NonMaskableInt_IRQn 1 */
}

/**
  * @brief This function handles Hard fault interrupt.
  */
void HardFault_Handler(void)
{
  /* USER CODE BEGIN HardFault_IRQn 0 */

  /* USER CODE END HardFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_HardFault_IRQn 0 */
    /* USER CODE END W1_HardFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Memory management fault.
  */
void MemManage_Handler(void)
{
  /* USER CODE BEGIN MemoryManagement_IRQn 0 */

  /* USER CODE END MemoryManagement_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_MemoryManagement_IRQn 0 */
    /* USER CODE END W1_MemoryManagement_IRQn 0 */
  }
}

/**
  * @brief This function handles Prefetch fault, memory access fault.
  */
void BusFault_Handler(void)
{
  /* USER CODE BEGIN BusFault_IRQn 0 */

  /* USER CODE END BusFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_BusFault_IRQn 0 */
    /* USER CODE END W1_BusFault_IRQn 0 */
  }
}

/**
  * @brief This function handles Undefined instruction or illegal state.
  */
void UsageFault_Handler(void)
{
  /* USER CODE BEGIN UsageFault_IRQn 0 */

  /* USER CODE END UsageFault_IRQn 0 */
  while (1)
  {
    /* USER CODE BEGIN W1_UsageFault_IRQn 0 */
    /* USER CODE END W1_UsageFault_IRQn 0 */
  }
}

/**
  * @brief This function handles System service call via SWI instruction.
  */
void SVC_Handler(void)
{
  /* USER CODE BEGIN SVCall_IRQn 0 */

  /* USER CODE END SVCall_IRQn 0 */
  /* USER CODE BEGIN SVCall_IRQn 1 */

  /* USER CODE END SVCall_IRQn 1 */
}

/**
  * @brief This function handles Debug monitor.
  */
void DebugMon_Handler(void)
{
  /* USER CODE BEGIN DebugMonitor_IRQn 0 */

  /* USER CODE END DebugMonitor_IRQn 0 */
  /* USER CODE BEGIN DebugMonitor_IRQn 1 */

  /* USER CODE END DebugMonitor_IRQn 1 */
}

/**
  * @brief This function handles Pendable request for system service.
  */
void PendSV_Handler(void)
{
  /* USER CODE BEGIN PendSV_IRQn 0 */

  /* USER CODE END PendSV_IRQn 0 */
  /* USER CODE BEGIN PendSV_IRQn 1 */


  /* USER CODE END PendSV_IRQn 1 */
}

/**
  * @brief This function handles System tick timer.
  */
void SysTick_Handler(void)
{
  /* USER CODE BEGIN SysTick_IRQn 0 */

  /* USER CODE END SysTick_IRQn 0 */
  HAL_IncTick();
  /* USER CODE BEGIN SysTick_IRQn 1 */
	MilliTimer++;

	Bit1mS = _SET;

 	//HAL_GPIO_TogglePin(GPIOB,GPIO_PIN_2);
 	//HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_7);
 	//HAL_GPIO_TogglePin(GPIOC,GPIO_PIN_8);

	//=======================================================================================================================================
	if((++gstech_Timer10mSec) >= _TIME_10MS_VALUE)
	{
		Bit10mS = _SET;
		gstech_Timer10mSec = _CLR;
	}

	//if((++gstech_Timer25mSec) >= _TIME_25MS_VALUE)
	//{
	//	Bit25mS = _SET;
	//	gstech_Timer25mSec = _CLR;
	//}
    //
	//if((++gstech_Timer50mSec) >= _TIME_50MS_VALUE)
	//{
	//	Bit50mS = _SET;
	//	gstech_Timer50mSec = _CLR;
	//}
    //
	if((++gstech_Timer100mSec) >= _TIME_100MS_VALUE)
	{
		Bit100mS = _SET;
		gstech_Timer100mSec = _CLR;
	}

	if((++gstech_Timer250mSec) >= _TIME_250MS_VALUE)
	{
		Bit250mS = _SET;
		gstech_Timer250mSec = _CLR;
	}

	if((++gstech_Timer500mSec) >= _TIME_500MS_VALUE)
	{
		Bit500mS = _SET;
		gstech_Timer500mSec = _CLR;
	}

	if((++gstech_Timer1000mSec) >= _TIME_1000MS_VALUE)
	{
		Bit1000mS = _SET;
		gstech_Timer1000mSec = _CLR;

		if(gstech_MqttSendStartTimeCount)
		{
			if((--gstech_MqttSendStartTimeCount) == _CLR)
			{
				BitMqttSendDataStart = _SET;
			}
		}

		////=======================================================================================================================================
		//if(gstech_RelayTimeCount[1])
		//{
		//	if((--gstech_RelayTimeCount[1]) == _CLR)
		//	{
		//		if(BitPort1Control)
		//		{
		//			RELAY_PORT_1_ON();
		//		}
		//		else //if(!BitPort1Control)
		//		{
		//			RELAY_PORT_1_OFF();
		//		}
		//	//printf("Gstech_RelayStatus 1 = %d\r\n", Gstech_RelayStatus[1]);
		//	}
		//}
    	
		//---------------------------------------------------
		if(gstech_RelayTimeCount[2])
		{
			if((--gstech_RelayTimeCount[2]) == _CLR)
			{
				if(BitPort2Control)
				{
					RELAY_PORT_2_ON();
				}
				else //if(!BitPort2Control)
				{
					RELAY_PORT_2_OFF();
				}
				//printf("Gstech_RelayStatus 2 = %d\r\n", Gstech_RelayStatus[2]);
			}
		}
    	
		//---------------------------------------------------
		if(gstech_RelayTimeCount[3])
		{
			if((--gstech_RelayTimeCount[3]) == _CLR)
			{
				if(BitPort3Control)
				{
					RELAY_PORT_3_ON();
				}
				else //if(!BitPort3Control)
				{
					RELAY_PORT_3_OFF();
				}
				//printf("Gstech_RelayStatus 3 = %d\r\n", Gstech_RelayStatus[3]);
			}
		}
    	
		//---------------------------------------------------
		if(gstech_RelayTimeCount[4])
		{
			if((--gstech_RelayTimeCount[4]) == _CLR)
			{
				if(BitPort4Control)
				{
					RELAY_PORT_4_ON();
				}
				else //if(!BitPort4Control)
				{
					RELAY_PORT_4_OFF();
				}
				//printf("Gstech_RelayStatus 4 = %d\r\n", Gstech_RelayStatus[4]);
			}
		}

		//---------------------------------------------------
		if(gstech_RelayTimeCount[5])
		{
			if((--gstech_RelayTimeCount[5]) == _CLR)
			{
				if(BitPort5Control)
				{
					RELAY_PORT_5_ON();
				}
				else //if(!BitPort5Control)
				{
					RELAY_PORT_5_OFF();
				}
				//printf("Gstech_RelayStatus 5 = %d\r\n", Gstech_RelayStatus[5]);
			}
		}
    
		//---------------------------------------------------
		if(gstech_RelayTimeCount[6])
		{
			if((--gstech_RelayTimeCount[6]) == _CLR)
			{
				if(BitPort6Control)
				{
					RELAY_PORT_6_ON();
				}
				else //if(!BitPort6Control)
				{
					RELAY_PORT_6_OFF();
				}
				//printf("Gstech_RelayStatus 6 = %d\r\n", Gstech_RelayStatus[6]);
			}
		}
    
		//---------------------------------------------------
		if(gstech_RelayTimeCount[7])
		{
			if((--gstech_RelayTimeCount[7]) == _CLR)
			{
				if(BitPort7Control)
				{
					RELAY_PORT_7_ON();
				}
				else //if(!BitPort7Control)
				{
					RELAY_PORT_7_OFF();
				}
				//printf("Gstech_RelayStatus 7 = %d\r\n", Gstech_RelayStatus[7]);
			}
		}
    
		//---------------------------------------------------
		if(gstech_RelayTimeCount[8])
		{
			if((--gstech_RelayTimeCount[8]) == _CLR)
			{
				if(BitPort8Control)
				{
					RELAY_PORT_8_ON();
				}
				else if(!BitPort8Control)
				{
					RELAY_PORT_8_OFF();
				}
				//printf("Gstech_RelayStatus 8 = %d\r\n", Gstech_RelayStatus[8]);
			}
		}

		DHCP_time_handler();
	}

	//=======================================================================================================================================
	++gstech_pingMessageTimeCount;

	//=======================================================================================================================================
	//if((++gstech_TimerxxxxmSec) > _TIME_8000MS_VALUE)
	//{
	//	BitxxxxmS = _SET;
	//	gstech_TimerxxxxmSec = _CLR;
	//}

	////=======================================================================================================================================
	//if(gstech_TimeOverI2C)
	//{
	//	if((--gstech_TimeOverI2C) == _CLR)
	//	{
	//		BitTimeOverI2C = _SET;
	//	}
	//}
    //
 	//=======================================================================================================================================
	if(gstech_W5500TimeOutCount)
	{
		if((--gstech_W5500TimeOutCount) == _CLR)
		{
			BitTimeOverW5500Check = _SET;
		}
	}

 	//=======================================================================================================================================
	if(gstech_sntpTimeOutCount)
	{
		if((--gstech_sntpTimeOutCount) == _CLR)
		{
			BitTimeOversntpCheck = _SET;
		}
	}

	//=======================================================================================================================================

  /* USER CODE END SysTick_IRQn 1 */
}

/******************************************************************************/
/* STM32F1xx Peripheral Interrupt Handlers                                    */
/* Add here the Interrupt Handlers for the used peripherals.                  */
/* For the available peripheral interrupt handler names,                      */
/* please refer to the startup file (startup_stm32f1xx.s).                    */
/******************************************************************************/

/**
  * @brief This function handles USART1 global interrupt.
  */
void USART1_IRQHandler(void)
{
  /* USER CODE BEGIN USART1_IRQn 0 */

  /* USER CODE END USART1_IRQn 0 */
  HAL_UART_IRQHandler(&huart1);
  /* USER CODE BEGIN USART1_IRQn 1 */

  /* USER CODE END USART1_IRQn 1 */
}

/**
  * @brief This function handles USART2 global interrupt.
  */
void USART2_IRQHandler(void)
{
  /* USER CODE BEGIN USART2_IRQn 0 */

  /* USER CODE END USART2_IRQn 0 */
  HAL_UART_IRQHandler(&huart2);
  /* USER CODE BEGIN USART2_IRQn 1 */

  /* USER CODE END USART2_IRQn 1 */
}

/* USER CODE BEGIN 1 */

/* USER CODE END 1 */
/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
