#ifndef __CLIENT_H
#define __CLIENT_H

void client_init(void);


#endif