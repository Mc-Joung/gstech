#ifndef __SERVER_H
#define __SERVER_H

void server_init(void);
void receive_data(uint8_t *data_buf);

#endif