#ifndef __LED_CF_H
#define __LED_CF_H

#include "stm32f4xx_gpio.h"

void M_LED_Config(void);

#endif