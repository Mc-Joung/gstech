//
// Created by Wang on 2021/2/27.
//

#include "w5500_conf.h"
#include <string.h>
#include "main.h"
#include "spi.h"
#include <stdio.h>
#include "w5500.h"
#include "dhcp.h"

#define W5500_SPI    &hspi2

CONFIG_MSG ConfigMsg;
EEPROM_MSG_STR EEPROM_MSG;

uint8 mac[6] = {0x00, 0x08, 0xdc, 0x11, 0x11, 0x11};	/*W5500 MAC address*/

uint8 local_ip[4] = {192, 168, 0, 101};
uint8 subnet[4] = {255, 255, 255, 0};
uint8 gateway[4] = {192, 168, 0, 1};
uint8 dns_server[4] = {114, 114, 114, 114};

uint16 local_port = 6000;

uint8 remote_ip[4] = {192, 168, 0, 100};
uint16 remote_port = 1883;

uint8 ip_from = IP_FROM_DEFINE;

/*******************************************************************************
* Function Name  : SPI_FLASH_SendByte
* Description    : Sends a byte through the SPI interface and return the byte
*                  received from the SPI bus.
* Input          : byte : byte to send.
* Output         : None
* Return         : The value of the received byte.
*******************************************************************************/
unsigned char SPI2_ReadWrite(unsigned char writedat)
{
	unsigned char ret;
	HAL_SPI_TransmitReceive(W5500_SPI, &writedat, &ret, 1u, 10u);
	return ret;
}

void wiz_cs(uint8_t val)
{
	if (val==LOW)
	{
		HAL_GPIO_WritePin(CS_GPIO_Port, CS_Pin, GPIO_PIN_RESET);
	} else
	{
		HAL_GPIO_WritePin(CS_GPIO_Port, CS_Pin, GPIO_PIN_SET);
	}
}

uint8 IINCHIP_SpiSendData(uint8 dat)
{
	return (SPI2_ReadWrite(dat));
}

void iinchip_csoff(void)
{
	wiz_cs(LOW);
}

void iinchip_cson(void)
{
	wiz_cs(HIGH);
}

void IINCHIP_WRITE(uint32 addrbsb, uint8 data)
{
	iinchip_csoff();
	IINCHIP_SpiSendData((addrbsb & 0x00FF0000) >> 16);
	IINCHIP_SpiSendData((addrbsb & 0x0000FF00) >> 8);
	IINCHIP_SpiSendData((addrbsb & 0x000000F8) + 4);
	IINCHIP_SpiSendData(data);
	iinchip_cson();
}

uint8 IINCHIP_READ(uint32 addrbsb)
{
	uint8 data = 0;
	iinchip_csoff();
	IINCHIP_SpiSendData((addrbsb & 0x00FF0000) >> 16);
	IINCHIP_SpiSendData((addrbsb & 0x0000FF00) >> 8);
	IINCHIP_SpiSendData((addrbsb & 0x000000F8));
	data = IINCHIP_SpiSendData(0x00);
	iinchip_cson();
	return data;
}

uint16 wiz_write_buf(uint32 addrbsb, uint8 *buf, uint16 len)
{
	uint16 idx = 0;
	if (len==0) printf("Unexpected2 length 0\r\n");
	iinchip_csoff();
	IINCHIP_SpiSendData((addrbsb & 0x00FF0000) >> 16);
	IINCHIP_SpiSendData((addrbsb & 0x0000FF00) >> 8);
	IINCHIP_SpiSendData((addrbsb & 0x000000F8) + 4);
	for (idx = 0; idx < len; idx++)
	{
		IINCHIP_SpiSendData(buf[idx]);
	}
	iinchip_cson();
	return len;
}

uint16 wiz_read_buf(uint32 addrbsb, uint8 *buf, uint16 len)
{
	uint16 idx = 0;
	if (len==0)
	{
		printf("Unexpected2 length 0\r\n");
	}
	iinchip_csoff();
	IINCHIP_SpiSendData((addrbsb & 0x00FF0000) >> 16);
	IINCHIP_SpiSendData((addrbsb & 0x0000FF00) >> 8);
	IINCHIP_SpiSendData((addrbsb & 0x000000F8));
	for (idx = 0; idx < len; idx++)
	{
		buf[idx] = IINCHIP_SpiSendData(0x00);
	}
	iinchip_cson();
	return len;
}

uint8 set_w5500_ip(void)
{
	memcpy(ConfigMsg.mac, mac, 6u);
	memcpy(ConfigMsg.lip, local_ip, 4u);
	memcpy(ConfigMsg.sub, subnet, 4u);
	memcpy(ConfigMsg.gw, gateway, 4u);
	memcpy(ConfigMsg.dns, dns_server, 4u);

	if (ip_from==IP_FROM_EEPROM)
	{

	}

	if (ip_from==IP_FROM_DHCP)
	{
		if (dhcp_ok == 1)
		{
			printf(" IP from DHCP \r\n");
			memcpy(ConfigMsg.lip,DHCP_GET.lip, 4);
			memcpy(ConfigMsg.sub,DHCP_GET.sub, 4);
			memcpy(ConfigMsg.gw,DHCP_GET.gw, 4);
			memcpy(ConfigMsg.dns,DHCP_GET.dns,4);
		}
		else
		{
			printf(" DHCP sub program run failed.\r\n");
			printf(" Use defined IP information.\r\n");
		}
	}

	ConfigMsg.sw_ver[0] = FW_VER_HIGH;
	ConfigMsg.sw_ver[1] = FW_VER_LOW;

	setSUBR(ConfigMsg.sub);
	setGAR(ConfigMsg.gw);
	setSIPR(ConfigMsg.lip);

	getSIPR(local_ip);
	printf(" W5500 IP address   : %d.%d.%d.%d\r\n", local_ip[0], local_ip[1], local_ip[2], local_ip[3]);
	getSUBR(subnet);
	printf(" W5500 sub net mask : %d.%d.%d.%d\r\n", subnet[0], subnet[1], subnet[2], subnet[3]);
	getGAR(gateway);
	printf(" W5500 gateway     : %d.%d.%d.%d\r\n", gateway[0], gateway[1], gateway[2], gateway[3]);

	if ((local_ip[0]!=ConfigMsg.lip[0]) || (local_ip[1]!=ConfigMsg.lip[1]) ||
		(local_ip[2]!=ConfigMsg.lip[2]) || (local_ip[3]!=ConfigMsg.lip[3]))
		return 1;
	if ((subnet[0]!=ConfigMsg.sub[0]) || (subnet[1]!=ConfigMsg.sub[1]) ||
		(subnet[2]!=ConfigMsg.sub[2]) || (subnet[3]!=ConfigMsg.sub[3]))
		return 2;
	if ((gateway[0]!=ConfigMsg.gw[0]) || (gateway[1]!=ConfigMsg.gw[1]) ||
		(gateway[2]!=ConfigMsg.gw[2]) || (gateway[3]!=ConfigMsg.gw[3]))
		return 3;

	return 0;
}

void set_w5500_mac(void)
{
	memcpy(ConfigMsg.mac, mac, 6);
	setSHAR(ConfigMsg.mac);    /**/
	memcpy(DHCP_GET.mac, mac, 6);
}

void reset_w5500(void)
{
	HAL_GPIO_WritePin(RST_GPIO_Port, RST_Pin, GPIO_PIN_RESET);
	HAL_Delay(1);
	HAL_GPIO_WritePin(RST_GPIO_Port, RST_Pin, GPIO_PIN_SET);
	HAL_Delay(1);
}

void set_network(void)
{
	setSUBR(ConfigMsg.sub);
	setGAR(ConfigMsg.gw);
	setSIPR(ConfigMsg.lip);
}
