//
// Created by Wang on 2021/2/27.
//

#ifndef _W5500_CONF_H_
#define _W5500_CONF_H_

#include "types.h"

extern uint8		local_ip[4];
extern uint8  	remote_ip[4];
extern uint16 	remote_port;
extern uint16		local_port;
extern uint8  	use_dhcp;
extern uint8  	use_eeprom;

extern uint8 ip_from;
extern uint8 dhcp_ok;
extern uint32 dhcp_time;

#define FW_VER_HIGH  						1
#define FW_VER_LOW    					0
#define ON	                 		1
#define OFF	                 		0
#define HIGH	           	 			1
#define LOW		             			0

#define IP_FROM_DEFINE	  	0
#define IP_FROM_DHCP	  	1
#define IP_FROM_EEPROM	  	2


typedef struct _CONFIG_MSG
{
	uint8 mac[6];			/*MAC address*/
	uint8 lip[4];			/*local IP*/
	uint8 sub[4];			/*sub net mask*/
	uint8 gw[4];			/*Gateway*/
	uint8 dns[4];			/*DNS address*/
	uint8 rip[4];			/*remote IP*/
	uint8 sw_ver[2];		/*Software version*/
}CONFIG_MSG;

extern CONFIG_MSG  	ConfigMsg;

typedef struct _EEPROM_MSG
{
	uint8 mac[6];			/*MAC address*/
	uint8 lip[4];			/*local IP*/
	uint8 sub[4];			/*sub net mask*/
	uint8 gw[4];			/*Gateway*/
}EEPROM_MSG_STR;

extern EEPROM_MSG_STR EEPROM_MSG;

void IINCHIP_WRITE( uint32 addrbsb,  uint8 data);
uint8 IINCHIP_READ(uint32 addrbsb);
uint16 wiz_write_buf(uint32 addrbsb,uint8* buf,uint16 len);
uint16 wiz_read_buf(uint32 addrbsb, uint8* buf,uint16 len);

uint8 set_w5500_ip(void);
void set_w5500_mac(void);
void reset_w5500(void);
void set_network(void);

#endif //_W5500_CONF_H_
