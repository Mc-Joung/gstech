//
// Created by Wang on 2021/3/1.
//

#include "tcp_demo.h"
#include <stdio.h>
#include <string.h>
#include "socket.h"
#include "w5500.h"
#include "w5500_conf.h"

uint8 buff[2048];

void do_tcp_server(void)
{
	uint16 len = 0;
	switch (getSn_SR(SOCK_TCPS))        //Get the status of socket
	{
		case SOCK_CLOSED:
			socket(SOCK_TCPS, Sn_MR_TCP, local_port, Sn_MR_ND);    //Open socket
			break;
		case SOCK_INIT:
			listen(SOCK_TCPS);    //Build listen to socket
			break;
		case SOCK_ESTABLISHED:
			if (getSn_IR(SOCK_TCPS) & Sn_IR_CON)
			{
				setSn_IR(SOCK_TCPS, Sn_IR_CON);
			}
			len = getSn_RX_RSR(SOCK_TCPS);
			if (len > 0)
			{
				recv(SOCK_TCPS, buff, len);
				buff[len] = 0x00;
				printf("%s\r\n", buff);
			}
			break;
		case SOCK_CLOSE_WAIT:
			close(SOCK_TCPS);
			break;
	}
}

void do_tcp_client(void)
{
	uint16 len = 0;

	switch (getSn_SR(SOCK_TCPC))
	{
		case SOCK_CLOSED:
			socket(SOCK_TCPC, Sn_MR_TCP, local_port++, Sn_MR_ND);
			break;
		case SOCK_INIT:
			connect(SOCK_TCPC, remote_ip, remote_port);
			break;
		case SOCK_ESTABLISHED:
			if (getSn_IR(SOCK_TCPC) & Sn_IR_CON)
			{
				setSn_IR(SOCK_TCPC, Sn_IR_CON);
			}

			len = getSn_RX_RSR(SOCK_TCPC);
			if (len > 0)
			{
				recv(SOCK_TCPC, buff, len);
				buff[len] = 0x00;
				printf("%s\r\n", buff);
			}

			strcpy(buff, "Hello World!\r\n");
			send(SOCK_TCPC, buff, 14u);
			HAL_Delay(1000u);
			break;
		case SOCK_CLOSE_WAIT:
			close(SOCK_TCPC);
			break;
	}
}
