//
// Created by Wang on 2021/3/16.
//

#include "udp_demo.h"
#include <stdio.h>
#include "types.h"
#include "w5500_conf.h"
#include "w5500.h"
#include "socket.h"


void do_udp(void)
{
	uint16 len = 0;
	uint8 buff[2048];

	switch(getSn_SR(SOCK_UDPS))
	{
		case SOCK_CLOSED:
			socket(SOCK_UDPS, Sn_MR_UDP, local_port, 0);
			break;
		case SOCK_UDP:
			HAL_Delay(10);
			if (getSn_IR(SOCK_UDPS) & Sn_IR_RECV)
			{
				setSn_IR(SOCK_UDPS, Sn_IR_RECV);
			}

			if ((len = getSn_RX_RSR(SOCK_UDPS)) > 0)
			{
				recvfrom(SOCK_UDPS, buff, len, remote_ip, &remote_port);
				buff[len - 8] = 0x00;
				printf("%s\r\n", buff);
				sendto(SOCK_UDPS, buff, len-8, remote_ip, remote_port);
			}
			break;
	}

}
