//
// Created by Wang on 2021/3/16.
//

#ifndef _SMTP_H_
#define _SMTP_H_

#include "types.h"

extern char from[];	/*Sender email address*/
extern char to[];	/*Receiver email address*/

//SMTP_STATE
#define waitfor220 			0
#define waitforHELO250 		1
#define waitforAUTH334 		2
#define waitforuser334 		3
#define waitforpassword235 	4
#define waitforsend250 		5
#define waitforrcpt250 		6
#define waitfordate354 		7
#define waitformime250 		8

#endif //_SMTP_H_
