//
// Created by Wang on 2021/2/27.
//

#ifndef _PING_H_
#define _PING_H_

#include "types.h"
#include "stm32f1xx.h"

#define BUF_LEN 128
#define PING_REQUEST 8
#define PING_REPLY 0
#define CODE_ZERO 0

#define SOCKET_ERROR 1
#define TIMEOUT_ERROR 2
#define SUCCESS 3
#define REPLY_ERROR 4

typedef struct pingmsg
{
	uint8  Type; 		// 0 - Ping Reply, 8 - Ping Request
	uint8  Code;		// Always 0
	uint16  CheckSum;	// Check sum
	uint16  ID;	            // Identification
	uint16  SeqNum; 	// Sequence Number
	int8_t  Data[BUF_LEN];// Ping Data  : 1452 = IP RAW MTU - sizeof(Type+Code+CheckSum+ID+SeqNum)
} PINGMSGR;

void ping_auto(uint8 s, uint8 *addr);
void ping_count(uint8 s, uint16 pCount, uint8 *addr);

#endif //_PING_H_
