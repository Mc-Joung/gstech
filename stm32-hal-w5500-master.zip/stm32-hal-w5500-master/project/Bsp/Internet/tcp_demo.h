//
// Created by Wang on 2021/3/1.
//

#ifndef _TCP_DEMO_H_
#define _TCP_DEMO_H_

#include "stm32f1xx.h"

void do_tcp_server(void);
void do_tcp_client(void);

#endif //_TCP_DEMO_H_
