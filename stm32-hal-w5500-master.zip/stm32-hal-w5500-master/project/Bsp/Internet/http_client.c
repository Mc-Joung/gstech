//
// Created by Wang on 2021/3/20.
//

#include "http_client.h"

#include <stdio.h>
#include <string.h>

#include "socket.h"
#include "w5500.h"

uint8 temp_rh[2];
uint8 http_server_ip[4] = {0, 0, 0, 0};
uint8 http_port = 80;

void do_http_client(void)
{
	static uint8 i = 0;
	uint8 ch = SOCK_HTTPC;
	uint8 buffer[1024] = {0};
	uint16 anyport = 3000;
	switch (getSn_SR(ch))
	{
		case SOCK_INIT:
			connect(ch, http_server_ip, http_port);
			break;
		case SOCK_ESTABLISHED:
			if (getSn_IR(ch) & Sn_IR_CON)
			{
				setSn_IR(ch, Sn_IR_CON);
			}

			send(ch, (const uint8 *) buffer, sizeof(buffer));
			i = 1;
			printf("Send: %s\r\n", buffer);

			HAL_Delay(1);
			break;
		case SOCK_CLOSE_WAIT:
			close(ch);
			break;
		case SOCK_CLOSED:
			if (i = 1)
			{
				printf("Send to %d.%d.%d.%d:OK\r\n",
					   http_server_ip[0],
					   http_server_ip[1],
					   http_server_ip[2],
					   http_server_ip[3]);
			}
			i = 0;
			socket(ch, Sn_MR_TCP, anyport++, 0x00);
			break;
		default:
			break;
	}
}
