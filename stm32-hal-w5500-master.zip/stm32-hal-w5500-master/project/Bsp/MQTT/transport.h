//
// Created by Wang on 2021/3/20.
//

#ifndef _TRANSPORT_H_
#define _TRANSPORT_H_

int transport_sendPacketBuffer(int sock, unsigned char* buf, int buflen);
int transport_getdata(unsigned char* buf, int count);
int transport_getdatanb(void *sck, unsigned char* buf, int count);
int transport_open(char* host, int port);
int transport_close(int sock);


#endif //_TRANSPORT_H_
