//
// Created by Wang on 2021/3/20.
//

#include "ts_mqtt.h"
#include "MQTTPacket.h"
#include "transport.h"

#include "w5500_conf.h"
#include "w5500.h"
#include "socket.h"

#include <string.h>

int do_MQTT(void)
{
	MQTTPacket_connectData data = MQTTPacket_connectData_initializer;
	int rc = 0;
	int mysock = SOCK_TCPC;
	unsigned char buf[200];
	int buflen = sizeof(buf);
	int msgid = 1;
	MQTTString topicString = MQTTString_initializer;
	int req_qos = 0;
	char *payload = "mypayload";
	int payloadlen = strlen(payload);
	int len = 0;
	char *host = "0.0.0.0";
	int port = 1883;

	switch (getSn_SR(SOCK_TCPC))
	{
		case SOCK_CLOSED:
			socket(SOCK_TCPC, Sn_MR_TCP, local_port++, Sn_MR_ND);
			break;
		case SOCK_INIT:
			connect(SOCK_TCPC, remote_ip, remote_port);
			break;
		case SOCK_ESTABLISHED:
			if (getSn_IR(SOCK_TCPC)&Sn_IR_CON)
			{
				printf("TCP established\r\n");
				setSn_IR(SOCK_TCPC, Sn_IR_CON);
			}

			printf("Sending to hostname %s port %d\n", host, port);

			data.clientID.cstring = "me";	//client ID
			data.keepAliveInterval = 20;	//keep alive time
			data.cleansession = 1;	// clean the last info after re-link (1: clean; 0: not clean)
			data.username.cstring = "testuser";	// the username if MQTT server need
			data.password.cstring = "testpassword";	// the password if MQTT server need

			len = MQTTSerialize_connect(buf, buflen, &data);  // Serialize the MQTT Packet according the connect data
			rc = transport_sendPacketBuffer(mysock, buf, len);	// sned packet to Server by driver

			/*wait for connack*/
			if (MQTTPacket_read(buf, buflen, transport_getdata)==CONNACK)	// call the driver to get conn ack packet from Server
			{
				unsigned char sessionPresent, connack_rc;
				if (MQTTDeserialize_connack(&sessionPresent, &connack_rc, buf, buflen) != 1 || connack_rc != 0)	//deserialize packet to confirm the MQTT connect success
				{
					printf("Unable to connect, return code %d\n", connack_rc);
					transport_close(mysock);
					return 0;
				}
				else
				{
					printf("Connect succeed!\r\n");
				}
			}
			else
			{
				transport_close(mysock);
				return 0;
			}

			/*subscribe*/
			topicString.cstring = "substopic";	// subscribe topic name from Server
			len = MQTTSerialize_subscribe(buf, buflen, 0, msgid, 1, &topicString, &req_qos);	//serialize subscribe topic packet
			rc = transport_sendPacketBuffer(mysock, buf, len);	// sned packet to Server by driver
			/* wait for suback */
			if (MQTTPacket_read(buf, buflen, transport_getdata) == SUBACK)	// call the driver to get subscribe ack packet from Server
			{
				unsigned short submsgid;
				int subcount;
				int granted_qos;

				rc = MQTTDeserialize_suback(&submsgid, 1, &subcount, &granted_qos, buf, buflen); // deserialize packet to confirm the MQTT subscribe success

				if (granted_qos != 0)
				{
					printf("granted qos != 0, %d\n", granted_qos);
					transport_close(mysock);
					return 0;
				}
				else
				{
					printf("Received suback\r\n");
				}
			}
			else
			{
				transport_close(mysock);
				return 0;
			}

			/*loop get msgs on 'subscribed' topic and send msgs on 'pubtopic' topic*/
			topicString.cstring = "pubtopic"; // publish topic name to Server
			while (1)
			{
				/* transport_getdata() has a built-in 1 second timeout,
				your mileage will vary */
				if (MQTTPacket_read(buf, buflen, transport_getdata) == PUBLISH)
				{
					unsigned char dup;	//re-send flag
					int qos;	// Service quality level
					unsigned char retained;	//keep flag
					unsigned short msgid;
					int payloadlen_in;
					unsigned char* payload_in;
					int rc;
					MQTTString receivedTopic;

					rc = MQTTDeserialize_publish(&dup, &qos, &retained, &msgid, &receivedTopic,
												 &payload_in, &payloadlen_in, buf, buflen);
					printf("message arrived %.*s\n", payloadlen_in, payload_in);
				}
				else
				{
					printf("No data arrived.\r\n");
				}

				printf("publishing reading\n");
				len = MQTTSerialize_publish(buf, buflen, 0, 0, 0, 0, topicString, (unsigned char*)payload, payloadlen);
				rc = transport_sendPacketBuffer(mysock, buf, len);
			}

			printf("disconnecting\n");
			len = MQTTSerialize_disconnect(buf, buflen);
			rc = transport_sendPacketBuffer(mysock, buf, len);
			break;
		case SOCK_CLOSE_WAIT:
			close(SOCK_TCPC);
			break;
	}
}
